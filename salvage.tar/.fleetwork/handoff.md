# Deterministic handoff - fleetwork-920 - 2026-10-29T06:33:40Z

## 0. Trigger
stop-length (last turn 27 stopReason=length, zero text blocks, thinking 65258 chars)

## 1. Original brief (verbatim)
JOB: jarate issue #306 - restart-boundary message handling: DIAGNOSE + FIX (one PR if the root cause is in jarate; documented finding + minimal mitigation if not).

CONTEXT (self-contained): operator complaint 2026-10-29: 'this restart handover sucks, half the time you miss the last message and have amnesia'. Issue #306 (marzukia/jarate) carries the full symptom write-up. The COMPACT path amnesia (#291) is fixed at f82fa69d and live - a 2026-10-29 compact resume was clean. The remaining class is the RESTART boundary:

EVIDENCE (today, hydrogen, jarate main 22d8bf58): after the planned pi restart, the agent channel received the 'pi-bg restart-wake - planned' embed TWICE, identical body. The second delivery's Discord snowflake (1565239434729754655) is OLDER than the first's (1565244903061987410) - an older event was replayed after the newer one. Recurring operator-observed second symptom: the message just before (or during) a restart does not reach the resumed session - the resume acts without it, silently.

DIAGNOSE (do not guess - read the code paths, then prove):
1. The restart scheduler + post-wake path: ~/scripts/pi-restart is tracked in the repo (issue #260) - find where the 'restart-wake - planned' embed is posted (the systemd one-shot / postcheck), and whether anything can post it twice per restart (double one-shot, postcheck retry, both the scheduler and a reconnect handler posting).
2. The gateway reconnect / message delivery path in the bridge (packages/bridge): after the pi process restarts, does the bridge replay channel history (REST fetch of recent messages on connect) without a seen-message-id dedupe set? That would explain the out-of-order replay (old snowflake delivered after the new one) AND could double-deliver. Check how incoming channel messages are buffered/resumed across a pi restart and whether a message posted while pi was down is delivered exactly once, in order.
3. The handover generator's RESTART path (distinct from the #291 compact path): does the restart handover capture the transcript through the last delivered message, and does it name lost/replayed messages explicitly?

FIX (mechanical, minimal, tested):
- if the double post is jarate's: make the restart-wake post idempotent per restart (one post, or a dedupe key the channel consumer ignores repeats of).
- if the replay is a reconnect history-fetch without dedupe: add a persistent seen-message-id set (the bridge already persists state JSON - extend it) so a snowflake is delivered to the session at most once, in snowflake order.
- regression tests for both (the bridge test suite pattern - discord.test.ts et al.).
- if a symptom's root cause is OUTSIDE jarate (e.g. Discord gateway itself replaying): document it in the PR with the evidence, and land the bridge-side dedupe as the mitigation (delivery-at-most-once is jarate's contract either way).

GATES (report each as a check line, exactly as CI runs them): bunx biome check . (the CI biome job), the CI test job command (read .github/workflows/ci.yml), bun run build / bin job as CI runs it, size job as CI runs it.

PROCESS: repo marzukia/jarate, base main (22d8bf58). Commit early per milestone. Push the branch, open the PR (body cites issue #306 + the two symptom evidence lines, worker: monky, reviewer pass to follow). END once the PR is open - no CI waits, no poll loops. Commits factual, NO Co-authored-by/AI trailers.

budget: code-path reading 200s + root-cause proof 200s + fix + tests 500s = 900s, +25% headroom 300s = 1200s wall. model_origin: explicit
model_origin: explicit

## 2. Git state
branch: HEAD
head: 22d8bf58f3ceb1aba1f3d848f77fc4e984fd6699
dirty: no

## 3. Files touched
read: /srv/fleetwork/work/920/packages/bridge/channel/restart-ops.ts, /srv/fleetwork/work/920/packages/bridge/channel/index.ts, /srv/fleetwork/work/920/packages/bridge/channel/handover.ts, /srv/fleetwork/work/920/packages/bridge/channel/queue.ts, /srv/fleetwork/work/920/packages/bridge/channel/discord.ts, /srv/fleetwork/work/920/packages/bridge/channel/restart-queue.ts, /srv/fleetwork/work/920/packages/bridge/channel/restart-wake.ts
modified: (none)

## 4. Decisions (marked lines only)
(none)

## 5. Last tool calls (truncated results)
[t18] read {"limit": 150, "offset": 3543, "path": "/srv/fleetwork/work/920/packages/bridge/channel/index.ts"}
  -> const bang = rawBody.match(/^!\s*([\s\S]+)$/);
  if (bang && ch) {
    noAck();
    if (!isOwnerUser(ch, msg.fromId)) {
      replyCmd(fence("[!] ! shell is owner-only"));
      return;
    }
    const shellCmd = bang[1].trim();
    sendDiscordTyping(ch).catch(() => {});
    const r = await runShellPassthrough(shellCmd, ctx.cwd);
    const truncated = r.out.length >= 20_000;
    const shown = r.out.length > 4000 ? r.out.slice(0, 4000) : r.out;
    const status = r.timedOut
      ? "timeout 60s"
      : r.code === 0
        ? r.out
          ? ""
          : "exit 0"
        : `exit ${r.code}`;
    const tail = [
      shown ? (truncated ? `… (truncated)` : "") : "(no output)",
      status,
    ]
      .filter(Boolean)
      .join(" · ");
    replyCmd(r.out ? `${wrapFence(shown)}\n${tail}` : tail);
    return;
  }

  // ── Side-question suffix: "fix the bug. btw" → brief-answer flag ─────
  const { prompt: body, forceBtw } = extractBtwSuffix(rawBody);

  // Channel ctx (+ btw hint) — LLM-only, not shown in the TUI.
  const channelCtx = buildChannelContext(ch, msg, { btw: forceBtw });
  const repliedBlock = buildRepliedMessageBlock(msg.repliedMessage);
  const ctxBlock = [channelCtx, repliedBlock].filter(Boolean).join("\n\n");
  const withCtx = (text: string) => `${ctxBlock}\n\n${text}`;

  // A run is in flight (streaming or has pending messages). Mid-turn inbounds
  // are queued for a guaranteed re-wake at agent_end instead of steered into
  // the in-flight run, which pi may swallow if the run ends first. forceDirect
  // (the re-wake path) bypasses the gate so the message is never re-queued.
  const runActive = forceDirect
    ? false
    : !ctx.isIdle() || ctx.hasPendingMessages?.() || isCompacting(ch.id);
  // #39: while held, EVERY plain message (attachments included) buffers in
  // the re-wake queue without starting a run — even while idle. The buffer
  // drains on /hold off. Held messages never arm the mid-run interrupt:
  // they wait their turn (an inte…[truncated]
[t19] bash {"command": "cd /srv/fleetwork/work/920/packages/bridge/channel && grep -n \"function queueMidTurnInbound\\|function drainRewakeSurvival\\|function popOldestQueuedInbound\\|function updateQueuedInbound\" index.ts queue.ts 2>/dev/null | head"}
  -> queue.ts:160:export function queueMidTurnInbound(
queue.ts:220:export function popOldestQueuedInbound(): {
queue.ts:280:export function drainRewakeSurvival(
queue.ts:375:export async function updateQueuedInbound(
[t20] read {"path": "/srv/fleetwork/work/920/packages/bridge/channel/queue.ts"}
  -> /**
 * channel/queue — mid-turn re-wake queue + queued acks + queue control.
 *
 * God-file split 2/5 (2026-10-19). Moved verbatim from index.ts: the
 * re-wake queue (queueMidTurnInbound / pop / clear / drain / drop),
 * queued acks (consume/renumber), and queue control (update/delete of
 * queued inbounds). Absorbs the
 * pre-existing queue.ts (extractQueueSuffix) — same path, no import
 * changes for that function.
 *
 * Shared state owned elsewhere: configRoot + runtimeStateDir +
 * interrupt state stay in index.ts (hub-and-spoke, runtime-only
 * cross-refs); hold state (heldChannels) likewise.
 */

import type { ExtensionContext } from "@earendil-works/pi-coding-agent";
import { extractBtwSuffix } from "./btw";
import { hasOwnerConfigured, isOwnerUser } from "./commands";
import { deleteDiscordMessage, editDiscordMessage } from "./discord";
import {
  armInterruptTimer,
  buildChannelContext,
  buildRepliedMessageBlock,
  channelTitle,
  configRoot,
  ensureRuntimeStateLoaded,
  heldChannels,
  interruptingChannels,
  interruptStepTimeoutMs,
  isBgInbound,
  pendingInterrupts,
  runtimeStateDir,
} from "./index";
import { persistLivePlaceholders } from "./live";
import {
  collectRewakeOrphans,
  rewakeAddPending,
  rewakePending,
  rewakeRemovePending,
  rewakeUpdatePendingMsg,
} from "./restart-queue";
import {
  type AttachmentRef,
  type ChannelConfig,
  type ChannelMessage,
  getChannel,
  loadChannelConfig,
} from "./types";

// Detects a `. queue` suffix at the end of a Discord message.
//
// Kimaki parity: a plain message during an active run ARMS the mid-run
// interrupt (jump the queue). A message ending in ". queue" is parked in
// the re-wake queue explicitly — it waits its turn and does NOT arm the
// interrupt. The suffix is stripped from the stored/forwarded text; the
// bot's ack shows the message's position in line.
//
// Supported forms (case-insensitive):
// - ". queue", "! queue", "; queue", ": queue" (punctuation, then the word)
// - "....q…[truncated]
[t21] read {"limit": 130, "offset": 3855, "path": "/srv/fleetwork/work/920/packages/bridge/channel/index.ts"}
  -> sendToPi(pi, ch.id, plainText, title, queuedBody || "(empty)", msg.messageId);
}

// ─── Send to pi session ──────────────────────────────────────────────────

export function sendToPi(
  pi: ExtensionAPI,
  channelId: string,
  text: string,
  title: string,
  displayBody: string,
  messageId?: string,
  messageIds?: string[],
): boolean {
  const ids = messageIds ?? (messageId ? [messageId] : []);
  if (ids.length > 0) {
    const prev = runInboundIds.get(channelId) ?? [];
    runInboundIds.set(channelId, [...new Set([...prev, ...ids])]);
  }
  interruptCancelled.delete(channelId); // a fresh send opens a fresh run
  try {
    pi.sendMessage(
      {
        customType: CHANNEL_MSG_TYPE,
        content: text, // LLM context: full channel-ctx + body
        display: true,
        // TUI: title + body only; messageId/messageIds drive reply threading
        details: {
          title,
          body: displayBody,
          ...(messageId ? { messageId } : {}),
          ...(ids.length > 0 ? { messageIds: ids } : {}),
        },
      },
      { triggerTurn: true, deliverAs: "steer" },
    );
    // #180: pi accepted the message — the delivery is committed. Prune
    // the survived copy (if this was a queued re-wake) and record the
    // id in the delivered set (the startup history-scan dedupe). A
    // sendMessage throw returns false BEFORE this line: the file keeps
    // the entry, the next restart re-delivers (at-least-once).
    if (messageId) {
      rewakeCommitDelivered(runtimeStateDir, channelId, messageId);
      // #186 (F1): the commit prunes the FILE copy; prune the drained
      // in-memory copy too (same id still queued by the survival drain
      // or a replay re-queue) — otherwise the agent_end re-wake pops
      // it and delivers the same inbound twice.
      dropQueuedInbound(channelId, messageId);
    }
  } catch (e) {
    console.error("[channel] sendMessage failed:", sanitizeUnknownValue(e));
    return false;
  }
  return true;
}

// ─── …[truncated]
[t22] read {"path": "/srv/fleetwork/work/920/packages/bridge/channel/handover.ts"}
  -> /**
 * Handover compaction — mechanism A (design v2, PR1).
 *
 * On a qualifying compaction (auto at the handoff threshold, manual
 * /compact or /handover) the bridge returns a durable handover doc as pi's
 * CUSTOM compaction result: `{ compaction: { summary: doc, ... } }` —
 * no cancel, no restart, the op-window flow is untouched (review F1/F3).
 *
 * The doc is a deterministic template (NO LLM call): the raw transcript
 * span (current state first) + References, State, Last user asks
 * extracted from the session, plus <read-files>/<modified-files> tags →
 * deterministic, CUMULATIVE: prior doc tags ∪ current span fileOps
 * (review F9). /compact operator focus instructions are rendered as ONE
 * line in the State section (absent when none passed).
 *
 * Cumulative: the prior doc (latest.md pointer) is the base (F6), so
 * context compaction never shrinks the doc — it only retires done work.
 * The doc is written to <storeDir>/<YYYYMMDD-HHMM>-<slug>.md BEFORE
 * compaction returns; on disk before the compact is the failure-handling
 * invariant (doc already on disk → restart picks it up in PR2).
 */

import fs from "node:fs";
import path from "node:path";
import type {
  ContextUsage,
  ExtensionContext,
  SessionEntry,
} from "@earendil-works/pi-coding-agent";
import { fmtTokensLC } from "./format";
import { jobsView } from "./jobs";
import { formatTaskLine, loadTasks } from "./tasks";
import { defaultHome, loadBoard, renderBoard } from "./todos";
import { keptTailMessages, msgText, serializeTranscript } from "./transcript";
import { getDefaultChannel, loadChannelConfig } from "./types";

// re-exported for the tests + existing importers
export {
  keptTailMessages,
  msgText,
  serializeTranscript,
} from "./transcript";

// ─── Types ──────────────────────────────────────────────────────────────────

/** Minimal structural shape of pi's CompactionPreparation (the main
 *  pi-coding-agent entry does not re-export the type name). */
export interface HandoverPr…[truncated]
[t23] bash {"command": "cd /srv/fleetwork/work/920/packages/bridge/channel && grep -n \"buildSeedKickoff\\|liveKickoffState\\|lastHandoffAt\\|isHandoffFreshWindow\" index.ts | head -20"}
  -> 77:  isHandoffFreshWindow,
527: *  latest.md stamp, so without this arm the isHandoffFreshWindow loop-guard
2780:        freshWindow: isHandoffFreshWindow(settings.storeDir),
3323:  if (isHandoffFreshWindow(settings.storeDir)) return;
[t24] read {"limit": 120, "offset": 3270, "path": "/srv/fleetwork/work/920/packages/bridge/channel/index.ts"}
  -> setTimeout(() => {
    try {
      // The gate is async: a throw inside REJECTS the promise, it does
      // not hit this try/catch (sync throws only). A stale ctx (session
      // replaced after the timer armed — pi -p always: the session ends
      // at run end) rejects on the first ctx.cwd read; unhandled, that
      // rejection kills `pi -p` at exit (2026-10-19 crash).
      maybeAutoCompactByToken(pi, ctx).catch((e) => {
        console.error(
          "[handoff] auto-compact gate failed:",
          sanitizeUnknownValue(e),
        );
      });
    } catch (e) {
      console.error(
        "[handoff] auto-compact gate failed:",
        sanitizeUnknownValue(e),
      );
    }
  }, 0);
}

/** The actual token-% gate + compact trigger (exported for direct tests).
 *  Failure-tolerant: any error logs and returns — never crashes the
 *  settle path. */
export async function maybeAutoCompactByToken(
  pi: ExtensionAPI,
  ctx: ExtensionContext,
): Promise<void> {
  // The settle timer may fire after the session was replaced or reloaded:
  // the ctx.cwd getter throws "stale" then. Guard the first read — a
  // stale ctx logs one line and skips the gate (the replacement session's
  // own settle re-runs it).
  let cwd: string;
  try {
    cwd = ctx.cwd;
  } catch (e) {
    console.error(
      "[handoff] auto-compact gate: stale ctx, skipping:",
      sanitizeUnknownValue(e),
    );
    return;
  }
  const settings = resolveHandoffSettings(cwd);
  if (!settings.enabled) return;
  const ch = lastActiveChannel ?? getDefaultChannel(loadChannelConfig(cwd));
  if (ch?.type !== "discord") return;
  // A compact/restart op window is open for this channel: let it settle —
  // its own settle re-runs this gate.
  if (isCompacting(ch.id)) return;
  // Handover doc build in flight, or a doc was just written (the fresh
  // window covers the just-seeded session): don't re-compact.
  if (isHandoffInFlight()) return;
  if (isHandoffFreshWindow(settings.storeDir)) return;
  //…[truncated]
[t25] bash {"command": "cd /srv/fleetwork/work/920/packages/bridge/channel && grep -rn \"buildSeedKickoff\" *.ts | grep -v test | head"}
  -> handover.ts:991:export function buildSeedKickoff(
restart-ops.ts:25:  buildSeedKickoff,
restart-ops.ts:237:    buildSeedKickoff(doc, settings.storeDir, defaultHome(), live),
[t25] bash {"command": "cd /srv/fleetwork/work/920/packages/bridge/channel && grep -n \"seedKickoff\\|bootSeed\\|sendUserMessage\" index.ts | head -20"}
  -> (no output)
[t26] read {"path": "/srv/fleetwork/work/920/packages/bridge/channel/restart-ops.ts"}
  -> /**
 * channel/restart-ops.ts — restart-class ops: /reset /restart /undo
 * /redo, the op marker + shutdown scheduling, and handoff mechanism B
 * (restart-into-fresh-session).
 *
 * Extracted from channel/index.ts (god-file split 4/5, 2026-10-20).
 * Pure move — code is verbatim from index.ts; only import/export
 * boundaries were added.
 */
import { spawn } from "node:child_process";
import * as fs from "node:fs";
import * as path from "node:path";
import type {
  ExtensionAPI,
  ExtensionContext,
} from "@earendil-works/pi-coding-agent";

import {
  editDiscordMessage,
  getChannelCursor,
  sendDiscordMessage,
  setChannelCursor,
} from "./discord";
import {
  buildSeedKickoff,
  isHandoffFreshWindow,
  type KickoffLiveState,
  liveKickoffState,
  loadPreviousHandover,
  resolveHandoffSettings,
} from "./handover";
import {
  beginCompacting,
  type CompactingEntry,
  clearCompacting,
  compactingChannels,
  drainQueuedAfterCompact,
  handoffRestartArmed,
  lastActiveChannel,
  type OpLabel,
  opShutdownTimers,
  setHandoffRestartArmed,
  setUserStoppedRun,
} from "./index";
import { armOpTick, opTickLine } from "./live";
import { clearQueuedInbound, midTurnQueues } from "./queue";
import { sanitizeUnknownValue } from "./sanitize";
import { defaultHome } from "./todos";
import {
  type ChannelConfig,
  getChannel,
  getDefaultChannel,
  loadChannelConfig,
  resolveSystemdUnit,
} from "./types";
import { findSessionFile, performRedo, performUndo } from "./undo";

// ─── /undo + /redo: session + file revert ──────────────────────────────
// See channel/undo.ts. The conversation revert works like /reset: pi resumes
// with the LAST line of the session file as leaf, so truncating the file and
// restarting pi takes the revert into effect.

const sleep = (ms: number) =>
  new Promise<void>((resolve) => setTimeout(resolve, ms));

export function safeSessionFile(ctx: ExtensionContext): string | null {
  try {
    return ctx.sessionManager?.getSessionFile?.() ?? null;
  …[truncated]

## 6. Next action
resume: last turn 27 truncated (stopReason=length), zero text
last stated intent (t22): Now let me look at the handover generator's restart path.

## 7. Transcript tail (bounded, verbatim)
…[transcript truncated: 17 older messages dropped]
[assistant t16] [thinking] Let's look at handleInbound and the queuing logic around lines 660-810 to understand when the file mirror write happens.

[toolCall] read {"limit": 150, "offset": 660, "path": "/srv/fleetwork/work/920/packages/bridge/channel/index.ts"}
[assistant t17] [thinking] Let's look at the actual queuing in handleInbound (line 3413) and the re-wake drain (drainRewakeSurvival).

[toolCall] read {"limit": 130, "offset": 3413, "path": "/srv/fleetwork/work/920/packages/bridge/channel/index.ts"}
[assistant t18] [thinking] Let's keep reading handleInbound and find the queuing section (the part that handles the case where a turn is in progress).

[toolCall] read {"limit": 150, "offset": 3543, "path": "/srv/fleetwork/work/920/packages/bridge/channel/index.ts"}
[assistant t19] [thinking] Next, let's look at `queueMidTurnInbound` (which should be calling rewakeAddPending) and `drainRewakeSurvival`. Let me search for these.

[toolCall] bash {"command": "cd /srv/fleetwork/work/920/packages/bridge/channel && grep -n \"function queueMidTurnInbound\\|function drainRewakeSurvival\\|function popOldestQueuedInbound\\|function updateQueuedInbound\" index.ts queue.ts 2>/dev/null | head"}
[assistant t20] [thinking] Let's try reading queue.ts — the entire file (445 lines).

[toolCall] read {"path": "/srv/fleetwork/work/920/packages/bridge/channel/queue.ts"}
[assistant t21] [thinking] Now I understand the queuing path. `queueMidTurnInbound` synchronously calls `rewakeAddPending` right after the push — "the in-memory → file window is the same tick, no await in between." So the file mirror write happens synchronously at queue time.

But the important thing is that `rewakeAddPending` only runs when a message is "queued" (when a turn is in progress). If the bridge is idle, the message is sent directly to pi (sendToPi) — in that case `rewakeCommitDelivered` records it in the delivered set (line 3897).

So the loss window is:
1. Message is received → cursor advances + persists (synchronous).
2. If idle: sendToPi → rewakeCommitDelivered (records in delivered set).
3. If a turn is in progress: queueMidTurnInbound → rewakeAddPending (mirrors to file).

Between step 1 and steps 2/3, if the process dies:
- The cursor is persisted past the message.
- The message is neither in the file's pending nor in the delivered set.
- Next startup: the poll's `after=cursor` doesn't re-fetch it. The scan's `before=cursor` only re-queues webhook messages.

For a human message: lost (amnesia). For a webhook message: the scan re-queues it (backstop).

But wait — there's another subtle point. Let me check `sendToPi` (line 3860) and the re-wake path at agent_end to understand the commit flow.

And the key question for the double-post symptom: the wake card was posted twice (two Discord messages, 21.7 minutes apart). This requires two wake posts. `runRestartWake` runs on every "startup" reason session_start. claimWake's dedup window is 60 seconds. So:
- Startup 1 (T1): claims the wake, posts W1.
- Startup 2 (T2 = T1 + 21.7 min): the lock is stale (>60s), claims the wake, posts W2.

Two startups 21.7 minutes apart = two pi process starts. That's the double-post: the second startup is probably a crash + systemd auto-restart, or a second manual restart. The wake card is posted by design on every real startup — but the operator experiences it as a "double post" because they only intended one restart.

Hmm, but is that a "jarate bug"? The dedup window is 60 seconds for "two racing startups." A second startup 21 minutes later is a separate real startup, and posting its own card is by design (it tells the operator "pi is back online, and here's what's in flight"). But the "double post" symptom is that the same card appears twice in the channel.

Wait, actually — let me re-read the evidence: "The agent channel received the 'pi-bg restart-wake - planned' embed twice, with identical bodies."

"Identical bodies" — both cards are "planned." If the second startup were a crash (unclean), the card should say "unclean." Both being "planned" means both startups had a fresh clean-stop marker. The clean-stop marker is written on every session_shutdown and consumed (deleted) on the next startup. So:
- Startup 1: reads the marker (written by the old process's session_shutdown) → "planned", consumes it.
- Startup 2: reads the marker… wait, if startup 1 consumed it, then startup 2 should see "no marker" → "unclean." Unless startup 1's process ran session_shutdown again before dying (writing a fresh marker).

Hmm, so the sequence is: old process (session_shutdown writes marker) → startup 1 (posts W1, consumes marker) → startup 1's process dies (session_shutdown writes a fresh marker — a clean stop!) → startup 2 (reads fresh marker → "planned", posts W2).

So startup 1's process died cleanly (session_shutdown ran — e.g., another /restart or systemctl restart 21 minutes later). Both cards are "planned." Consistent.

So the double-post is: two real process startups, each posting its own wake card. The 60-second dedup window only covers racing startups, not startups 21 minutes apart. This is by design, but the operator experiences it as a double post.

Hmm, wait, but actually — is it possible that a single restart produced two wake posts? Let me think about `postWakePayload` again:

```ts
for (const route of routes) {
    for (let i = 1; i <= attempts; i+
…[truncated]
[assistant t22] [thinking] Now I understand the commit path. `sendToPi` → `rewakeCommitDelivered` (record in the delivered set, remove from pending) + `dropQueuedInbound` (remove from the in-memory queue).

The comment says: "#180: pi accepted the message — the delivery is committed." — `pi.sendMessage` with `triggerTurn: true, deliverAs: "steer"`. This is a synchronous call to the pi API. If it doesn't throw, the message is "committed" (accepted by pi).

But here's a subtle point: `pi.sendMessage` is accepted by the pi process (same process — the bridge is a pi extension). So "accepted" = queued in pi's in-memory message queue. If the pi process then dies (crash) before the LLM actually processes that message… the message is lost:
- The delivered set has that id (committed).
- The pending file has no entry (pruned).
- The cursor is past it.
- On restart: the scan sees it in the window, but it's in the delivered set → not re-queued. Lost.

This is the amnesia hole! "The message just before a restart doesn't reach the resumed session":
1. The message is received while idle → sendToPi → pi accepts it → committed (delivered set).
2. The pi process dies before the LLM processes the message (crash, or a clean restart via /restart or pi-restart).
3. On restart: the message is in the delivered set → the scan skips it. The cursor is past it → the poll skips it. Lost.

Wait, but in the case of a clean restart (session_shutdown), does pi process pending messages before shutdown? `deliverAs: "steer"` — the message is steered into the in-progress run, or starts a new turn. If the process is restarted (systemctl restart → SIGTERM), pi's session_shutdown runs… does it drain the pending messages? Probably not — it just shuts down. The steered message is lost.

Hmm, but actually, in the case of a planned restart via pi-restart: the operator runs pi-restart while the agent is idle (or in the middle of a turn). If a message arrived just before the restart (the agent received it, pi accepted it, a turn started), and then the restart happens 5 seconds later — the turn is interrupted (SIGTERM). The message is in pi's session file (the transcript) but… the resumed session — does pi resume the same session? pi-restart restarts pi.service — does the new pi process resume the same session?

This is where the handover generator comes in (task item 3): "Does the restart handover capture the transcript up to the last delivered message, and does it explicitly name lost/replayed messages?"

Let me look at handover.ts — the RESTART path.

[text] 

Now let me look at the handover generator's restart path.


[toolCall] read {"path": "/srv/fleetwork/work/920/packages/bridge/channel/handover.ts"}
[assistant t23] [thinking] OK, now I understand the handover mechanism. This is the COMPACT path (mechanism A + mechanism B's boot seed). The RESTART path — the part that seeds the new session after a restart — is `buildSeedKickoff` + `liveKickoffState`. This gets called at startup when a handover document exists (mechanism B, PR2).

Now, the key question in task item 3: "Does the restart handover capture the transcript up to the last delivered message, and does it explicitly name lost/replayed messages?"

Looking at the boot seed: it reads the handover document (written at compact time) + live state (jobs, tasks, todo board). It does NOT explicitly name lost/replayed messages. The "Last ask" line comes from the document's "Last user asks" section — which is computed at compact time (the #291 fix: an ask is PENDING only if no assistant response exists within the captured range).

So for the RESTART path: if the restart happens without a compact (e.g., a planned pi-restart without compaction), the boot seed uses the last handover document (which could be stale — from the previous compact). The transcript in that document is from the compact time, not the last delivered message. Messages that arrived after the document was written (and were lost in the restart) are not named in the seed.

Wait, but when does the boot seed actually fire? Let me look for where buildSeedKickoff is called — the startup path in index.ts. Let me search.

[toolCall] bash {"command": "cd /srv/fleetwork/work/920/packages/bridge/channel && grep -n \"buildSeedKickoff\\|liveKickoffState\\|lastHandoffAt\\|isHandoffFreshWindow\" index.ts | head -20"}
[assistant t24] [thinking] Let me look at the context around line 3323 — the path where the boot seed gets triggered.

[toolCall] read {"limit": 120, "offset": 3270, "path": "/srv/fleetwork/work/920/packages/bridge/channel/index.ts"}
[assistant t25] [thinking] That's the auto-compact gate, not the boot seed. Let me look for where the boot seed (buildSeedKickoff) is actually being called — maybe it's in a different file, or perhaps it's being called via a different name. Let me search across the entire channel directory.

[toolCall] bash {"command": "cd /srv/fleetwork/work/920/packages/bridge/channel && grep -rn \"buildSeedKickoff\" *.ts | grep -v test | head"}
[toolCall] bash {"command": "cd /srv/fleetwork/work/920/packages/bridge/channel && grep -n \"seedKickoff\\|bootSeed\\|sendUserMessage\" index.ts | head -20"}
[assistant t26] [thinking] Let's take a look at restart-ops.ts — the RESTART path of the handover generator.

[toolCall] read {"path": "/srv/fleetwork/work/920/packages/bridge/channel/restart-ops.ts"}
[assistant t27] [thinking] Now I have a good grasp of the overall picture of the RESTART path (mechanism B):
- Handoff-eligible compact → restart operation → move session file → new session → `consumeOpMarker` → `seedFromHandoffDoc` → `buildSeedKickoff(doc, ...)` + `liveKickoffState`.
- The seed is a 5-line digest from the handoff document + live state. It does not explicitly name lost/replayed messages.

For a planned `pi-restart` (not via /compact handoff), the op marker is not "handoff" — the seed is not applied. The resumed session is the same session (pi -c continues the latest .jsonl). The wake card is the only "handoff" signal.

So for the RESTART path (pi-restart):
1. The session continues (same session file).
2. The wake card is posted (restart-wake).
3. The rewake survival drain re-queues pending entries.
4. The startup history scan re-queues uncommitted webhook posts.
5. The first backfill poll replays messages from after the cursor.

Messages that are lost at the restart boundary (amnesia):
- Case A: A message was received, the cursor advanced, it was sent directly to pi (sendToPi committed it to the delivered set), but pi died before processing it. On restart: the delivered set has the id → the scan skips it; the cursor is past it → the poll skips it. Lost. (The message is in pi's in-memory queue but not in the session file — actually, wait, is that right? pi.sendMessage with triggerTurn — does pi persist the message to the session file immediately? If pi persists to the session file at the moment of sendMessage, then the resumed session should have it in the transcript. Let me think… pi is an agent harness; sendMessage with triggerTurn starts a turn. The message should be appended to the session file (jsonl) when the turn starts. If the process dies before the turn starts (message is in the in-memory queue but the turn hasn't started), the message is not in the session file. That's the loss window.)

- Case B: A message was received, the cursor advanced, it was queued (rewakeAddPending wrote to the file), but the process died mid-file-write (tmp orphaned). The file doesn't have it. Scan: only webhook messages are re-queued. Human messages are lost.

- Case C: A message was posted while pi was down (between the old process's death and the new process's first successful poll). The first backfill poll fetches after=cursor → it gets delivered. ✓ Covered (as long as the poll eventually succeeds).

- Case D: A message was received and queued, the file write succeeded, the process died. The drain re-queues it. It's delivered at the next agent_end. ✓ Covered by #180.

The operator's "half the time" — hmm. Let me think about what happens in a planned pi-restart:

pi-restart:
1. `systemd-run --on-active=90s pi-postcheck.sh`
2. `sleep 5; systemctl --user restart pi.service`

systemctl restart: SIGTERM to the old process. pi handles SIGTERM → session_shutdown. During session_shutdown:
- The in-memory queue is drained (clearQueuedInbound with keepFile — the file is preserved).
- writeCleanStop writes the clean-stop marker.

But what about messages that were sent directly to pi (sendToPi) but whose turns hadn't started yet? They're in pi's in-memory queue. On SIGTERM, does pi flush pending messages to the session file? Probably not — the process just dies. So those messages are lost:
- The cursor is past them (persisted at receipt).
- The delivered set has their ids (rewakeCommitDelivered at sendToPi time).
- Not in the rewake file (no pending entry — it was sent directly, not queued).
- On restart: the scan sees them in the window (before=cursor), but they're in the delivered set → skipped. The poll: after=cursor → not fetched. Lost.

Wait, but are they really lost from the session? If pi persisted them to the session file at the moment of sendMessage… let me check how pi handles sendMessage. Actually, the bridge is a pi extension; pi.sendMessage sends to the pi session. In pi's architecture (agent-session), sendMessage with triggerTurn appe
…[truncated]

## 8. Usage
turns: 28
last usage: input=79159 output=16384 total=95543
compactions: 0
model: helium/Qwen3.8
