# Deterministic handoff - fleetwork-922 - 2026-10-29T06:41:21Z

## 0. Trigger
stop-length (last turn 6 stopReason=length, zero text blocks, thinking 61739 chars)

## 1. Original brief (verbatim)
scope-delta: CONTINUATION of t920 (diagnose+fix for jarate #306). t920 died empty_final mid-diagnosis: clean tree, zero commits, last words "Now let me look at the handover generator's restart path." Its partial findings survive ONLY in its session: /srv/fleetwork/work/920/.fleetwork/session.jsonl (372KB) - READ IT FIRST (it is your own user's file, monky) and carry forward everything it established (files read, suspects ranked, code paths mapped). Do not re-read from zero. NO wall (op ruling 2026-10-29, 4th: no wall unless a genuine external bound - there is none here).

SCOPE (updated since t920 was briefed - the issue grew): jarate #306 now covers THREE handover defect classes, all in the handoff generator / restart-wake path:
1. RESTART BOUNDARY (original t920 scope): after a planned pi restart the agent channel received the 'restart-wake - planned' embed TWICE; the second delivery's Discord snowflake (1565239434729754655) is OLDER than the first's (1565244903061987410) - an older event replayed after the newer one. Recurring symptom: the message just before/during a restart does not reach the resumed session, silently.
2. SIZE-GUARD HEAD-CONDENSE (jimmy's incoherence, root-caused by warden 2026-10-29 ~06:30Z): a 6.5h/212k-token compaction produced a handover whose transcript section was "condensed by size guard" - the HEAD of the transcript (where the active task was framed) was cut, only the tail survived. The resumed agent had zero task framing. Evidence: jimmy's handover 2026-10-29T05:59:26Z (session 01a184d4 -> 01a1863d). The condenser must protect the head (mission/in-flight/last-ask + task framing) - condense the middle, or size-budget so the framing always survives.
3. (Reference only, do not fix here): #291 last-turn drop is already fixed at f82fa69d - do not regress it.

DELIVERABLE (one PR, verdict-first - land the artifact BEFORE any verification tail):
- DIAGNOSIS section in the PR body: root cause per symptom (the double restart-wake post; the out-of-order replay / last-message drop; the size-guard head-condense) with the exact code locations.
- FIXES: (a) idempotent restart-wake post (one embed per restart, or a dedupe key the consumer ignores repeats of); (b) delivery-at-most-once + in-order for channel messages across a restart (persistent seen-message-id set in the bridge state JSON, snowflake-ordered); (c) size guard that protects the transcript head - mission/in-flight/last-ask + the active task framing always survive, condense the middle; (d) regression tests for all three (the bridge test pattern - discord.test.ts et al.).
- If a root cause turns out to be OUTSIDE jarate (e.g. Discord gateway replay): document it in the PR with the evidence and land the bridge-side dedupe as the mitigation.

GATES (report each as a check line, exactly as CI runs them): bunx biome check . (CI biome job), the CI test job command (read .github/workflows/ci.yml), the bin job as CI runs it, the size job as CI runs it.

PROCESS: repo marzukia/jarate, base main (22d8bf58). Commit early per milestone - the diagnosis write-up is a commit-able artifact, commit it before the fix work. Push the branch, open the PR (body cites issue #306 + the three defect classes with their evidence lines, worker: monky, reviewer pass to follow). END once the PR is open - no CI waits, no poll loops. Commits factual, NO Co-authored-by/AI trailers. model_origin: explicit
model_origin: explicit

## 2. Git state
branch: HEAD
head: 22d8bf58f3ceb1aba1f3d848f77fc4e984fd6699
dirty: no

## 3. Files touched
read: /srv/fleetwork/work/922/packages/bridge/channel/restart-wake.ts, /srv/fleetwork/work/920/.fleetwork/handoff.md, /tmp/t920_assistant.txt
modified: (none)

## 4. Decisions (marked lines only)
(none)

## 5. Last tool calls (truncated results)
[t0] bash {"command": "cd /srv/fleetwork/work/922 && ls -la && git status && git log --oneline -5 && git branch -a | head -20"}
  -> total 144
drwxrwsr-x 1 hallmon fleetwork   482 Oct 29 17:35 .
drwxrwsr-x 1 hallmon fleetwork  4468 Oct 29 17:35 ..
-rw-rw-r-- 1 hallmon fleetwork  4912 Oct 29 17:35 AGENTS.md
drwxrwsr-x 1 hallmon fleetwork    30 Oct 29 17:35 assets
drwxrwsr-x 1 hallmon fleetwork    68 Oct 29 17:35 bin
-rw-rw-r-- 1 hallmon fleetwork   825 Oct 29 17:35 biome.json
-rw-rw-r-- 1 hallmon fleetwork   387 Oct 29 17:35 bunfig.toml
-rw-rw-r-- 1 hallmon fleetwork 52346 Oct 29 17:35 bun.lock
-rw-rw-r-- 1 hallmon fleetwork  5956 Oct 29 17:35 CHANGELOG.md
-rw-rw-r-- 1 hallmon fleetwork  3269 Oct 29 17:35 CONTRIBUTING.md
drwxrwsr-x 1 hallmon fleetwork   246 Oct 29 17:35 deploy
drwxrwsr-x 1 hallmon fleetwork   250 Oct 29 17:35 dispatch
drwxrwsr-x 1 hallmon fleetwork   228 Oct 29 17:35 docs
drwxrwsr-x 1 hallmon fleetwork    24 Oct 29 17:35 extensions
drwxrws--- 1 hallmon fleetwork   152 Oct 29 17:35 .fleetwork
-rw-rw-r-- 1 hallmon fleetwork    48 Oct 29 17:35 .git
drwxrwsr-x 1 hallmon fleetwork    20 Oct 29 17:35 .githooks
drwxrwsr-x 1 hallmon fleetwork    18 Oct 29 17:35 .github
-rw-rw-r-- 1 hallmon fleetwork   118 Oct 29 17:35 .gitignore
-rwxrwxr-x 1 hallmon fleetwork 12592 Oct 29 17:35 install.sh
drwxrwsr-x 1 hallmon fleetwork   216 Oct 29 17:35 issues
-rw-rw-r-- 1 hallmon fleetwork   705 Oct 29 17:35 package.json
drwxrwsr-x 1 hallmon fleetwork    12 Oct 29 17:35 packages
-rw-rw-r-- 1 hallmon fleetwork  4664 Oct 29 17:35 RCA.md
-rw-rw-r-- 1 hallmon fleetwork  6863 Oct 29 17:35 README.md
-rw-rw-r-- 1 hallmon fleetwork 13649 Oct 29 17:35 REPORT.md
drwxrwsr-x 1 hallmon fleetwork    54 Oct 29 17:35 scripts
-rw-rw-r-- 1 hallmon fleetwork   411 Oct 29 17:35 size-ratchet.json
drwxrwsr-x 1 hallmon fleetwork    14 Oct 29 17:35 skills
drwxrwsr-x 1 hallmon fleetwork    32 Oct 29 17:35 templates
Not currently on any branch.
nothing to commit, working tree clean
22d8bf58 feat(bridge): channel-send — in-turn post to the agent's own channel under its own bot identity (#305)
45a68339 setup: re-add the 15-min wat…[truncated]
[t0] bash {"command": "ls -la /srv/fleetwork/work/920/.fleetwork/ && wc -c /srv/fleetwork/work/920/.fleetwork/session.jsonl"}
  -> total 464
drwxrws--- 1 hallmon fleetwork    310 Oct 29 17:33 .
drwxrwsr-x 1 hallmon fleetwork    482 Oct 29 17:19 ..
-rw-r--r-- 1 hallmon fleetwork     41 Oct 29 17:19 base_commit
-rw------- 1 monky   fleetwork   3570 Oct 29 17:19 brief
-rw-r--r-- 1 hallmon fleetwork    182 Oct 29 17:19 gitenv
-rw-rw---- 1 monky   fleetwork   1001 Oct 29 17:33 handoff.json
-rw-rw---- 1 monky   fleetwork  34211 Oct 29 17:33 handoff.md
-rw-rw---- 1 monky   fleetwork    509 Oct 29 17:33 live.json
-rw-rw---- 1 monky   fleetwork    712 Oct 29 17:33 llm-capture.json
-rw-rw---- 1 monky   fleetwork    494 Oct 29 17:33 llm-stream.json
-rw------- 1 monky   fleetwork     22 Oct 29 17:19 piargs
-rwxr-xr-x 1 hallmon fleetwork  20017 Oct 29 17:19 run-wrapper.sh
-rw-rw---- 1 monky   fleetwork     84 Oct 29 17:33 salvage-manifest.txt
-rw-rw---- 1 monky   fleetwork 372054 Oct 29 17:33 session.jsonl
-rw-rw---- 1 monky   fleetwork     73 Oct 29 17:33 tailer.log
-rw-rw---- 1 monky   fleetwork     12 Oct 29 17:33 terminal
372054 /srv/fleetwork/work/920/.fleetwork/session.jsonl
[t1] bash {"command": "cd /srv/fleetwork/work/920/.fleetwork && python3 -c \"\nimport json\nwith open('session.jsonl') as f:\n    for i, line in enumerate(f):\n        line = line.strip()\n        if not line: continue\n        try:\n            obj = json.loads(line)\n        except Exception as e:\n            print(i, 'PARSE_ERR', e); continue\n        t = obj.get('type')\n        role = obj.get('message', {}).get('role') if isinstance(obj.get('message'), dict) else None\n        keys = list(obj.keys())\n        print(i, t, role, keys[:8])\n\" | head -80"}
  -> 0 session None ['type', 'version', 'id', 'timestamp', 'cwd']
1 model_change None ['type', 'id', 'parentId', 'timestamp', 'provider', 'modelId']
2 thinking_level_change None ['type', 'id', 'parentId', 'timestamp', 'thinkingLevel']
3 message user ['type', 'id', 'parentId', 'timestamp', 'message']
4 message assistant ['type', 'id', 'parentId', 'timestamp', 'message']
5 message toolResult ['type', 'id', 'parentId', 'timestamp', 'message']
6 message toolResult ['type', 'id', 'parentId', 'timestamp', 'message']
7 message assistant ['type', 'id', 'parentId', 'timestamp', 'message']
8 message toolResult ['type', 'id', 'parentId', 'timestamp', 'message']
9 message toolResult ['type', 'id', 'parentId', 'timestamp', 'message']
10 message assistant ['type', 'id', 'parentId', 'timestamp', 'message']
11 message toolResult ['type', 'id', 'parentId', 'timestamp', 'message']
12 message toolResult ['type', 'id', 'parentId', 'timestamp', 'message']
13 message assistant ['type', 'id', 'parentId', 'timestamp', 'message']
14 message toolResult ['type', 'id', 'parentId', 'timestamp', 'message']
15 message toolResult ['type', 'id', 'parentId', 'timestamp', 'message']
16 message assistant ['type', 'id', 'parentId', 'timestamp', 'message']
17 message toolResult ['type', 'id', 'parentId', 'timestamp', 'message']
18 message assistant ['type', 'id', 'parentId', 'timestamp', 'message']
19 message toolResult ['type', 'id', 'parentId', 'timestamp', 'message']
20 message assistant ['type', 'id', 'parentId', 'timestamp', 'message']
21 message toolResult ['type', 'id', 'parentId', 'timestamp', 'message']
22 message toolResult ['type', 'id', 'parentId', 'timestamp', 'message']
23 message assistant ['type', 'id', 'parentId', 'timestamp', 'message']
24 message toolResult ['type', 'id', 'parentId', 'timestamp', 'message']
25 message toolResult ['type', 'id', 'parentId', 'timestamp', 'message']
26 message assistant ['type', 'id', 'parentId', 'timestamp', 'message']
27 message toolResult ['type', 'id', 'pa…[truncated]
[t2] bash {"command": "cd /srv/fleetwork/work/920/.fleetwork && python3 -c \"\nimport json\nwith open('session.jsonl') as f:\n    lines = [l for l in f if l.strip()]\nout = []\nfor i, line in enumerate(lines):\n    obj = json.loads(line)\n    if obj.get('type') != 'message': continue\n    msg = obj['message']\n    role = msg.get('role')\n    if role == 'assistant':\n        for c in msg.get('content', []):\n            if c.get('type') == 'text':\n                out.append(f'--- [{i}] ASSISTANT TEXT ---\\n' + c['text'])\n            elif c.get('type') == 'toolCall':\n                args = c.get('arguments', {})\n                s = json.dumps(args)\n                if len(s) > 600: s = s[:600] + '...'\n                out.append(f'--- [{i}] TOOL {c.get(\\\"name\\\")} ---\\n{s}')\n    elif role == 'user':\n        pass\ntext = '\\n'.join(out)\nprint(len(text))\nopen('/tmp/t920_assistant.txt','w').write(text)\n\""}
  -> 5168
[t3] read {"path": "/tmp/t920_assistant.txt"}
  -> --- [4] TOOL bash ---
{"command": "ls /srv/fleetwork/work/920 && ls /srv/fleetwork/work/920/packages/bridge 2>/dev/null | head -50"}
--- [4] TOOL bash ---
{"command": "cd /srv/fleetwork/work/920 && git log --oneline -5 && git status --short | head"}
--- [7] TOOL bash ---
{"command": "cd /srv/fleetwork/work/920 && ls scripts/ packages/bridge/channel/ | head -60 && grep -rn \"restart-wake\" --include=\"*.ts\" --include=\"*.sh\" --include=\"*.json\" -l . | head -20"}
--- [7] TOOL bash ---
{"command": "cd /srv/fleetwork/work/920 && ls ~/.pi/agent 2>/dev/null; ls ~/scripts 2>/dev/null | head"}
--- [10] TOOL bash ---
{"command": "cd /srv/fleetwork/work/920 && ls ~/scripts/ && cat ~/scripts/pi-restart 2>/dev/null | head -80"}
--- [10] TOOL read ---
{"path": "/srv/fleetwork/work/920/packages/bridge/channel/restart-wake.ts"}
--- [13] ASSISTANT TEXT ---


Now let me look at the bridge's message delivery path and how it handles reconnects.



--- [13] TOOL bash ---
{"command": "cd /srv/fleetwork/work/920/packages/bridge/channel && wc -l index.ts discord.ts queue.ts handover.ts live.ts restart-ops.ts restart-queue.ts"}
--- [13] TOOL bash ---
{"command": "cd /srv/fleetwork/work/920/packages/bridge/channel && grep -n \"reconnect\\|resume\\|replay\\|history\\|seen\" index.ts | head -40"}
--- [16] TOOL read ---
{"path": "/srv/fleetwork/work/920/packages/bridge/channel/index.ts", "offset": 1580, "limit": 120}
--- [18] TOOL read ---
{"path": "/srv/fleetwork/work/920/packages/bridge/channel/index.ts", "offset": 1700, "limit": 180}
--- [20] TOOL bash ---
{"command": "cat ~/scripts/pi-postcheck.sh"}
--- [20] TOOL bash ---
{"command": "cd /srv/fleetwork/work/920 && grep -rn \"restart-wake\\|restart_wake\\|restartWake\" dispatch/ scripts/ 2>/dev/null | head -20"}
--- [23] ASSISTANT TEXT ---


Now let me look at the re-queue scan and the cursor/dedup machinery.



--- [23] TOOL bash ---
{"command": "cd /srv/fleetwork/work/920/packages/bridge/channel && grep -rn \"scanUndeliveredBgInbounds\…[truncated]
[t4] read {"path": "/srv/fleetwork/work/920/.fleetwork/handoff.md"}
  -> # Deterministic handoff - fleetwork-920 - 2026-10-29T06:33:40Z

## 0. Trigger
stop-length (last turn 27 stopReason=length, zero text blocks, thinking 65258 chars)

## 1. Original brief (verbatim)
JOB: jarate issue #306 - restart-boundary message handling: DIAGNOSE + FIX (one PR if the root cause is in jarate; documented finding + minimal mitigation if not).

CONTEXT (self-contained): operator complaint 2026-10-29: 'this restart handover sucks, half the time you miss the last message and have amnesia'. Issue #306 (marzukia/jarate) carries the full symptom write-up. The COMPACT path amnesia (#291) is fixed at f82fa69d and live - a 2026-10-29 compact resume was clean. The remaining class is the RESTART boundary:

EVIDENCE (today, hydrogen, jarate main 22d8bf58): after the planned pi restart, the agent channel received the 'pi-bg restart-wake - planned' embed TWICE, identical body. The second delivery's Discord snowflake (1565239434729754655) is OLDER than the first's (1565244903061987410) - an older event was replayed after the newer one. Recurring operator-observed second symptom: the message just before (or during) a restart does not reach the resumed session - the resume acts without it, silently.

DIAGNOSE (do not guess - read the code paths, then prove):
1. The restart scheduler + post-wake path: ~/scripts/pi-restart is tracked in the repo (issue #260) - find where the 'restart-wake - planned' embed is posted (the systemd one-shot / postcheck), and whether anything can post it twice per restart (double one-shot, postcheck retry, both the scheduler and a reconnect handler posting).
2. The gateway reconnect / message delivery path in the bridge (packages/bridge): after the pi process restarts, does the bridge replay channel history (REST fetch of recent messages on connect) without a seen-message-id dedupe set? That would explain the out-of-order replay (old snowflake delivered after the new one) AND could double-deliver. Check how incoming channel messages are buff…[truncated]
[t5] read {"path": "/srv/fleetwork/work/922/packages/bridge/channel/restart-wake.ts"}
  -> // restart-wake — post-restart wake (issue #111, P0).
//
// When the pi process really starts (session_start reason "startup"), the
// bridge posts ONE "back online" message to the agent's channel. Shape
// (2026-10-19 EMBED CARD family; 2026-10-21, Andryo: the visible `[bg:`
// content prefix is dropped - no visible `[bg:` lines in agent channels):
//   - content is EMPTY; the card is the ONE embed: title
//     `restart-wake · planned|unplanned` (green/red), a short
//     description, the in-flight ticket rows as an `in-flight` field
//     (multiline value, rows are `run profile elapsed`), and a footer
//     with the producer name (no timestamp)
//   - the EMBED AUTHOR is `pi-bg restart-wake · planned|unplanned` -
//     the machine-wake MARKER (isBgCallbackBody classifies the
//     serialized `Author: pi-bg`). The WAKE itself rides webhook_id:
//     isBgWebhook exempts any webhook-posted message from the
//     other-bot filter, so the post lands as an agent turn
//
// Guards (issue #111):
//   - never blocks startup: the caller fires and forgets (void + catch);
//     the post itself is bounded — 3 attempts, 15s hard timeout each,
//     3s*i backoff (the pi-bg webhook pattern, bg_post)
//   - no channel with a bot token or webhook (dev runs) = silent no-op
//   - two startups racing within 60s post once (atomic O_EXCL claim)
//   - hot reload / session switch (reason != "startup") never posts
//
// Marker layout (runtime state dir, <agent-cwd>/.tmp on the live boxes):
//   clean-stop        last session_shutdown timestamp (written on every
//                     shutdown, consumed on the next process start)
//   restart-wake.lock last wake claim (epoch ms), 60s dedup window
//
// Out of scope here (documented follow-ups, see PR body):
//   - P1-2/P1-3 cursor-replay holes can still lose queued inbounds across
//     a crash; this wake only tells the operator the work is in flight.
//   - actually RESUMING the runs (re-dispatch into the same worktree,
//    …[truncated]
[t5] bash {"command": "cd /srv/fleetwork/work/922/packages/bridge/channel && wc -l *.ts | sort -n | tail -25 && ls"}
  -> 544 restart-queue.test.ts
    587 tools.ts
    594 tasks.ts
    632 diff.test.ts
    646 restart-wake.test.ts
    650 tasks.test.ts
    675 restart-ops.ts
    716 format.test.ts
    849 format.ts
    886 diff.ts
   1148 live.test.ts
   1151 undo.ts
   1177 handover.ts
   1218 queue.test.ts
   1273 commands.ts
   1300 undo.test.ts
   1548 discord.test.ts
   1643 restart-ops.test.ts
   1795 tools.test.ts
   2072 commands.test.ts
   2103 discord.ts
   2496 handover.test.ts
   3961 index.ts
   4617 index.test.ts
  44033 total
btw.test.ts
btw.ts
censor.test.ts
censor.ts
chokepoint.test.ts
commands.test.ts
commands.ts
context.test.ts
context.ts
diff.test.ts
diff.ts
discord.test.ts
discord.ts
durable-store.test.ts
durable-store.ts
fleet-run.ts
format.test.ts
format.ts
frame.ts
handover.test.ts
handover.ts
image-optimizer.test.ts
image-optimizer.ts
index.test.ts
index.ts
jarate.test.ts
jarate.ts
jobs.test.ts
jobs.ts
live.test.ts
live.ts
queue.test.ts
queue.ts
restart-ops.test.ts
restart-ops.ts
restart-queue.test.ts
restart-queue.ts
restart-wake.test.ts
restart-wake.ts
sanitize.test.ts
sanitize.ts
secret-patterns.test.ts
secret-patterns.ts
sleep.test.ts
sleep.ts
tasks.test.ts
tasks.ts
todos.test.ts
todos.ts
tools.test.ts
tools.ts
transcribe.test.ts
transcribe.ts
transcript.ts
types.ts
undo.test.ts
undo.ts
usage.test.ts
usage.ts
voice.test.ts
voice.ts
worktree.test.ts
worktree.ts

## 6. Next action
resume: last turn 6 truncated (stopReason=length), zero text
last stated intent (t5): t920's handoff is rich. Now let me read the actual code in this checkout, starting with the smaller files t920 mapped.

## 7. Transcript tail (bounded, verbatim)
[user] scope-delta: CONTINUATION of t920 (diagnose+fix for jarate #306). t920 died empty_final mid-diagnosis: clean tree, zero commits, last words "Now let me look at the handover generator's restart path." Its partial findings survive ONLY in its session: /srv/fleetwork/work/920/.fleetwork/session.jsonl (372KB) - READ IT FIRST (it is your own user's file, monky) and carry forward everything it established (files read, suspects ranked, code paths mapped). Do not re-read from zero. NO wall (op ruling 2026-10-29, 4th: no wall unless a genuine external bound - there is none here).

SCOPE (updated since t920 was briefed - the issue grew): jarate #306 now covers THREE handover defect classes, all in the handoff generator / restart-wake path:
1. RESTART BOUNDARY (original t920 scope): after a planned pi restart the agent channel received the 'restart-wake - planned' embed TWICE; the second delivery's Discord snowflake (1565239434729754655) is OLDER than the first's (1565244903061987410) - an older event replayed after the newer one. Recurring symptom: the message just before/during a restart does not reach the resumed session, silently.
2. SIZE-GUARD HEAD-CONDENSE (jimmy's incoherence, root-caused by warden 2026-10-29 ~06:30Z): a 6.5h/212k-token compaction produced a handover whose transcript section was "condensed by size guard" - the HEAD of the transcript (where the active task was framed) was cut, only the tail survived. The resumed agent had zero task framing. Evidence: jimmy's handover 2026-10-29T05:59:26Z (session 01a184d4 -> 01a1863d). The condenser must protect the head (mission/in-flight/last-ask + task framing) - condense the middle, or size-budget so the framing always survives.
3. (Reference only, do not fix here): #291 last-turn drop is already fixed at f82fa69d - do not regress it.

DELIVERABLE (one PR, verdict-first - land the artifact BEFORE any verification tail):
- DIAGNOSIS section in the PR body: root cause per symptom (the double restart-wake post; the out-of-order replay / last-message drop; the size-guard head-condense) with the exact code locations.
- FIXES: (a) idempotent restart-wake post (one embed per restart, or a dedupe key the consumer ignores repeats of); (b) delivery-at-most-once + in-order for channel messages across a restart (persistent seen-message-id set in the bridge state JSON, snowflake-ordered); (c) size guard that protects the transcript head - mission/in-flight/last-ask + the active task framing always survive, condense the middle; (d) regression tests for all three (the bridge test pattern - discord.test.ts et al.).
- If a root cause turns out to be OUTSIDE jarate (e.g. Discord gateway replay): document it in the PR with the evidence and land the bridge-side dedupe as the mitigation.

GATES (report each as a check line, exactly as CI runs them): bunx biome check . (CI biome job), the CI test job command (read .github/workflows/ci.yml), the bin job as CI runs it, the size job as CI runs it.

PROCESS: repo marzukia/jarate, base main (22d8bf58). Commit early per milestone - the diagnosis write-up is a commit-able artifact, commit it before the fix work. Push the branch, open the PR (body cites issue #306 + the three defect classes with their evidence lines, worker: monky, reviewer pass to follow). END once the PR is open - no CI waits, no poll loops. Commits factual, NO Co-authored-by/AI trailers. model_origin: explicit
model_origin: explicit
[assistant t0] [thinking] Let's start by reading the session file from t920, and then check the current state of the repository.

[toolCall] bash {"command": "cd /srv/fleetwork/work/922 && ls -la && git status && git log --oneline -5 && git branch -a | head -20"}
[toolCall] bash {"command": "ls -la /srv/fleetwork/work/920/.fleetwork/ && wc -c /srv/fleetwork/work/920/.fleetwork/session.jsonl"}
[assistant t1] [thinking] First, let's read the session file from t920. It's 372KB. Let's check the structure and extract the important parts — the findings, the files that were read, the suspects that were ranked, the code paths that were mapped.

[toolCall] bash {"command": "cd /srv/fleetwork/work/920/.fleetwork && python3 -c \"\nimport json\nwith open('session.jsonl') as f:\n    for i, line in enumerate(f):\n        line = line.strip()\n        if not line: continue\n        try:\n            obj = json.loads(line)\n        except Exception as e:\n            print(i, 'PARSE_ERR', e); continue\n        t = obj.get('type')\n        role = obj.get('message', {}).get('role') if isinstance(obj.get('message'), dict) else None\n        keys = list(obj.keys())\n        print(i, t, role, keys[:8])\n\" | head -80"}
[assistant t2] [thinking] Let's extract the assistant's text messages and tool calls from the session to get a grasp of the investigation results. I'll write a Python script that dumps the assistant's text and tool calls (name + input summary) in order.

[toolCall] bash {"command": "cd /srv/fleetwork/work/920/.fleetwork && python3 -c \"\nimport json\nwith open('session.jsonl') as f:\n    lines = [l for l in f if l.strip()]\nout = []\nfor i, line in enumerate(lines):\n    obj = json.loads(line)\n    if obj.get('type') != 'message': continue\n    msg = obj['message']\n    role = msg.get('role')\n    if role == 'assistant':\n        for c in msg.get('content', []):\n            if c.get('type') == 'text':\n                out.append(f'--- [{i}] ASSISTANT TEXT ---\\n' + c['text'])\n            elif c.get('type') == 'toolCall':\n                args = c.get('arguments', {})\n                s = json.dumps(args)\n                if len(s) > 600: s = s[:600] + '...'\n                out.append(f'--- [{i}] TOOL {c.get(\\\"name\\\")} ---\\n{s}')\n    elif role == 'user':\n        pass\ntext = '\\n'.join(out)\nprint(len(text))\nopen('/tmp/t920_assistant.txt','w').write(text)\n\""}
[assistant t3] [thinking] The assistant's text is only 5KB. Let me try reading it.

[toolCall] read {"path": "/tmp/t920_assistant.txt"}
[assistant t4] [thinking] Now I've got a handle on t920's exploration map. What was read:
- `packages/bridge/channel/restart-wake.ts` (entire file)
- `packages/bridge/channel/index.ts` (multiple ranges: 1580-1700, 1700-1880, 660-810, 3413-3543, 3543-3693, 3855-3985, 3270-3390)
- `packages/bridge/channel/discord.ts` (1-120, 200-380, 380-500, 488-708)
- `packages/bridge/channel/restart-queue.ts` (entire file)
- `packages/bridge/channel/queue.ts` (entire file)
- `packages/bridge/channel/handover.ts` (entire file)
- `~/scripts/pi-postcheck.sh`
- `~/scripts/pi-restart`

Grep targets: reconnect/resume/replay/history/seen in index.ts; lastMessageId/cursor in discord.ts; pollDiscord/deliverInboundMessage; rewakeAddPending/rewakeCommitDelivered/rewakeRemovePending; midTurnQueues/queueInbound/handleInbound/sendToPi/popOldestQueuedInbound/drainRewakeSurvival; buildSeedKickoff/liveKickoffState/lastHandoffAt/isHandoffFreshWindow; seedKickoff/bootSeed/sendUserMessage.

t920 died right after reading all of handover.ts and grepping for buildSeedKickoff. Its final words were "Now let me look at the handover generator's restart path."

Also, there's a handoff.md (34KB) in the .fleetwork directory — that's the session's handoff document, and it might contain a summary of the investigation findings. Let me read it.

[text] 

t920's session map is clear. Now let me read its handoff doc (34KB) which likely carries the findings summary.


[toolCall] read {"path": "/srv/fleetwork/work/920/.fleetwork/handoff.md"}
[assistant t5] [thinking] Excellent — t920's handoff is very information-rich. Key findings so far:

**Map of t920's investigation findings:**

1. **Restart wake path**: `runRestartWake` runs on every "startup" reason session_start; `claimWake`'s dedup window is 60 seconds (for competing startups). Double-post = two actual process startups, each posting its own wake card. The 60-second dedup window only covers competing startups, not startups 21 minutes apart. The clean stop marker is written on session_shutdown and consumed on the next startup.

2. **Message loss (amnesia) at the restart boundary**:
   - Case A: Message is received while idle → sendToPi (commit to delivered set) → pi dies before the turn starts → on restart, the delivered set has that id → scan skips; cursor is past it → poll skips. Lost.
   - Case B: Message is received, cursor advances, gets queued (rewakeAddPending writes to file), process dies mid-write (tmp orphaned) → file has no entry → scan only re-queues webhook messages → human messages are lost.
   - Case C: Message is posted while pi is down → first backfill poll fetches with after=cursor → delivered. Covered.
   - Case D: Message is received and queued, file write succeeded, process dies → drain re-queues → delivered at next agent_end. Covered by #180.

3. **Handover RESTART path**: mechanism B (restart-into-fresh-session) — `buildSeedKickoff` + `liveKickoffState`, called from restart-ops.ts:237. For a planned pi-restart (not via /compact handoff), no op marker → no seed; the session continues with the same session file; the wake card is the only handover signal.

4. **Reconnect/replay**: Need to check `scanUndeliveredBgInbounds` (startup history scan, before=cursor) and the first backfill poll (after=cursor). t920 read lines 488-708 of discord.ts (pollDiscord/deliverInboundMessage) and lines 200-380 (cursor mechanism).

Now, the scope has expanded to three defect classes:
1. **Restart boundary**: double restart-wake post (older snowflake replayed after newer) + last-message loss.
2. **Size-guard head-condense**: a 6.5-hour/212k-token compaction produced a handover whose transcript section was "condensed by the size guard" — the head of the transcript (where the active task was framed) was cut, only the tail survived. The condenser must protect the head (mission/in-flight/last-ask + task framing) — condense the middle, or size-budget so framing always survives. Evidence: jimmy's handover 2026-10-29T05:59:26Z (session 01a184d4 -> 01a1863d).
3. #291 last-turn loss is already fixed at f82fa69d — do not regress.

Deliverables:
- (a) Idempotent restart-wake post (one embed per restart, or a dedup key the consumer ignores repeats of)
- (b) At-most-once + in-order delivery for channel messages across restart (persistent seen-message-id set in the bridge's state JSON, snowflake-ordered)
- (c) Size guard that protects the transcript head — mission/in-flight/last-ask + active task framing always survive, condense the middle
- (d) Regression tests for all three

OK, so I need to read the actual code in /srv/fleetwork/work/922 (a fresh checkout of the same base 22d8bf58). Let me read the key files:

1. `packages/bridge/channel/restart-wake.ts` — the wake post
2. `packages/bridge/channel/discord.ts` — cursor + polling + scan
3. `packages/bridge/channel/queue.ts` — rewake queue
4. `packages/bridge/channel/restart-queue.ts` — rewake pending/delivered set
5. `packages/bridge/channel/handover.ts` — handover generation (size guard!)
6. `packages/bridge/channel/index.ts` — the big one
7. `packages/bridge/channel/transcript.ts` — probably where the size guard lives (serializeTranscript, keptTailMessages)

Let me start with the smaller files first.

[text] 

t920's handoff is rich. Now let me read the actual code in this checkout, starting with the smaller files t920 mapped.



[toolCall] read {"path": "/srv/fleetwork/work/922/packages/bridge/channel/restart-wake.ts"}
[toolCall] bash {"command": "cd /srv/fleetwork/work/922/packages
…[truncated]
[assistant t6] [thinking] Now I've got a handle on the entirety of restart-wake.ts. Key facts:

- `runRestartWake` runs on every session_start with reason "startup".
- `readCleanStop` consumes (deletes) the clean-stop marker.
- `claimWake` — O_EXCL lock, 60-second dedup window. If two startups are 60 seconds or more apart, both claim and both post.

So double-posting: two actual process startups more than 60 seconds apart each post a wake card. The 60-second window only dedupes competing startups.

But wait — the evidence says: "The second delivery's Discord snowflake (1565239434729754655) is older than the first (1565244903061987410) — an older event was replayed after a newer one."

Snowflake diff: 1565244903061987410 - 1565239434729754655 = 5468332232755. Discord snowflake: (id >> 22) + 1420070400000 = timestamp ms. 5468332232755 / 4194304 ≈ 1303757 ms ≈ 21.7 minutes. So the second post (the one received later) is 21.7 minutes older than the first.

Hmm, wait. Let me re-read: "The agent channel received the 'pi-bg restart-wake - planned' embed twice; the second delivery's Discord snowflake is older than the first's." So the channel received the wake card twice, and the second one received has an older snowflake. If two separate startups each posted, the second startup's post should have a newer snowflake. For the second-received one to be older, one of the following must be true:
1. The same post was delivered twice (a gateway reconnect replayed the older message after the newer one), or
2. The second startup's post was delayed (network) and arrived after the first — but in that case the snowflake should still be newer… no wait, if the second startup happened 21.7 minutes later, its post's snowflake would be newer. An older snowflake received later = either a replay of the first post, or the first post was actually posted later…

Wait a sec. Let me reconsider. If the first startup posts W1 (snowflake S1, newer) and the second startup posts W2 (snowflake S2, older) — that would mean the second startup happened before the first? That's impossible for two sequential startups… unless the "second delivery" is a replay of W1 itself: the same message (S1) delivered twice? But the brief says the snowflakes are different: 1565239434729754655 (older) vs 1565244903061987410 (newer).

So two different messages. The one received second is older by 21.7 minutes. How?

Scenario: The bridge (pi process) is the Discord client. When pi restarts, the Discord connection drops and reconnects. On reconnect, the gateway may replay events. If the bridge also does a REST backfill fetch (pollDiscord with after=cursor) on startup…

Actually, the more likely mechanism: the wake post is done via webhook (bus webhook). Webhook posts arrive via the gateway as MESSAGE_CREATE events. The pi process (old) dies, the new pi process starts, and the bridge reconnects to the gateway. Discord's gateway, on resume/reconnect, may resend recent events (RESUME with sequence replay, or IDENTIFY triggers a burst of recent events? Actually, the gateway doesn't replay history on a new IDENTIFY, but the bridge's own REST backfill does).

The bridge's startup backfill: `pollDiscord` fetches messages with after=cursor. The cursor is persisted. So the backfill only fetches messages after the persisted cursor. The wake post W1 (from startup 1) — when startup 1 posted it, did the cursor advance past it? The wake post is made by the bridge itself (webhook), and the bridge's own messages are… hmm, isBgWebhook exempts webhook-posted messages from the other-bot filter, so the wake post lands as a turn (delivered to pi as a message).

Let me think about the actual sequence that would produce "an older snowflake received after a newer one":

- T0: Old pi process running.
- T1: pi-restart: systemd-run one-shot (90 seconds later) + systemctl restart.
- T2: New pi process (startup 1) starts. Bridge connects to Discord. runRestartWake: consumes clean-stop marker → "planned", claims the wake, posts W1 
…[truncated]

## 8. Usage
turns: 7
last usage: input=27014 output=16384 total=43398
compactions: 0
model: helium/Qwen3.8
