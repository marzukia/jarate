/**
 * Markdown → Discord formatting pipeline.
 *
 * Ported from kimaki (limit-heading-depth, unnest-code-blocks,
 * format-tables key-value rendering, discord-utils escapes,
 * message-formatting embed serialization).
 *
 * Pipeline (mdToDiscord):
 *   1. limitHeadingDepth        — #### and deeper become ###
 *   2. unnestCodeBlocksFromLists — code blocks hoisted out of list items
 *   3. formatMarkdownTables     — tables become **header** value key-value lines
 *   4. escapeBackticksInCodeBlocks — stray backticks in code escaped
 *   5. convertInlineForDiscord  — headings → bold, [text](url) → text (<url>)
 */
import { Lexer, type Token, type Tokens } from "marked";
import type { DiscordEmbed } from "./types";

// ─── Heading depth ─────────────────────────────────────────────────────────

/**
 * Discord only supports headings up to ### (h3). Convert ####, #####, etc.
 * to ### to maintain consistent rendering.
 */
export function limitHeadingDepth(markdown: string, maxDepth = 3): string {
  const lexer = new Lexer();
  const tokens = lexer.lex(markdown);

  let result = "";
  for (const token of tokens) {
    if (token.type === "heading") {
      const heading = token as Tokens.Heading;
      if (heading.depth > maxDepth) {
        const hashes = "#".repeat(maxDepth);
        result += `${hashes} ${heading.text}\n`;
      } else {
        result += token.raw;
      }
    } else {
      result += token.raw;
    }
  }
  return result;
}

// ─── Unnest code blocks from lists ─────────────────────────────────────────

type Segment =
  | { type: "list-item"; prefix: string; content: string }
  | { type: "code"; content: string };

/**
 * Discord doesn't render code blocks inside list items. Hoist them to root
 * level while preserving the list structure around them.
 */
export function unnestCodeBlocksFromLists(markdown: string): string {
  const lexer = new Lexer();
  const tokens = lexer.lex(markdown);

  const result: string[] = [];

  for (let i = 0; i < tokens.length; i++) {
    const token = tokens[i]!;
    const next = tokens[i + 1];

    const chunk = (() => {
      if (token.type === "list") {
        const segments = processListToken(token as Tokens.List);
        // Empty segments (e.g. a bare "42." item with no content) — fall
        // back to the raw token so the text is not dropped.
        return renderSegments(segments) || token.raw;
      }
      return token.raw;
    })();

    if (!chunk) {
      continue;
    }

    const nextRaw = next?.raw ?? "";
    const needsNewline =
      nextRaw &&
      !chunk.endsWith("\n") &&
      typeof nextRaw === "string" &&
      !nextRaw.startsWith("\n");

    result.push(needsNewline ? `${chunk}\n` : chunk);
  }
  return result.join("");
}

function processListToken(list: Tokens.List): Segment[] {
  const segments: Segment[] = [];
  const start =
    typeof list.start === "number" ? list.start : parseInt(list.start, 10) || 1;
  const prefix = list.ordered ? (i: number) => `${start + i}. ` : () => "- ";

  for (let i = 0; i < list.items.length; i++) {
    const item = list.items[i]!;
    const itemSegments = processListItem(item, prefix(i));
    segments.push(...itemSegments);
  }

  return segments;
}

function processListItem(item: Tokens.ListItem, prefix: string): Segment[] {
  const segments: Segment[] = [];
  let currentText: string[] = [];
  // Track if we've seen a code block - text after code uses continuation prefix
  let seenCodeBlock = false;

  const taskMarker = item.task ? (item.checked ? "[x] " : "[ ] ") : "";
  let wroteFirstListItem = false;

  const flushText = (): void => {
    const rawText = currentText.join("");
    const text = rawText.trimEnd();
    if (text.trim()) {
      // After a code block, use '-' as continuation prefix to avoid repeating numbers
      const effectivePrefix = seenCodeBlock ? "- " : prefix;
      const marker = !wroteFirstListItem ? taskMarker : "";
      const normalizedText = normalizeListItemText({
        text,
        isTaskItem: item.task,
      });
      segments.push({
        type: "list-item",
        prefix: effectivePrefix,
        content: marker + normalizedText,
      });
      wroteFirstListItem = true;
    }
    currentText = [];
  };

  for (const token of item.tokens) {
    if (token.type === "code") {
      flushText();
      const codeToken = token as Tokens.Code;
      const lang = codeToken.lang || "";
      segments.push({
        type: "code",
        content: `\`\`\`${lang}\n${codeToken.text}\n\`\`\`\n`,
      });
      seenCodeBlock = true;
      continue;
    }

    if (token.type === "list") {
      flushText();
      // Recursively process nested list - segments bubble up
      const nestedSegments = processListToken(token as Tokens.List);
      segments.push(...nestedSegments);
      continue;
    }

    currentText.push(extractText(token));
  }

  flushText();

  // If no segments were created (empty item), return empty
  if (segments.length === 0) {
    return [];
  }

  // If item had no code blocks (all segments are list-items from this level),
  // return original raw to preserve formatting
  const hasCode = segments.some((s) => s.type === "code");
  if (!hasCode) {
    return [{ type: "list-item", prefix: "", content: item.raw }];
  }

  return segments;
}

function extractText(token: Token): string {
  // Prefer raw to preserve newlines and markdown markers.
  if (typeof token.raw === "string") {
    return token.raw;
  }

  if (token.type === "text") {
    return (token as Tokens.Text).text;
  }

  return "";
}

function normalizeListItemText({
  text,
  isTaskItem,
}: {
  text: string;
  isTaskItem: boolean;
}): string {
  const withoutIndent = text.replace(/^\s+/, "");
  if (!isTaskItem) {
    return withoutIndent;
  }
  return withoutIndent.replace(/^\[(?: |x|X)\]\s+/, "");
}

function renderSegments(segments: Segment[]): string {
  const result: string[] = [];

  for (let i = 0; i < segments.length; i++) {
    const segment = segments[i]!;
    const prev = segments[i - 1];

    if (segment.type === "code") {
      // Add newline before code if previous was a list item
      if (prev && prev.type === "list-item") {
        result.push("\n");
      }
      result.push(segment.content);
    } else {
      // list-item
      if (segment.prefix) {
        result.push(`${segment.prefix + segment.content}\n`);
      } else {
        // Raw content (no prefix means it's original raw)
        // Ensure raw ends with newline for proper separation from next segment
        const raw = segment.content.trimEnd();
        result.push(`${raw}\n`);
      }
    }
  }

  return result.join("").trimEnd();
}

// ─── Tables → key-value lines ──────────────────────────────────────────────

function isTableToken(token: Token): token is Tokens.Table {
  return (
    token.type === "table" &&
    Object.hasOwn(token, "header") &&
    Object.hasOwn(token, "rows")
  );
}

/**
 * Discord has no table rendering. Convert each table row into
 * `**header** value` key-value lines, one pair per cell.
 */
export function formatMarkdownTables(markdown: string): string {
  const tokens = new Lexer().lex(markdown);
  let result = "";
  for (const token of tokens) {
    if (isTableToken(token)) {
      // Preserve the table's trailing newlines so following paragraphs keep
      // their separation.
      const tail = token.raw.match(/\n{0,2}$/)![0];
      result += tableToKeyValue(token) + tail;
    } else {
      result += token.raw;
    }
  }
  return result;
}

function tableToKeyValue(table: Tokens.Table): string {
  const headers = table.header.map((cell, i) => {
    return extractCellText(cell.tokens) || `col ${i + 1}`;
  });
  const lines: string[] = [];
  for (const row of table.rows) {
    for (let i = 0; i < row.length; i++) {
      const cell = row[i]!;
      lines.push(
        `**${headers[i] || `col ${i + 1}`}** ${extractCellText(cell.tokens)}`,
      );
    }
  }
  return lines.join("\n");
}

function extractCellText(tokens: Token[]): string {
  const parts: string[] = [];
  for (const token of tokens) {
    parts.push(extractTokenText(token));
  }
  return parts.join("").trim();
}

function extractTokenText(token: Token): string {
  switch (token.type) {
    case "text":
    case "codespan":
    case "escape":
      return token.text;
    case "link":
      return token.href;
    case "image":
      return token.href;
    case "strong":
    case "em":
    case "del":
      return token.tokens ? extractCellText(token.tokens) : token.text;
    case "br":
      return " ";
    default: {
      const nestedTokens = Reflect.get(token, "tokens");
      if (Array.isArray(nestedTokens)) {
        return extractCellText(
          nestedTokens.filter((value): value is Token => {
            return (
              typeof value === "object" &&
              value !== null &&
              typeof Reflect.get(value, "type") === "string"
            );
          }),
        );
      }
      const text = Reflect.get(token, "text");
      if (typeof text === "string") {
        return text;
      }
      return "";
    }
  }
}

// ─── Escapes ───────────────────────────────────────────────────────────────

/**
 * Escape backticks inside code blocks so Discord doesn't mangle them.
 * Code fences are re-emitted with ``` (indented/tilde normalized).
 */
export function escapeBackticksInCodeBlocks(markdown: string): string {
  const lexer = new Lexer();
  const tokens = lexer.lex(markdown);

  let result = "";
  for (const token of tokens) {
    if (token.type === "code") {
      const escapedCode = token.text.replace(/`/g, "\\`");
      result += `\`\`\`${token.lang || ""}\n${escapedCode}\n\`\`\`\n`;
    } else {
      result += token.raw;
    }
  }

  return result;
}

/**
 * STYLE.md 2.5: a blank line after a closing fence renders as a visible
 * gap in Discord. Collapse ALL blank lines directly after a closing fence
 * (the agent habit is markdown-standard "blank line after code blocks" -
 * 2026-09-15 fleet-summary incident: '```\\n\\n\\nAll three...').
 * Toggles on ```-prefixed lines (real markdown fence semantics); blank
 * lines INSIDE a fence are untouched. Exported for tests.
 */
export function collapseFenceTrailingBlankLines(md: string): string {
  const lines = md.split("\n");
  const out: string[] = [];
  let inFence = false;
  let i = 0;
  while (i < lines.length) {
    const line = lines[i];
    if (line.trimStart().startsWith("```")) {
      const closing = inFence;
      inFence = !inFence;
      out.push(line);
      i++;
      if (closing) {
        while (i < lines.length && lines[i].trim() === "") i++;
      }
    } else {
      out.push(line);
      i++;
    }
  }
  return out.join("\n").replace(/\n+$/, "");
}

/** A fence line that IS a link (whole-line forms), rendered as the
 * hoisted plain line, or null when the line is not a whole-line link.
 * Exported for tests. */
export function wholeLinkLine(
  line: string,
  forms: [RegExp, (m: RegExpMatchArray) => string][],
): string | null {
  for (const [re, render] of forms) {
    const m = line.match(re);
    if (m !== null) return render(m);
  }
  return null;
}

/**
 * Hoist URLs and links out of fenced code blocks.
 *
 * A URL inside a ``` fence is NOT clickable in Discord - it renders as
 * monospace text. When the LLM ships a link in a code block (the "dev link"
 * habit), the reader gets a non-clickable string. Hoist the following fence
 * lines to plain lines immediately after the fence so Discord links them:
 *
 * - a bare http(s) URL that fills the line,
 * - an autolink <url> or a backticked `url` that fills the line (fence
 *   bodies carry ESCAPED backticks after escapeBackticksInCodeBlocks -
 *   both forms match),
 * - a markdown link [label](url) or image ![alt](url) that fills the line.
 *   Links re-emit in the bridge's `label (<url>)` form (image refs stay
 *   as-is): convertInlineForDiscord already ran, so a raw [label](url)
 *   would be re-converted on a second pass and the pipeline would not be
 *   idempotent,
 * - (untagged fences only) a line mixing a bare URL with other content:
 *   the URL hoists, the remainder stays fenced and is dropped if it is
 *   empty or punctuation-only (issue #87).
 *
 * If a fence contained only hoisted lines, the fence is dropped entirely.
 *
 * Fence-aware. LANGUAGE-TAGGED fences (```python, ```bash, ...) never get
 * the mixed-line treatment: a URL inside real code is an argument, not a
 * link. Other code lines are left inside the fence untouched.
 * Exported for tests.
 */
export function hoistFencedUrls(md: string): string {
  const urlLine = /^\s*(https?:\/\/\S+)\s*$/i;
  const autoLinkLine = /^\s*<(https?:\/\/[^\s<>\\]+)>\s*$/i;
  const spanUrlLine = /^\s*\\?`(https?:\/\/[^`\\\s]+)\\?`\s*$/i;
  const mdLinkLine =
    /^\s*(!?)\[([^\]]+)\]\(((?:https?|mailto):[^\s)]+)\)\s*[.!?]*\s*$/i;
  // whole-line link forms, tried in order; the render function emits the
  // hoisted plain line
  const wholeLinkForms: [RegExp, (m: RegExpMatchArray) => string][] = [
    [urlLine, (m) => m[1]!],
    [autoLinkLine, (m) => m[1]!],
    [spanUrlLine, (m) => m[1]!],
    [
      mdLinkLine,
      (m) => (m[1] === "!" ? `[${m[2]}](${m[3]})` : `${m[2]} (<${m[3]}>)`),
    ],
  ];
  const lines = md.split("\n");
  const out: string[] = [];
  let i = 0;
  while (i < lines.length) {
    const line = lines[i];
    if (!line.trimStart().startsWith("```")) {
      out.push(line);
      i++;
      continue;
    }
    // collect the whole fence (open line .. close line)
    const fenceStart = i;
    let j = i + 1;
    while (j < lines.length && !lines[j]!.trimStart().startsWith("```")) j++;
    const fenceEnd = j; // index of the closing fence line (== length if open)
    const closed = fenceEnd < lines.length;
    const body = lines.slice(fenceStart + 1, fenceEnd);
    const tagged = lines[fenceStart]!.trimStart().slice(3).trim() !== "";
    const hoisted: string[] = [];
    const kept: string[] = [];
    for (const bl of body) {
      const whole = wholeLinkLine(bl, wholeLinkForms);
      if (whole !== null) {
        hoisted.push(whole);
        continue;
      }
      if (!tagged) {
        const urls = extractMachineUrls(bl);
        if (urls.length > 0) {
          // remove end-first: later splices must not shift earlier indices
          let r = bl;
          for (let k = urls.length - 1; k >= 0; k--) {
            const u = urls[k]!;
            r = r.slice(0, u.start) + r.slice(u.end);
          }
          r = r.replace(/[ \t]+/g, " ").trim();
          if (/\w/.test(r)) kept.push(r);
          for (const u of urls) hoisted.push(u.url);
          continue;
        }
      }
      kept.push(bl);
    }
    if (hoisted.length === 0) {
      // no urls to hoist; emit fence unchanged
      out.push(...lines.slice(fenceStart, fenceEnd + 1));
      i = fenceEnd + 1;
      continue;
    }
    if (kept.length > 0) {
      // fence still has code in it: keep it, then the hoisted urls after
      out.push(lines[fenceStart]!, ...kept);
      if (closed) out.push(lines[fenceEnd]!);
      out.push(...hoisted);
    } else {
      // fence was links only: drop it, emit the links as plain lines
      out.push(...hoisted);
    }
    i = fenceEnd + 1;
  }
  return out.join("\n");
}

// ─── Style guard (STYLE.md 2.7 / 3.1 / 4.4 mechanical pass) ───────────────

/** Lowercase compact token count: 999 -> "999", 104480 -> "104k",
 * 2_621_440 -> "2.6m". Non-finite/negative -> "?". (Was ctxwatch.ts;
 * the context-boundary notice was gutted 2026-10-19 - the formatter
 * stays: /jobs run frame + /compact ack use it.) */
export function fmtTokensLC(n: number): string {
  if (!Number.isFinite(n) || n < 0) return "?";
  if (n < 1000) return String(Math.round(n));
  if (n < 1_000_000) return `${Math.round(n / 1000)}k`;
  const m = n / 1_000_000;
  return `${m >= 10 ? String(Math.round(m)) : m.toFixed(1)}m`;
}

/** Machine frames (STYLE.md 2.1): box-drawing chars live in fences only.
 * Exported for tests. */
export const STYLE_BOX_RE = /[┌┐└┘├┤┣┫│]/;

/** A line that IS a path, whole: /abs, ~/rel, ./rel, ../rel. A space means
 * prose mentioning a path, not a path line - those stay bare.
 * Exported for tests. */
export const STYLE_PATH_RE = /^(?:~\/|\.\.?\/|\/)(?:[\w.@+-]+\/)*[\w.@+-]+$/;

/** Deterministic log-line shapes: [timestamp] prefix, ISO date, HH:MM:SS,
 * UPPERCASE level prefix (ERROR: ...), journal "Sep 23 09:22:22 host ...".
 * All alternatives anchored - linear scan, no backtracking on long lines.
 * Exported for tests. */
export const STYLE_LOG_RE = new RegExp(
  "^\\[(?:\\d{4}-\\d{2}-\\d{2}[T ]|\\d{1,2}:\\d{2}:\\d{2})" +
    "|^\\d{4}[-/]\\d{2}[-/]\\d{2}[ T]\\d{2}:\\d{2}" +
    "|^\\d{1,2}:\\d{2}:\\d{2}[ .]" +
    "|^(?:ERROR|WARN|WARNING|INFO|DEBUG|TRACE|FATAL|CRIT|NOTICE)(?::|\\s)" +
    "|^[A-Z][a-z]{2} \\d{1,2} \\d{2}:\\d{2}:\\d{2} \\S",
);

/** Length of the leading backtick run (>=3), else 0 - the same
 * ```-prefixed toggle convention as every other fence-aware pass here. */
function fenceRun(line: string): number {
  const t = line.trimStart();
  if (!t.startsWith("```")) return 0;
  let n = 0;
  while (n < t.length && t[n] === "`") n++;
  return n >= 3 ? n : 0;
}

/** Naive brace/bracket balance (strings ignored) - only used to decide
 * whether a `{` line starts a multi-line JSON object. Never throws. */
function braceDepth(line: string): number {
  let d = 0;
  for (const c of line) {
    if (c === "{" || c === "[") d++;
    else if (c === "}" || c === "]") d--;
  }
  return d;
}

/** One top-level (outside any existing fence) line is MACHINE state when
 * it carries box-drawing frame chars, is a bare path, a deterministic log
 * line, or a JSON object line. Tagged status lines ([ok] [!] ...) are
 * machine output per STYLE.md 3.1 (Andryo 2026-10-20) - left alone (the
 * bridge ships those already fenced). Everything else - prose, lists,
 * headings, blockquotes, inline code - is left alone too (conservative: a
 * missed fence is less bad than a mangled message). */
function isMachineLine(raw: string): boolean {
  const t = raw.trim();
  if (t === "") return false;
  if (t.startsWith("`")) return false; // inline code: 4.4's one-line form
  if (/^#{1,6}\s/.test(t)) return false; // heading
  if (t.startsWith(">")) return false; // blockquote
  if (/^(?:[-*+]|\d{1,3}\.\s)/.test(t)) return false; // list item
  if (STYLE_BOX_RE.test(t)) return true;
  if (STYLE_PATH_RE.test(t)) return true;
  if (STYLE_LOG_RE.test(t)) return true;
  return t.startsWith("{"); // JSON object line
}

/**
 * Auto-linkable http(s) URL tokens on a machine line (issue #87).
 * Returns each bare URL plus the range to remove from the line. A
 * `<url>` autolink or `url` inline-code wrapper immediately around the
 * URL is absorbed into the range, so removing the range removes the
 * wrapper too - including the escape backslash of a backtick wrapper in
 * a fence body (escapeBackticksInCodeBlocks ships `url` as \`url\`).
 * A URL inside a quoted or code-spanned region that opened
 * EARLIER on the line (a JSON string value, a mixed-content span) is not
 * linkable here - removing it would break the quoted content - and is
 * skipped. Trailing sentence punctuation (.,;:!?)]) and a trailing
 * backslash (an escape) are not part of the URL. Exported for tests.
 */
export function extractMachineUrls(
  line: string,
): { url: string; start: number; end: number }[] {
  const found: { url: string; start: number; end: number }[] = [];
  const re = /https?:\/\/[^\s"'<>`]+/g;
  let m: RegExpExecArray | null = re.exec(line);
  while (m !== null) {
    const s = m.index;
    const mEnd = m.index + m[0].length;
    const before = line[s - 1]!;
    const after = line[mEnd]!;
    // wrapper detection runs on the RAW match end: in a fence body the
    // closing backtick is escaped, so the raw match ends on the backslash
    let ws = s;
    let we = mEnd;
    if (before === "<" && after === ">") {
      ws--;
      we++;
    } else if (before === "`" && after === "`") {
      ws--;
      we++;
      // fence bodies escape backticks: absorb the escape backslash too,
      // or the removal leaves a dangling \ behind
      if (ws > 0 && line[ws - 1] === "\\") ws--;
      if (we < line.length && line[we] === "\\") we++;
    }
    // a trailing \ (escape) is not URL content, then sentence punctuation
    let urlEnd = mEnd;
    while (urlEnd > s && line[urlEnd - 1] === "\\") urlEnd--;
    while (urlEnd > s && /[.,;:!?)\]]/.test(line[urlEnd - 1]!)) urlEnd--;
    const beforeUrl = line.slice(0, ws);
    if (
      (beforeUrl.match(/"/g)?.length ?? 0) % 2 === 1 ||
      (beforeUrl.match(/'/g)?.length ?? 0) % 2 === 1 ||
      (beforeUrl.match(/`/g)?.length ?? 0) % 2 === 1
    ) {
      m = re.exec(line);
      continue;
    }
    found.push({ url: line.slice(s, urlEnd), start: ws, end: we });
    m = re.exec(line);
  }
  return found;
}

/**
 * Deterministic mechanical fence pass (STYLE.md 2.7 / 4.4). Post-format
 * only: takes already-formatted markdown and fences top-level machine
 * state. Every /command reply and every machine output (script errors,
 * command output, logs, JSON, paths, box frames) ships in a code fence.
 * Tagged status lines are prose (STYLE.md 3.1, tag convention retired
 * 2026-10-19) and ship unfenced.
 *
 * - Consecutive machine lines share ONE fence (a frame or a tag block),
 *   never one fence per line.
 * - An unbalanced `{` line (multi-line JSON) also pulls in body lines
 *   until the braces balance; a blank line or an existing fence stops it
 *   (100-line cap).
 * - Lines already inside a fence are untouched (no double-fence).
 * - A URL on a machine line is hoisted to a BARE line after the fence
 *   (issue #87): a fenced URL is monospace, not clickable, and the
 *   clickability passes run before this one.
 * - Fence lines ship as written - NO 40-col wrap (Andryo 2026-10-18:
 *   the width budget is scoped to in-turn tool-call frames; fence
 *   content wraps natively in Discord).
 * - Pure, fast (single pass, anchored patterns), and idempotent:
 *   styleGuard(styleGuard(x)) === styleGuard(x).
 */
export function styleGuard(md: string): string {
  const lines = md.split("\n");
  const out: string[] = [];
  let i = 0;
  while (i < lines.length) {
    const line = lines[i]!;
    const open = fenceRun(line);
    if (open > 0) {
      // existing fence: pass delimiter + body through verbatim (no
      // width wrap - Andryo 2026-10-18). The closer is the first fence
      // line at least as long as the opener (a ``` line nested in a
      // ```` fence is body, not a closer).
      out.push(line);
      i++;
      while (i < lines.length && fenceRun(lines[i]!) < open) {
        out.push(lines[i]!);
        i++;
      }
      if (i < lines.length) {
        out.push(lines[i]!);
        i++;
      }
      continue;
    }
    if (!isMachineLine(line)) {
      out.push(line);
      i++;
      continue;
    }
    // machine block: consecutive machine lines go into ONE fence
    const block: string[] = [line];
    i++;
    let depth = braceDepth(line);
    while (i < lines.length) {
      const nxt = lines[i]!;
      const nt = nxt.trim();
      if (nt === "" || fenceRun(nxt) > 0) break;
      if (depth > 0) {
        // inside an unbalanced JSON object: pull in the body lines
        if (block.length >= 100) break;
        block.push(nxt);
        i++;
        depth += braceDepth(nxt);
        continue;
      }
      if (!isMachineLine(nxt)) break;
      block.push(nxt);
      i++;
      depth = braceDepth(nxt);
    }
    const marker = block.some((l) => l.includes("```")) ? "````" : "```";
    // #87: URLs on machine lines must not be trapped in this NEW fence -
    // the URL-clickability passes already ran. Hoist each URL to a bare
    // line AFTER the fence so Discord links it; the line's remainder
    // stays fenced and is dropped if it is empty or punctuation-only.
    const hoisted: string[] = [];
    const rest: string[] = [];
    for (const bl of block) {
      const urls = extractMachineUrls(bl);
      if (urls.length === 0) {
        rest.push(bl);
        continue;
      }
      let r = bl;
      for (const u of urls) r = r.slice(0, u.start) + r.slice(u.end);
      r = r.replace(/[ \t]+/g, " ").trim();
      if (/\w/.test(r)) rest.push(r);
      for (const u of urls) hoisted.push(u.url);
    }
    if (rest.length > 0) {
      out.push(marker);
      for (const rl of rest) out.push(rl);
      out.push(marker);
    }
    out.push(...hoisted);
  }
  return out.join("\n");
}

/**
 * Escape triple backticks in free text so it doesn't open a code block
 * when inserted into a Discord message.
 */
export function escapeDiscordFormatting(text: string): string {
  return text.replace(/```/g, "\\`\\`\\`").replace(/````/g, "\\`\\`\\`\\`");
}

// ─── Embed serialization ───────────────────────────────────────────────────

/**
 * Serialize Discord embeds into plain text so the LLM can read them.
 * Each embed becomes an <embed> block with author, title, URL, description,
 * fields, and footer when present.
 */
export function serializeEmbeds(embeds: DiscordEmbed[]): string {
  if (embeds.length === 0) return "";
  const parts: string[] = [];
  for (const embed of embeds) {
    const lines: string[] = [];
    if (embed.author?.name) {
      lines.push(`Author: ${embed.author.name}`);
    }
    if (embed.title) {
      lines.push(`Title: ${embed.title}`);
    }
    if (embed.url) {
      lines.push(`URL: ${embed.url}`);
    }
    if (embed.description) {
      lines.push(embed.description);
    }
    for (const field of embed.fields ?? []) {
      lines.push(`${field.name}: ${field.value}`);
    }
    if (embed.footer?.text) {
      lines.push(`Footer: ${embed.footer.text}`);
    }
    if (lines.length > 0) {
      parts.push(`<embed>\n${lines.join("\n")}\n</embed>`);
    }
  }
  return parts.join("\n\n");
}

// ─── Inline conversion ─────────────────────────────────────────────────────

/**
 * Line-based inline conversion, fence-aware (a ``` block is never touched):
 * - `# heading` → `**heading**`
 * - `[text](url)` → `text (<url>)`, skipped inside inline code spans
 */
export function convertInlineForDiscord(md: string): string {
  const lines = md.split("\n");
  let inCodeBlock = false;
  const out: string[] = [];
  for (const line of lines) {
    if (line.trimStart().startsWith("```")) {
      inCodeBlock = !inCodeBlock;
      out.push(line);
      continue;
    }
    if (inCodeBlock) {
      out.push(line);
      continue;
    }
    // # heading → **heading**
    let converted = line.replace(
      /^(#{1,6})\s+(.+)$/,
      (_m, _hashes: string, text: string) => `**${text}**`,
    );
    // [text](url) → text (<url>) — skip image refs ![alt](url) and code spans
    converted = codeSpans(converted, (part) =>
      part.replace(
        /(?<!!)\[([^\]]+)\]\(([^)]+)\)/g,
        (_m, text: string, url: string) => `${text} (<${url}>)`,
      ),
    );
    // `https://…` (a codespan whose ENTIRE content is a bare URL) → <https://…>
    // so a backticked link stays clickable. Spans with any other content
    // (e.g. `foo bar`, `code`) are left alone.
    converted = converted.replace(
      /`((?:https?:\/\/)[^`\s]+)`/g,
      (_m, url: string) => `<${url}>`,
    );
    out.push(converted);
  }
  return out.join("\n");
}

/** Split a line into code-span / non-code-span parts and map the non-code parts. */
function codeSpans(line: string, map: (part: string) => string): string {
  return line
    .split(/(`+[^`]*`+)/g)
    .map((part, i) => (i % 2 === 1 ? part : map(part)))
    .join("");
}

// ─── Pipeline ──────────────────────────────────────────────────────────────

/** Convert LLM markdown to Discord-friendly formatting. */
export function mdToDiscord(md: string): string {
  let out = limitHeadingDepth(md);
  out = unnestCodeBlocksFromLists(out);
  out = formatMarkdownTables(out);
  out = escapeBackticksInCodeBlocks(out);
  out = convertInlineForDiscord(out);
  out = collapseFenceTrailingBlankLines(out);
  out = hoistFencedUrls(out);
  // Last step: deterministic machine-state fence pass (STYLE.md 2.7/4.4)
  out = styleGuard(out);
  return out;
}
