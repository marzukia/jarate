import { afterEach, beforeEach, describe, expect, jest, test } from "bun:test";
import { execFileSync } from "node:child_process";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import {
  clearDiscordStatesForTest,
  getChannelCursor,
  loadPersistedCursors,
  pollDiscord,
  seedChannelStateForTest,
  setChannelCursor,
} from "./discord";
import { isFleetRun } from "./fleet-run";
import { fmtTokensLC, styleGuard } from "./format";
import { FRAME_COL_MAX } from "./frame";
import { ORCHESTRATOR_PRIME_LINE, writeHandover } from "./handover";
import extension, {
  autoCompactByToken,
  bashToolEssential,
  buildInteractionHandler,
  buildRepliedMessageBlock,
  buildRestartCommand,
  CHANNEL_MSG_TYPE,
  channelError,
  chunkText,
  clearAllCompacting,
  clearAllInterrupts,
  clearQueuedInbound,
  collectFinals,
  deleteQueuedInbound,
  deliverDueTasks,
  deliverDueWakes,
  earlySendText,
  failurePostText,
  fence,
  fileOnlyPrompt,
  handleInbound,
  hasOwnerConfigured,
  heldChannels,
  interruptStepTimeoutMs,
  isBgInbound,
  isCompacting,
  isEssentialToolCall,
  isHeld,
  isNoReply,
  isOwnerUser,
  isVerbose,
  LIVE_MARKER_DIR,
  LIVE_TEXT_PLACEHOLDER,
  LIVE_TEXT_THROTTLE_MS,
  lastRunUsage,
  matchCommand,
  maybeAutoCompactByToken,
  midTurnQueues,
  opWindowLabel,
  parseReplyTo,
  parseUndoCount,
  parseVerboseLevel,
  pendingAttachments,
  pendingInterrupts,
  persistLivePlaceholders,
  popChannelQueuedInbound,
  prunePendingBatches,
  queuedAcks,
  queueMidTurnInbound,
  REPEAT_WARNING,
  RUN_FRAME_MAX_STEPS,
  readLivePlaceholders,
  registerSleepTool,
  registerTaskTool,
  registerTodoTool,
  resetRuntimeStateForTest,
  runFrame,
  runMidRunInterrupt,
  runShellPassthrough,
  runUsageLine,
  setHandoffRestartArmed,
  setHeld,
  setInterruptCtx,
  setLiveKickoffStateHookForTest,
  setProcessExitHookForTest,
  setRuntimeStateDir,
  setSystemdRestartHookForTest,
  settleOpTick,
  simulateProcessDeathForTest,
  stopAllCompactTicks,
  stopAllOpTicks,
  TODO_TOOL_DESCRIPTION,
  TOOL_LINE_MAX,
  TOOL_TEXT_MAX,
  toolActionText,
  touchLiveMarker,
  truncateLiveText,
  updateQueuedInbound,
  verboseLevel,
  verboseOverride,
  workingMaxMs,
} from "./index";
import { loadRewakeQueue, rewakeAddPending } from "./restart-queue";
import { CLAIM_TTL_MS, loadWakes, markClaimed, scheduleWake } from "./sleep";
import { loadTasks, markTaskClaimed, scheduleTask } from "./tasks";
import { fit, loadBoard, renderBoard, saveBoard } from "./todos";
import {
  type ChannelMessage,
  loadChannelConfig,
  resolveSystemdUnit,
} from "./types";
import { performUndo } from "./undo";
import { clearWorktreeState } from "./worktree";

// Fleet-run gate (hall-monitor #35 gut): a dispatch agent running this
// suite inherits PI_SESSION_ID=fleetwork-<ticket> from its run wrapper;
// the gate treats that as a fleet run and would skip all channel startup
// in every test. Clear it here (the fleet-gate describe re-sets it).
delete process.env.PI_SESSION_ID;

/** A2 (polish sweep, 2026-09-15) + 2026-10-18: styleGuard once wrapped
 *  untagged fence bodies to the 40-col budget; the wrap is GONE (no width
 *  budget on fences anymore), so this collapse is a no-op kept for the
 *  historical assertions that use it. */
const unwarped = (s: string) => s.replace(/\n +/g, " ");

/** F2 (test-fidelity audit): the interaction network contract — the ONLY
 *  (method, URL) pairs the bridge may send for one interaction:
 *   - callback (defer / plain reply): POST  /interactions/{id}/{token}/callback
 *   - edit the deferred message:       PATCH /webhooks/{app}/{token}/messages/@original
 *   - create followup:                POST  /webhooks/{app}/{token}  (webhook ROOT)
 *  The followup is the webhook ROOT: the incoming-webhook form
 *  /webhooks/{app}/{token}/messages is rejected 400 50035 (RCA 2026-10-08).
 *  Returns a violation string for any other call, null when allowed.
 *  The vault-block stub additionally allows the plain channel message
 *  routes (card post / card edit) via allowChannelMessages. */
const interactionUrlViolation = (
  url: string,
  method: string,
  allowChannelMessages = false,
): string | null => {
  const u = String(url);
  const m = method ?? "GET";
  if (
    m === "POST" &&
    /^https:\/\/discord\.com\/api\/v10\/interactions\/[^/]+\/[^/]+\/callback$/.test(
      u,
    )
  )
    return null;
  if (
    m === "PATCH" &&
    /^https:\/\/discord\.com\/api\/v10\/webhooks\/[^/]+\/[^/]+\/messages\/@original$/.test(
      u,
    )
  )
    return null;
  if (
    m === "POST" &&
    /^https:\/\/discord\.com\/api\/v10\/webhooks\/[^/]+\/[^/]+$/.test(u)
  )
    return null;
  if (allowChannelMessages) {
    if (
      m === "POST" &&
      /^https:\/\/discord\.com\/api\/v10\/channels\/[^/]+\/messages$/.test(u)
    )
      return null;
    if (
      m === "PATCH" &&
      /^https:\/\/discord\.com\/api\/v10\/channels\/[^/]+\/messages\/[^/]+$/.test(
        u,
      )
    )
      return null;
  }
  return `${m} ${u}`;
};

describe("chunkText", () => {
  test("short fenced block is unchanged", () => {
    const text = "```js\nconst x = 1\n```";
    expect(chunkText(text, 200)).toEqual([text]);
  });

  test("fenced block over max is split and each piece stays fenced under max (M1)", () => {
    const line = "x".repeat(1200);
    const text = ["```js", line, "const y = 2", "```"].join("\n");
    const chunks = chunkText(text, 500);
    expect(chunks.length).toBeGreaterThan(1);
    for (const c of chunks) {
      expect(c.length).toBeLessThanOrEqual(500);
      expect(c.startsWith("```js\n")).toBe(true);
      expect(c.endsWith("\n```")).toBe(true);
    }
    // No content lost: strip fences and newlines, must equal the inner text.
    const stripped = chunks
      .map((c) => c.replace(/^```js\n/, "").replace(/\n```$/, ""))
      .join("\n")
      .replace(/\n/g, "");
    expect(stripped).toBe(`${line}const y = 2`);
  });

  test("single oversized code line inside a fence is split (M1)", () => {
    const line = "b".repeat(400);
    const text = ["```", line, "```"].join("\n");
    const chunks = chunkText(text, 100);
    expect(chunks.length).toBeGreaterThan(1);
    for (const c of chunks) {
      expect(c.length).toBeLessThanOrEqual(100);
      expect(c.startsWith("```\n")).toBe(true);
      expect(c.endsWith("\n```")).toBe(true);
    }
  });

  test("single long line outside a fence is split without loss", () => {
    const chunks = chunkText("a".repeat(250), 100);
    expect(chunks.every((c) => c.length <= 100)).toBe(true);
    expect(chunks.join("")).toBe("a".repeat(250));
  });
});

describe("isNoReply", () => {
  test("exact token (trim + case-insensitive)", () => {
    expect(isNoReply("NO_REPLY")).toBe(true);
    expect(isNoReply("no_reply")).toBe(true);
    expect(isNoReply("  No_ReplY  ")).toBe(true);
  });
  test("non-matches stay postable", () => {
    expect(isNoReply("NO_REPLY.")).toBe(false);
    expect(isNoReply("NO_REPLY extra")).toBe(false);
    expect(isNoReply("·")).toBe(false);
    expect(isNoReply("")).toBe(false);
  });
});

describe("collectFinals", () => {
  const inbound = (id: string) => ({
    customType: "channel-inbound",
    details: { messageId: id },
  });
  const assistantText = (text: string) => ({
    role: "assistant",
    content: [{ type: "text", text }],
  });

  test("pairs each final with the nearest preceding inbound (L4)", () => {
    // Steering run shape: [A, X, B, Y] must thread X → A and Y → B.
    const finals = collectFinals([
      inbound("A"),
      assistantText("X"),
      inbound("B"),
      assistantText("Y"),
    ]);
    expect(finals).toEqual([
      { text: "X", replyTo: "A" },
      { text: "Y", replyTo: "B" },
    ]);
  });

  test("tool-call turns are not finals (L4)", () => {
    const finals = collectFinals([
      inbound("A"),
      {
        role: "assistant",
        content: [{ type: "toolCall", toolName: "read", arguments: {} }],
      },
      assistantText("done"),
    ]);
    expect(finals).toEqual([{ text: "done", replyTo: "A" }]);
  });

  test("final before any inbound has no reply target", () => {
    const finals = collectFinals([assistantText("hi")]);
    expect(finals).toEqual([{ text: "hi", replyTo: undefined }]);
  });

  test("<reply-to> tag matching a burst id wins over the last-message target", () => {
    const burst = {
      customType: "channel-inbound",
      details: { messageId: "333", messageIds: ["111", "222", "333"] },
    };
    const finals = collectFinals([
      burst,
      assistantText("<reply-to:111>\nthanks andy"),
    ]);
    expect(finals).toEqual([{ text: "thanks andy", replyTo: "111" }]);
  });

  test("<reply-to> tag mid-text is stripped and used when valid", () => {
    const burst = {
      customType: "channel-inbound",
      details: { messageId: "333", messageIds: ["111", "222", "333"] },
    };
    const finals = collectFinals([
      burst,
      assistantText("done, see above <reply-to: 222 >"),
    ]);
    expect(finals).toEqual([{ text: "done, see above ", replyTo: "222" }]);
  });

  test("<reply-to> tag not in the triggering ids falls back to last-message target", () => {
    const burst = {
      customType: "channel-inbound",
      details: { messageId: "333", messageIds: ["111", "222", "333"] },
    };
    const finals = collectFinals([burst, assistantText("<reply-to:999>\nhi")]);
    expect(finals).toEqual([{ text: "hi", replyTo: "333" }]);
  });

  test("<reply-to> tag without any inbound falls back (no target)", () => {
    const finals = collectFinals([assistantText("<reply-to:111>\nhi")]);
    expect(finals).toEqual([{ text: "hi", replyTo: undefined }]);
  });

  test("no tag: existing behavior unchanged, text untouched", () => {
    const finals = collectFinals([inbound("A"), assistantText("  spaced  ")]);
    expect(finals).toEqual([{ text: "spaced", replyTo: "A" }]);
  });

  test("rapid-fire: reply-to an earlier inbound in the same run (2026-09-20)", () => {
    // operator msg 1 → my reply → operator msg 2 → my reply with <reply-to:msg1>
    // The allowed set must accumulate ALL inbound ids, not just the last.
    const finals = collectFinals([
      inbound("111"),
      assistantText("first reply"),
      inbound("222"),
      assistantText("<reply-to:111>\ntagging the earlier one"),
    ]);
    expect(finals).toEqual([
      { text: "first reply", replyTo: "111" },
      { text: "tagging the earlier one", replyTo: "111" },
    ]);
  });

  test("rapid-fire burst: reply-to a burst member from an earlier burst (2026-09-20)", () => {
    const burst1 = {
      customType: "channel-inbound",
      details: { messageId: "333", messageIds: ["111", "222", "333"] },
    };
    const burst2 = {
      customType: "channel-inbound",
      details: { messageId: "444", messageIds: ["444"] },
    };
    const finals = collectFinals([
      burst1,
      assistantText("<reply-to:111>\ntagging 111 from burst 1"),
      burst2,
      assistantText("<reply-to:111>\nstill tagging 111 after burst 2"),
    ]);
    expect(finals).toEqual([
      { text: "tagging 111 from burst 1", replyTo: "111" },
      { text: "still tagging 111 after burst 2", replyTo: "111" },
    ]);
  });
});

describe("parseReplyTo", () => {
  test("strips a leading tag and the newline it leaves", () => {
    expect(parseReplyTo("<reply-to:123456>\nbody text")).toEqual({
      text: "body text",
      replyTo: "123456",
    });
  });

  test("strips a tag anywhere in the text", () => {
    expect(parseReplyTo("a <reply-to:123> b")).toEqual({
      text: "a  b",
      replyTo: "123",
    });
  });

  test("no tag: text unchanged, replyTo undefined", () => {
    expect(parseReplyTo("plain text")).toEqual({
      text: "plain text",
      replyTo: undefined,
    });
  });

  test("non-numeric payload is not a tag", () => {
    expect(parseReplyTo("<reply-to:abc>\nbody")).toEqual({
      text: "<reply-to:abc>\nbody",
      replyTo: undefined,
    });
  });

  test("empty text", () => {
    expect(parseReplyTo("")).toEqual({ text: "", replyTo: undefined });
  });

  test("tag inside a code fence is content, not a directive", () => {
    expect(parseReplyTo("example:\n```\n<reply-to:111>\n```\ndone")).toEqual({
      text: "example:\n```\n<reply-to:111>\n```\ndone",
      replyTo: undefined,
    });
  });

  test("tag outside a fence next to a fenced tag is honored, fenced one kept", () => {
    expect(
      parseReplyTo("```\n<reply-to:111>\n```\nsee above <reply-to:222>"),
    ).toEqual({
      text: "```\n<reply-to:111>\n```\nsee above ",
      replyTo: "222",
    });
  });

  test("multiple tags: first outside fences wins, all are stripped", () => {
    expect(parseReplyTo("<reply-to:111>\nbody <reply-to:333>")).toEqual({
      text: "body ",
      replyTo: "111",
    });
  });
});

describe("fileOnlyPrompt", () => {
  const att = (filename: string) => ({
    id: "1",
    filename,
    contentType: "image/jpeg",
    size: 1024,
  });

  test("single file uses singular wording", () => {
    expect(fileOnlyPrompt([att("IMG_1358.jpg")])).toBe(
      "[user sent 1 file without text: IMG_1358.jpg]",
    );
  });

  test("multiple files are listed", () => {
    expect(fileOnlyPrompt([att("a.txt"), att("b.jpg")])).toBe(
      "[user sent 2 files without text: a.txt, b.jpg]",
    );
  });
});

describe("prunePendingBatches", () => {
  test("drops batches older than the 10-minute TTL", () => {
    const now = Date.now();
    pendingAttachments.set("ch1", [
      {
        folder: ".tmp/attachments/old",
        files: [],
        addedAt: now - 11 * 60 * 1000,
      },
      { folder: ".tmp/attachments/fresh", files: [], addedAt: now - 60 * 1000 },
    ]);
    const fresh = prunePendingBatches("ch1", now);
    expect(fresh.map((b) => b.folder)).toEqual([".tmp/attachments/fresh"]);
    pendingAttachments.delete("ch1");
  });

  test("empty channel has no batches and no map entry", () => {
    expect(prunePendingBatches("nope")).toEqual([]);
    expect(pendingAttachments.has("nope")).toBe(false);
  });
});

describe("matchCommand (A3)", () => {
  test("slash commands match, with and without args", () => {
    expect(matchCommand("/stop")).toEqual({ name: "stop", arg: undefined });
    expect(matchCommand("/stop now")).toEqual({ name: "stop", arg: "now" });
    expect(matchCommand("/status")).toEqual({ name: "status", arg: undefined });
    expect(matchCommand("/reset the table")).toEqual({
      name: "reset",
      arg: "the table",
    });
    expect(matchCommand("/verbose on")).toEqual({ name: "verbose", arg: "on" });
    expect(matchCommand("/help")).toEqual({ name: "help", arg: undefined });
    expect(matchCommand("/btw what is up")).toEqual({
      name: "btw",
      arg: "what is up",
    });
    expect(matchCommand("/compact keep the decisions")).toEqual({
      name: "compact",
      arg: "keep the decisions",
    });
    expect(matchCommand("/model vllm/qwen3.8-27b")).toEqual({
      name: "model",
      arg: "vllm/qwen3.8-27b",
    });
    expect(matchCommand("/jobs")).toEqual({ name: "jobs", arg: undefined });
    expect(matchCommand("/todos")).toEqual({ name: "todos", arg: undefined });
    expect(matchCommand("/todos all")).toEqual({ name: "todos", arg: "all" });
    expect(matchCommand("/sleep")).toEqual({ name: "sleep", arg: undefined });
    expect(matchCommand("/sleep list")).toEqual({ name: "sleep", arg: "list" });
    expect(matchCommand("/sleep cancel abc123")).toEqual({
      name: "sleep",
      arg: "cancel abc123",
    });
    expect(matchCommand("/tasks")).toEqual({ name: "tasks", arg: undefined });
    expect(matchCommand("/tasks list")).toEqual({ name: "tasks", arg: "list" });
    expect(matchCommand("/tasks cancel abc123")).toEqual({
      name: "tasks",
      arg: "cancel abc123",
    });
    expect(matchCommand("/diff")).toEqual({ name: "diff", arg: undefined });
    expect(matchCommand("/diff main..HEAD")).toEqual({
      name: "diff",
      arg: "main..HEAD",
    });
  });

  test("bare stop is exact-match only", () => {
    expect(matchCommand("stop")).toEqual({ name: "stop", arg: undefined });
    expect(matchCommand("STOP")).toEqual({ name: "stop", arg: undefined });
    expect(matchCommand("stop ")).toBeNull();
    expect(matchCommand("stop that")).toBeNull();
  });

  test("no-slash other commands are chat, not commands", () => {
    expect(matchCommand("status update")).toBeNull();
    expect(matchCommand("help me with X")).toBeNull();
    expect(matchCommand("btw I was thinking")).toBeNull();
    expect(matchCommand("reset the table")).toBeNull();
    expect(matchCommand("verbose on")).toBeNull();
    expect(matchCommand("compact the logs")).toBeNull();
    expect(matchCommand("model switch")).toBeNull();
    expect(matchCommand("stop1")).toBeNull();
  });

  test("near-misses are not commands", () => {
    expect(matchCommand("/stopx")).toBeNull();
    expect(matchCommand("/todosx")).toBeNull();
    expect(matchCommand("todos")).toBeNull();
    expect(matchCommand("sleep")).toBeNull();
    expect(matchCommand("/sleepx")).toBeNull();
    expect(matchCommand(" stop")).toBeNull();
    expect(matchCommand("/ /stop")).toBeNull();
  });
});

describe("parseUndoCount (#46 /undo N)", () => {
  test("bare / whitespace = 1; positive integers pass through", () => {
    expect(parseUndoCount(undefined)).toBe(1);
    expect(parseUndoCount("")).toBe(1);
    expect(parseUndoCount("   ")).toBe(1);
    expect(parseUndoCount("1")).toBe(1);
    expect(parseUndoCount(" 2 ")).toBe(2);
    expect(parseUndoCount("10")).toBe(10);
    expect(parseUndoCount("007")).toBe(7);
  });

  test("0, negative, non-numeric -> null (one line, no action)", () => {
    expect(parseUndoCount("0")).toBeNull();
    expect(parseUndoCount("-1")).toBeNull();
    expect(parseUndoCount("abc")).toBeNull();
    expect(parseUndoCount("1.5")).toBeNull();
    expect(parseUndoCount("1x")).toBeNull();
    expect(parseUndoCount("2 turns")).toBeNull();
  });
});

describe("runShellPassthrough (!)", () => {
  test("runs bash -c and returns output + exit code", async () => {
    const r = await runShellPassthrough("echo hello; exit 3", "/tmp");
    expect(r.out).toContain("hello");
    expect(r.code).toBe(3);
    expect(r.timedOut).toBeFalse();
  });

  test("captures stderr", async () => {
    const r = await runShellPassthrough("echo oops 1>&2", "/tmp");
    expect(r.out).toContain("oops");
  });

  test("empty output yields empty out", async () => {
    const r = await runShellPassthrough("true", "/tmp");
    expect(r.out).toBe("");
    expect(r.code).toBe(0);
  });
});

describe("failurePostText (A2)", () => {
  const failure = (stopReason: string, errorMessage?: string) => ({
    role: "assistant",
    content: [{ type: "text", text: "" }],
    stopReason,
    errorMessage,
  });

  test("error stopReason posts the errorMessage", () => {
    expect(failurePostText([failure("error", "boom")], false)).toBe("boom");
  });

  test("error without errorMessage posts a fallback", () => {
    expect(failurePostText([failure("error")], false)).toBe("run failed");
  });

  test("aborted with errorMessage posts when the run was not user-stopped", () => {
    expect(failurePostText([failure("aborted", "interrupted")], false)).toBe(
      "interrupted",
    );
  });

  test("aborted run shaped stopReason=error is suppressed when user-stopped", () => {
    // pi's stream layer maps ctx.abort() to stopReason "error" +
    // errorMessage "This operation was aborted" (verified in a live
    // session, 2026-09-10). /stop, /reset and the mid-run interrupt set
    // the user-stopped flag, so the failure post is expected noise.
    expect(
      failurePostText([failure("error", "This operation was aborted")], true),
    ).toBeNull();
  });

  test("aborted run shaped stopReason=error is suppressed even when NOT user-stopped", () => {
    // The user-stopped flag can race a re-wake's turn_start reset (the
    // aborted run's agent_end runs AFTER the fresh run started). The
    // abort marker itself is the signal — suppress unconditionally.
    expect(
      failurePostText([failure("error", "This operation was aborted")], false),
    ).toBeNull();
  });

  test("genuine error is trimmed to its first line, no stack", () => {
    expect(
      failurePostText(
        [failure("error", "boom line1\n    at stack frame (x.js:1:1)")],
        false,
      ),
    ).toBe("boom line1");
  });

  test("run-level timeout posts the short marker", () => {
    expect(
      failurePostText(
        [failure("error", "request timed out after 30000ms")],
        false,
      ),
    ).toBe("timed out");
  });

  test("run-level rate limit posts the short marker", () => {
    expect(
      failurePostText([failure("error", "429 Too Many Requests")], false),
    ).toBe("rate limited, retrying");
  });

  test("aborted with errorMessage is silent when the user stopped the run", () => {
    expect(
      failurePostText([failure("aborted", "interrupted")], true),
    ).toBeNull();
  });

  test("aborted without errorMessage is silent", () => {
    expect(failurePostText([failure("aborted")], false)).toBeNull();
  });

  test("normal stop is silent", () => {
    expect(failurePostText([failure("stop")], false)).toBeNull();
  });

  test("no messages or non-assistant last message is silent", () => {
    expect(failurePostText([], false)).toBeNull();
    expect(failurePostText([{ role: "user", content: [] }], false)).toBeNull();
  });
});

describe("channelError", () => {
  test("abort strings are suppressed (null)", () => {
    expect(channelError("This operation was aborted")).toBeNull();
    expect(channelError("Command aborted")).toBeNull();
    expect(
      channelError(
        new DOMException("This operation was aborted", "AbortError"),
      ),
    ).toBeNull();
  });

  test("genuine error: first line only, no stack, capped at 200 chars", () => {
    expect(
      channelError(
        new Error(
          "first line of failure\n    at foo (bar.js:1:1)\n    at main",
        ),
      ),
    ).toBe("first line of failure");
    expect(channelError(new Error("x".repeat(500)))).toHaveLength(200);
    expect(channelError(new Error("x".repeat(100)))).toHaveLength(100);
  });

  test("timeout markers", () => {
    expect(channelError(new Error("request timed out after 30000ms"))).toBe(
      "timed out",
    );
    const e = new Error("connect");
    (e as any).code = "ETIMEDOUT";
    expect(channelError(e)).toBe("timed out");
    expect(
      channelError(new DOMException("The operation timed out", "TimeoutError")),
    ).toBe("timed out");
  });

  test("rate limit markers", () => {
    const e = new Error("response error");
    (e as any).status = 429;
    expect(channelError(e)).toBe("rate limited, retrying");
    expect(channelError(new Error("rate limit exceeded"))).toBe(
      "rate limited, retrying",
    );
  });

  test("ENOSPC marker", () => {
    const e = new Error("write /tmp/x: no space left on device");
    (e as any).code = "ENOSPC";
    expect(channelError(e)).toBe("disk full");
  });

  test("empty input yields empty string (fallback), null/undefined suppressed", () => {
    expect(channelError("")).toBe("");
    expect(channelError(null)).toBeNull();
    expect(channelError(undefined)).toBeNull();
  });

  test("sensitive text is redacted in the fallback line", () => {
    expect(
      channelError(new Error("fetch failed: Bearer sk-abcdefghijklmnop1234")),
    ).toBe("fetch failed: Bearer [REDACTED]");
  });
});

describe("earlySendText", () => {
  const toolCall = { type: "toolCall", toolName: "bash", arguments: {} };

  test("intermediate assistant message (text + toolCall) returns the text", () => {
    const msg = {
      role: "assistant",
      content: [{ type: "text", text: "checking files" }, toolCall],
    };
    expect(earlySendText(msg)).toBe("checking files");
  });

  test("multiple text blocks are joined", () => {
    const msg = {
      role: "assistant",
      content: [
        { type: "text", text: "a " },
        { type: "text", text: "b" },
        toolCall,
      ],
    };
    expect(earlySendText(msg)).toBe("a b");
  });

  test("final (text only, no toolCall) returns null", () => {
    const msg = {
      role: "assistant",
      content: [{ type: "text", text: "done" }],
    };
    expect(earlySendText(msg)).toBeNull();
  });

  test("no text blocks returns null", () => {
    const msg = { role: "assistant", content: [toolCall] };
    expect(earlySendText(msg)).toBeNull();
  });

  test("non-assistant message returns null", () => {
    expect(
      earlySendText({
        role: "user",
        content: [{ type: "text", text: "hi" }, toolCall],
      }),
    ).toBeNull();
    expect(earlySendText(undefined)).toBeNull();
    expect(earlySendText(null)).toBeNull();
  });

  test("thinking tags are stripped from the result", () => {
    const msg = {
      role: "assistant",
      content: [
        {
          type: "text",
          text: "\u003cthink\u003epondering\u003c/think\u003eabout to read the file",
        },
        toolCall,
      ],
    };
    expect(earlySendText(msg)).toBe("about to read the file");
  });

  test("whitespace-only text returns null", () => {
    const msg = {
      role: "assistant",
      content: [{ type: "text", text: "  \n " }, toolCall],
    };
    expect(earlySendText(msg)).toBeNull();
  });
});

// ─── Integration: extension handlers with mocked fetch ──────────────────────
// Exercises the default factory's message_end / agent_end / handleInbound
// wiring without a live Discord: channel config from a temp workspace,
// global fetch captured, pi.sendMessage captured.

describe("extension handlers (A1/A2/A4)", () => {
  let tmp = "";
  let pi: any;
  let ctx: any;
  let handlers: Record<string, (...a: any[]) => any> = {};
  let sent: { m: any; o?: any }[] = [];
  let fetchCalls: { url: string; method: string; body?: any }[] = [];
  // sequential message ids: the working frame is out1, a later live-text
  // post (SPEC B) gets out2, so id-based assertions stay unambiguous
  let msgN = 0;
  const realFetch = globalThis.fetch;

  // Bounded clock-time flush for the fire-and-forget re-wake kick
  // (cancel branch, index.ts): the kick's send chain needs real
  // event-loop turns that competing macrotasks steal under load, so a
  // fixed setImmediate-hop budget flakes (MEDIUM-1, review 3005244).
  // All real clocks are faked under jest.useFakeTimers (Date/performance/
  // hrtime move with advanceTimersByTime), so the budget is virtual
  // clock time: 25ms steps (settle-tick cadence) interleaved with a real
  // loop turn. Exits as soon as cond() holds or 20s of clock elapses.
  // (20s = 800 ticks: instrumented kick chains need 1-6 ticks normally,
  // up to 147 under 20-process load — the send chain's real localhost
  // fetches stretch across many loop turns when the CPU is contended.)
  // Only call under fake timers.
  const flushUntil = async (cond: () => boolean, budgetMs = 20000) => {
    for (let used = 0; used < budgetMs && !cond(); used += 25) {
      jest.advanceTimersByTime(25);
      await new Promise<void>((r) => setImmediate(r));
    }
  };

  const inbound = (body: string, id: string): ChannelMessage => ({
    channelId: "ch1",
    channelName: "Test",
    channelType: "discord",
    messageId: id,
    from: "u",
    fromId: "uid",
    body,
    timestamp: new Date().toISOString(),
    attachments: [],
    isRoom: false,
  });

  beforeEach(() => {
    tmp = fs.mkdtempSync(path.join(os.tmpdir(), "piscord-test-"));
    fs.mkdirSync(path.join(tmp, ".pi"), { recursive: true });
    fs.writeFileSync(
      path.join(tmp, ".pi", "settings.json"),
      JSON.stringify({
        channels: [
          {
            id: "ch1",
            name: "Test",
            type: "discord",
            botToken: "tok1",
            ownerUserId: "uid",
            ack: true,
          },
        ],
      }),
    );

    handlers = {};
    sent = [];
    midTurnQueues.clear();
    pendingAttachments.clear();
    verboseOverride.clear();
    fetchCalls = [];
    msgN = 0;
    pi = {
      registerMessageRenderer: () => {},
      registerTool: () => {},
      on: (n: string, fn: any) => {
        handlers[n] = fn;
      },
      sendMessage: (m: any, o?: any) => {
        sent.push({ m, o });
      },
    };
    extension(pi);
    ctx = {
      cwd: tmp,
      ui: { setStatus: () => {} },
      isIdle: () => true,
      hasPendingMessages: () => false,
      abort: () => {},
    };
    globalThis.fetch = (async (url: any, init?: any) => {
      fetchCalls.push({
        url: String(url),
        method: init?.method ?? "GET",
        body: init?.body,
      });
      let id = "out1";
      if (
        init?.method === "POST" &&
        String(url).endsWith("/channels/ch1/messages")
      )
        id = `out${++msgN}`;
      return {
        ok: true,
        status: 200,
        json: async () => ({ id }),
        text: async () => "",
      };
    }) as any;
  });

  afterEach(async () => {
    clearDiscordStatesForTest(); // no auto-react suppression leaks across tests
    jest.useRealTimers();
    // Drop leftover re-wake state BEFORE the cleanup agent_end, or it would
    // start an in-flight re-wake whose sendToPi continuation leaks into the
    // next test's mock pi (shared `sent` binding).
    midTurnQueues.clear();
    pendingAttachments.clear();
    clearAllInterrupts(); // armed interrupt timers + in-flight flags
    setInterruptCtx(null);
    await handlers.agent_end?.({ messages: [] }, ctx); // clears any typing interval
    globalThis.fetch = realFetch;
    fs.rmSync(tmp, { recursive: true, force: true });
  });

  test("A1: message_end early send unreacts the 👀 ack on the last inbound", async () => {
    await handleInbound(pi, inbound("hello", "m123"), ctx);
    await handlers.turn_start(null, ctx);
    // step-final (text only) is the early-send path; intermediate
    // (text + toolCall) lands in the SPEC B live-text slot instead
    const stepFinal = {
      role: "assistant",
      content: [{ type: "text", text: "working on it" }],
    };
    await handlers.message_end({ message: stepFinal }, ctx);

    const posted = fetchCalls.filter(
      (c) => c.method === "POST" && c.url.endsWith("/channels/ch1/messages"),
    );
    expect(posted.length).toBeGreaterThan(0);
    const unreact = fetchCalls.find(
      (c) =>
        c.method === "DELETE" &&
        c.url.includes("/channels/ch1/messages/m123/reactions/"),
    );
    expect(unreact).toBeDefined();
  });

  test("message_end early send strips <reply-to> and threads to the tagged inbound", async () => {
    await handleInbound(pi, inbound("hello", "111"), ctx);
    await handlers.turn_start(null, ctx);
    const stepFinal = {
      role: "assistant",
      content: [{ type: "text", text: "<reply-to:111>\nhi there" }],
    };
    await handlers.message_end({ message: stepFinal }, ctx);

    const posts = fetchCalls.filter(
      (c) => c.method === "POST" && c.url.endsWith("/channels/ch1/messages"),
    );
    const post = posts[posts.length - 1]; // last: earlier POSTs are the activity placeholder
    expect(post).toBeDefined();
    const body = JSON.parse(post!.body);
    expect(body.content).toBe("hi there");
    expect(body.message_reference?.message_id).toBe("111");
  });

  test("message_end invalid <reply-to> falls back to the last inbound", async () => {
    await handleInbound(pi, inbound("hello", "111"), ctx);
    await handlers.turn_start(null, ctx);
    const stepFinal = {
      role: "assistant",
      content: [{ type: "text", text: "<reply-to:999>\nhi there" }],
    };
    await handlers.message_end({ message: stepFinal }, ctx);

    const posts = fetchCalls.filter(
      (c) => c.method === "POST" && c.url.endsWith("/channels/ch1/messages"),
    );
    const post = posts[posts.length - 1]; // last: earlier POSTs are the activity placeholder
    const body = JSON.parse(post!.body);
    expect(body.content).toBe("hi there");
    expect(body.message_reference?.message_id).toBe("111");
  });

  test("message_end untagged final threads to the last inbound", async () => {
    await handleInbound(pi, inbound("hello", "111"), ctx);
    await handlers.turn_start(null, ctx);
    const stepFinal = {
      role: "assistant",
      content: [{ type: "text", text: "hi there" }],
    };
    await handlers.message_end({ message: stepFinal }, ctx);

    const posts = fetchCalls.filter(
      (c) => c.method === "POST" && c.url.endsWith("/channels/ch1/messages"),
    );
    const post = posts[posts.length - 1]; // last: earlier POSTs are the activity placeholder
    const body = JSON.parse(post!.body);
    expect(body.message_reference?.message_id).toBe("111");
  });

  test("A2: agent_end posts errorMessage on a failed run", async () => {
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    const failure = {
      role: "assistant",
      content: [{ type: "text", text: "" }],
      stopReason: "error",
      errorMessage: "boom",
    };
    await handlers.agent_end({ messages: [failure] }, ctx);

    const posts = fetchCalls.filter(
      (c) => c.method === "POST" && c.url.endsWith("/channels/ch1/messages"),
    );
    const post = posts[posts.length - 1]; // last: earlier POSTs are the activity placeholder
    expect(post).toBeDefined();
    // Op status is bare prose (no fence, no tag - v4 §2.3 + 2026-10-20):
    expect(JSON.parse(post!.body).content).toBe(styleGuard("boom"));
  });

  test("A2: user /stop abort is not posted as a run error", async () => {
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    ctx.isIdle = () => false; // a run is active when /stop lands
    fetchCalls.length = 0;
    await handleInbound(pi, inbound("/stop", "m2"), ctx);

    const failure = {
      role: "assistant",
      content: [{ type: "text", text: "" }],
      stopReason: "aborted",
      errorMessage: "aborted",
    };
    await handlers.agent_end({ messages: [failure] }, ctx);

    const errors = fetchCalls.filter(
      (c) =>
        c.method === "POST" &&
        c.url.endsWith("/channels/ch1/messages") &&
        String(JSON.parse(c.body).content).startsWith("[!]"),
    );
    expect(errors.length).toBe(0);
  });

  test("activity block: 0 tool calls -> deleted at agent_end (no done line)", async () => {
    verboseOverride.set("ch1", 2); // display gate: block renders only when verbose (level 2 = all)
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    await handlers.turn_start(null, ctx);
    const pureTextFinal = {
      role: "assistant",
      content: [{ type: "text", text: "hi there" }],
    };
    await handlers.agent_end({ messages: [pureTextFinal] }, ctx);

    const placeholder = fetchCalls.find(
      (c) =>
        c.method === "POST" &&
        c.url.endsWith("/channels/ch1/messages") &&
        String(JSON.parse(c.body).content).includes("┌ working"), // fenced working frame (live-frame unification)
    );
    expect(placeholder).toBeDefined(); // live block existed during the run
    const deleted = fetchCalls.find(
      (c) => c.method === "DELETE" && c.url.includes("/messages/out1"),
    );
    expect(deleted).toBeDefined(); // 0 calls: block deleted, not left behind
    const doneEdit = fetchCalls.find(
      (c) => c.method === "PATCH" && String(c.body).includes("┗ done"),
    );
    expect(doneEdit).toBeUndefined(); // no "done · 0 calls" line
  });

  test("activity block: 1+ tool calls -> closed with done line (regression)", async () => {
    verboseOverride.set("ch1", 2); // display gate: block renders only when verbose (level 2 = all)
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    await handlers.turn_start(null, ctx);
    await handlers.tool_call(
      { toolName: "bash", input: { command: "ls" } },
      ctx,
    );
    const withTool = {
      role: "assistant",
      content: [
        { type: "text", text: "done" },
        { type: "toolCall", toolName: "bash", arguments: {} },
      ],
    };
    await handlers.agent_end({ messages: [withTool] }, ctx);

    const doneEdit = fetchCalls.find(
      (c) =>
        c.method === "PATCH" &&
        String(JSON.parse(c.body).content).includes("┌ done · 1 call"),
    );
    expect(doneEdit).toBeDefined(); // block stays, shows the finished run
    // live-frame unification: the morph is an edit of the SAME placeholder
    // message (mock id out1), not a fresh post at run end
    expect(doneEdit!.url).toContain("/channels/ch1/messages/out1");
    expect(
      fetchCalls.some(
        (c) =>
          c.method === "POST" &&
          String(JSON.parse(c.body ?? "{}").content ?? "").includes("┌ done"),
      ),
    ).toBe(false);
    const doneBody = String(JSON.parse(doneEdit!.body).content);
    expect(doneBody).toContain("│ └ bash ls"); // sub-step, last = └
    // multi-line frame lives in a code fence (mockup3), same fence() as
    // every other machine line
    expect(doneBody.startsWith("```\n")).toBe(true);
    expect(doneBody.trimEnd()).toMatch(/\n└\n```$/); // closing bar, then fence
    const deleted = fetchCalls.find(
      (c) => c.method === "DELETE" && c.url.includes("/messages/out1"),
    );
    expect(deleted).toBeUndefined();
  });

  test("live tick re-renders the full working frame in place (same message)", async () => {
    jest.useFakeTimers();
    verboseOverride.set("ch1", 2);
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    await handlers.turn_start(null, ctx);
    // settle the fire-and-forget placeholder post (microtasks, no timers)
    await Promise.resolve();
    await Promise.resolve();
    await Promise.resolve();
    // level-2 placeholder IS the 0-call working frame (live-frame unification)
    const placeholder = fetchCalls.find(
      (c) =>
        c.method === "POST" &&
        c.url.endsWith("/channels/ch1/messages") &&
        String(JSON.parse(c.body).content).includes("┌ working · 0 calls"),
    );
    expect(placeholder).toBeDefined();

    const edits = () =>
      fetchCalls
        .filter((c) => c.method === "PATCH" && c.url.includes("/messages/"))
        .map((c) =>
          String(
            (typeof c.body === "string" ? JSON.parse(c.body) : c.body).content,
          ),
        );

    // a tool call edits the SAME message with the full working frame
    await handlers.tool_call(
      { toolName: "bash", input: { command: "git push" } },
      ctx,
    );
    let last = edits().at(-1)!;
    expect(last).toContain("┌ working · 1 call");
    expect(last).toContain("│ └ bash git push");
    expect(last.trimEnd()).toMatch(/\n└\n```$/); // full frame, fenced
    expect((last.match(/^```/gm) ?? []).length).toBe(2); // exactly one fence

    // 5s-step tick: still the full frame (not a one-line status), same
    // message id, elapsed stepped to 5s
    jest.advanceTimersByTime(5001);
    last = edits().at(-1)!;
    expect(last).toContain("┌ working · 1 call · 5s");
    expect(last).toContain("│ └ bash git push");
    expect((last.match(/^```/gm) ?? []).length).toBe(2); // exactly one fence (F1)
    const tickEdit = fetchCalls
      .filter((c) => c.method === "PATCH" && c.url.includes("/messages/"))
      .at(-1);
    expect(tickEdit!.url).toContain("/channels/ch1/messages/out1");
    // the tick never posts a fresh working message
    expect(
      fetchCalls.filter(
        (c) =>
          c.method === "POST" &&
          c.url.endsWith("/channels/ch1/messages") &&
          String(JSON.parse(c.body).content).includes("┌ working"),
      ).length,
    ).toBe(1);

    // a second call grows the frame in place; the tick keeps the shape
    await handlers.tool_call(
      { toolName: "edit", input: { path: "a.txt" } },
      ctx,
    );
    jest.advanceTimersByTime(5000);
    last = edits().at(-1)!;
    expect(last).toContain("┌ working · 2 calls · 10s");
    expect(last).toContain("│ ├ bash git push");
    expect(last).toContain("│ └ edit a.txt");
  });

  test("working frame stalls after the max lifetime without agent_end (#84 L3)", async () => {
    jest.useFakeTimers();
    verboseOverride.set("ch1", 2);
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    await handlers.turn_start(null, ctx);
    // settle the fire-and-forget placeholder post (microtasks, no timers)
    await Promise.resolve();
    await Promise.resolve();
    await Promise.resolve();
    const placeholder = fetchCalls.find(
      (c) =>
        c.method === "POST" &&
        c.url.endsWith("/channels/ch1/messages") &&
        String(JSON.parse(c.body).content).includes("┌ working · 0 calls"),
    );
    expect(placeholder).toBeDefined();

    const edits = () =>
      fetchCalls
        .filter(
          (c) =>
            c.method === "PATCH" && c.url.includes("/channels/ch1/messages/"),
        )
        .map((c) =>
          String(
            (typeof c.body === "string" ? JSON.parse(c.body) : c.body).content,
          ),
        );

    // still counting up well before the cap
    jest.advanceTimersByTime(5000);
    expect(edits().at(-1)).toContain("┌ working · 0 calls · 5s");

    // cross the 30-min cap: the run never ended (no agent_end), so the tick
    // settles the frame to its TRUE state (stalled) and stops — it must not
    // count up forever.
    jest.advanceTimersByTime(workingMaxMs() - 5000 + 5000);
    await Promise.resolve();
    await Promise.resolve();
    expect(edits().at(-1)).toBe("run stalled - /stop to abort");

    // tick is gone: advancing further must not edit the frame again
    const n = edits().length;
    jest.advanceTimersByTime(10000);
    expect(edits().length).toBe(n);
  });

  test("verbose off: no tool-call block created, sent, or edited (#38)", async () => {
    // ch1 has no forwardToolCalls and no override -> verbose off
    expect(isVerbose(loadChannelConfig(ctx.cwd)[0]!)).toBe(false);
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    await handlers.turn_start(null, ctx);
    await handlers.tool_call(
      { toolName: "bash", input: { command: "ls" } },
      ctx,
    );
    await handlers.tool_call(
      { toolName: "read", input: { path: "/tmp/a.md" } },
      ctx,
    );
    const pureTextFinal = {
      role: "assistant",
      content: [{ type: "text", text: "hi there" }],
    };
    await handlers.agent_end({ messages: [pureTextFinal] }, ctx);

    const posts = fetchCalls.filter(
      (c) => c.method === "POST" && c.url.endsWith("/channels/ch1/messages"),
    );
    expect(
      posts.filter((c) =>
        String(JSON.parse(c.body).content).includes("┌ working"),
      ).length,
    ).toBe(0); // no working frame placeholder, no tool frame
    const edits = fetchCalls.filter((c) => c.method === "PATCH");
    expect(edits.length).toBe(0); // nothing to edit, no done line either
    const deleted = fetchCalls.filter((c) => c.method === "DELETE");
    expect(deleted.length).toBe(0); // no block to delete at run end
    // the final still lands
    expect(
      posts.some((c) =>
        String(JSON.parse(c.body).content).includes("hi there"),
      ),
    ).toBe(true);
  });

  test("verbose-off run leaves the previous run's done line untouched (#38)", async () => {
    // run 1: verbose on — block created, closed with a done line
    verboseOverride.set("ch1", 2);
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    await handlers.turn_start(null, ctx);
    await handlers.tool_call(
      { toolName: "bash", input: { command: "ls" } },
      ctx,
    );
    const fin = (t: string) => ({
      role: "assistant",
      content: [{ type: "text", text: t }],
    });
    await handlers.agent_end({ messages: [fin("one")] }, ctx);
    expect(
      fetchCalls.some(
        (c) => c.method === "PATCH" && String(c.body).includes("┌ done"),
      ),
    ).toBe(true); // run 1's frame closed

    // run 2: verbose off, no tool calls — statusMsgId still points at
    // run 1's line; agent_end must not delete or re-edit it
    verboseOverride.set("ch1", 0);
    fetchCalls.length = 0;
    await handleInbound(pi, inbound("again", "m2"), ctx);
    await handlers.turn_start(null, ctx);
    await handlers.agent_end({ messages: [fin("two")] }, ctx);
    expect(fetchCalls.some((c) => c.method === "PATCH")).toBe(false); // no done line (nothing to close)
    expect(fetchCalls.some((c) => c.method === "DELETE")).toBe(false);
    // run 2's final still posts
    expect(
      fetchCalls.some(
        (c) =>
          c.method === "POST" &&
          c.url.endsWith("/channels/ch1/messages") &&
          String(JSON.parse(c.body).content).includes("two"),
      ),
    ).toBe(true);
  });

  test("verbose on->off mid-run deletes the live block (#38)", async () => {
    verboseOverride.set("ch1", 2);
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    await handlers.turn_start(null, ctx);
    await handlers.tool_call(
      { toolName: "bash", input: { command: "ls" } },
      ctx,
    );
    expect(
      fetchCalls.some(
        (c) =>
          c.method === "POST" &&
          c.url.endsWith("/channels/ch1/messages") &&
          String(JSON.parse(c.body).content).includes("┌ working"), // fenced working frame (live-frame unification)
      ),
    ).toBe(true); // live block exists (mock id out1)

    // flip verbose off while the run is in flight
    await handleInbound(pi, inbound("/verbose off", "m2"), ctx);
    const del = fetchCalls.find(
      (c) =>
        c.method === "DELETE" && c.url.includes("/channels/ch1/messages/out1"),
    );
    expect(del).toBeDefined(); // live block deleted on the transition

    // next tool call: no edit (no block to update)
    fetchCalls.length = 0;
    await handlers.tool_call(
      { toolName: "bash", input: { command: "pwd" } },
      ctx,
    );
    expect(fetchCalls.some((c) => c.method === "PATCH")).toBe(false);

    // run end: done line no-ops, final still posts
    await handlers.agent_end(
      {
        messages: [
          { role: "assistant", content: [{ type: "text", text: "done" }] },
        ],
      },
      ctx,
    );
    expect(
      fetchCalls.some(
        (c) => c.method === "PATCH" && String(c.body).includes("┌ done"),
      ),
    ).toBe(false); // no done frame after the live block was deleted
    expect(
      fetchCalls.some(
        (c) =>
          c.method === "POST" &&
          c.url.endsWith("/channels/ch1/messages") &&
          String(JSON.parse(c.body).content).includes("done"),
      ),
    ).toBe(true);
  });

  test("verbose off->on mid-run re-arms the block on the next tool call (#38)", async () => {
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    await handlers.turn_start(null, ctx);
    await handlers.tool_call(
      { toolName: "bash", input: { command: "ls" } },
      ctx,
    );
    expect(
      fetchCalls
        .filter(
          (c) =>
            c.method === "POST" && c.url.endsWith("/channels/ch1/messages"),
        )
        .filter((c) =>
          String(JSON.parse(c.body).content).includes("┌ working"),
        ),
    ).toHaveLength(0); // quiet run so far

    verboseOverride.set("ch1", 2);
    await handlers.tool_call(
      { toolName: "bash", input: { command: "pwd" } },
      ctx,
    );
    // fresh block created by the next tool call (no stale placeholder to edit)
    const toolPost = fetchCalls.find(
      (c) =>
        c.method === "POST" &&
        c.url.endsWith("/channels/ch1/messages") &&
        String(JSON.parse(c.body).content).includes("┌ working") &&
        String(JSON.parse(c.body).content).includes("bash pwd"),
    );
    expect(toolPost).toBeDefined();
  });

  test("/status reflects the verbose state (#38)", async () => {
    const statusPost = () => {
      const posts = fetchCalls.filter(
        (c) => c.method === "POST" && c.url.endsWith("/channels/ch1/messages"),
      );
      return posts
        .map((p) => String(JSON.parse(p.body).content))
        .find((t) => t.includes("[status]"));
    };
    // off by default: quiet
    await handleInbound(pi, inbound("/status", "m1"), ctx);
    let st = statusPost();
    expect(st).toBeDefined();
    expect(st).toContain("quiet");
    expect(st).not.toContain("verbose");

    // /verbose on (legacy = level 2): the next /status says verbose
    await handleInbound(pi, inbound("/verbose on", "m2"), ctx);
    expect(
      fetchCalls.some(
        (c) =>
          c.method === "POST" &&
          c.url.endsWith("/channels/ch1/messages") &&
          String(JSON.parse(c.body).content).includes("[ok] verbose: 2"),
      ),
    ).toBe(true);
    fetchCalls.length = 0;
    await handleInbound(pi, inbound("/status", "m3"), ctx);
    st = statusPost();
    expect(st).toBeDefined();
    expect(st).toContain("verbose 2");

    // #47: queue depth in the status line
    queueMidTurnInbound(
      "ch1",
      inbound("queued q1", "m4"),
      "text",
      "discord/Test",
      "text",
      false,
    );
    queueMidTurnInbound(
      "ch1",
      inbound("queued q2", "m5"),
      "text",
      "discord/Test",
      "text",
      false,
    );
    fetchCalls.length = 0;
    await handleInbound(pi, inbound("/status", "m6"), ctx);
    st = statusPost();
    expect(st).toContain("queue 2");

    // #47: hold state in the status line (queue survives the hold)
    await handleInbound(pi, inbound("/hold on", "m7"), ctx);
    fetchCalls.length = 0;
    await handleInbound(pi, inbound("/status", "m8"), ctx);
    st = statusPost();
    expect(st).toContain("hold on");
    expect(st).toContain("queue 2");

    // release: idle mock runs the oldest now; the rest chain via the
    // re-wake loop (one run each) and stay queued until then
    await handleInbound(pi, inbound("/hold off", "m9"), ctx);
    await new Promise((r) => setImmediate(r));
    fetchCalls.length = 0;
    await handleInbound(pi, inbound("/status", "m10"), ctx);
    st = statusPost();
    expect(st).not.toContain("hold on");
    expect(st).toContain("queue 1");

    // drain the last entry (the mock never fires agent_end, so no
    // re-wake): status is back to a clean line
    midTurnQueues.delete("ch1");
    fetchCalls.length = 0;
    await handleInbound(pi, inbound("/status", "m11"), ctx);
    st = statusPost();
    expect(st).not.toContain("hold on");
    expect(st).not.toContain("queue");
  });

  test("A4: /stop drains the channel's queued mid-turn inbounds", async () => {
    ctx.isIdle = () => false; // inbounds while a run is active get queued
    await handleInbound(pi, inbound("followup", "m1"), ctx);
    expect(sent.length).toBe(0); // queued, not sent yet
    expect(midTurnQueues.get("ch1")?.length).toBe(1);

    await handleInbound(pi, inbound("/stop", "m2"), ctx);
    expect(midTurnQueues.has("ch1")).toBe(false); // /stop drained the queue

    // The run ends; nothing queued, so no re-wake send.
    await handlers.agent_end({ messages: [] }, ctx);
    expect(sent.length).toBe(0);
  });

  test("mid-turn inbound is queued and re-woken at agent_end (no swallow)", async () => {
    ctx.isIdle = () => false; // a run is in flight
    await handleInbound(pi, inbound("pi-bg webhook callback", "m100"), ctx);
    // While busy: NOT sent to pi, queued for a guaranteed re-wake instead.
    expect(sent.length).toBe(0);
    expect(midTurnQueues.get("ch1")?.length).toBe(1);

    // The run ends → agent_end re-wakes the queued message as a fresh run.
    await handlers.agent_end({ messages: [] }, ctx);
    expect(sent.length).toBe(1); // re-wake fired a new run
    expect(sent[0].o.triggerTurn).toBe(true);
    // Full inbound context preserved (processed exactly as a fresh inbound).
    expect(sent[0].m.details.body).toBe("pi-bg webhook callback");
    expect(sent[0].m.details.messageId).toBe("m100");
    expect(midTurnQueues.has("ch1")).toBe(false); // queue drained
  });

  test("multiple mid-turn inbounds re-wake in order (FIFO)", async () => {
    ctx.isIdle = () => false;
    await handleInbound(pi, inbound("first", "m1"), ctx);
    await handleInbound(pi, inbound("second", "m2"), ctx);
    expect(midTurnQueues.get("ch1")?.length).toBe(2);

    // First agent_end re-wakes only the oldest; the rest stay queued.
    await handlers.agent_end({ messages: [] }, ctx);
    expect(sent.length).toBe(1);
    expect(sent[0].m.details.body).toBe("first");
    expect(midTurnQueues.get("ch1")?.length).toBe(1);

    // Second agent_end re-wakes the next; queue fully drained.
    await handlers.agent_end({ messages: [] }, ctx);
    expect(sent.length).toBe(2);
    expect(sent[1].m.details.body).toBe("second");
    expect(midTurnQueues.has("ch1")).toBe(false);
  });

  test("mid-turn inbound with attachments keeps full context on re-wake", async () => {
    ctx.isIdle = () => false;
    const withAtt = inbound("look at this", "m200");
    withAtt.attachments = [
      { id: "a1", filename: "x.jpg", contentType: "image/jpeg", size: 100 },
    ];
    await handleInbound(pi, withAtt, ctx);
    expect(sent.length).toBe(0);
    expect(midTurnQueues.get("ch1")?.length).toBe(1);

    await handlers.agent_end({ messages: [] }, ctx);
    expect(sent.length).toBe(1);
    // The re-wake re-processed the message as a fresh inbound: the attachment
    // context block is present in the LLM content.
    expect(sent[0].m.content).toContain("x.jpg");
    expect(sent[0].m.details.body).toContain("look at this");
  });

  test("idle inbound is sent immediately, not queued", async () => {
    ctx.isIdle = () => true;
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    expect(sent.length).toBe(1);
    expect(midTurnQueues.has("ch1")).toBe(false);
  });

  test("no double-processing: a busy inbound is queued, not also sent", async () => {
    ctx.isIdle = () => false;
    await handleInbound(pi, inbound("callback", "m1"), ctx);
    // Exactly one owner: queued (not sent now), and present in the queue.
    expect(sent.length).toBe(0);
    expect(midTurnQueues.get("ch1")?.length).toBe(1);
    await handlers.agent_end({ messages: [] }, ctx);
    // The re-wake sends it exactly once (not a second time).
    expect(sent.length).toBe(1);
  });

  describe("mid-run interrupt", () => {
    let abortCount: number;
    let idle: boolean;

    beforeEach(() => {
      jest.useFakeTimers();
      abortCount = 0;
      idle = false;
      // Model the real session: abort kills the run and it settles (idle).
      ctx.isIdle = () => idle;
      ctx.abort = () => {
        abortCount += 1;
        idle = true;
      };
      setInterruptCtx(ctx);
    });

    afterEach(() => {
      clearDiscordStatesForTest(); // no auto-react suppression leaks across tests
      resetRuntimeStateForTest(); // sessionStartTs/held/verbose: no leaks
      setInterruptCtx(null);
      clearAllInterrupts();
      pendingInterrupts.clear();
      queuedAcks.clear();
      jest.useRealTimers();
    });

    test("plain message during a run interrupts after the timeout (abort + fresh run)", async () => {
      expect(idle).toBe(false);
      await handleInbound(pi, inbound("redirect me", "m1"), ctx);
      expect(sent.length).toBe(0);
      expect(midTurnQueues.get("ch1")?.length).toBe(1);
      expect(pendingInterrupts.get("ch1")?.length).toBe(1);

      jest.advanceTimersByTime(interruptStepTimeoutMs() - 1);
      expect(abortCount).toBe(0);
      expect(sent.length).toBe(0);
      jest.advanceTimersByTime(1);

      // Force-delivered: in-flight step aborted, message sent as a fresh run
      // after the session settles.
      expect(abortCount).toBe(1);
      expect(sent.length).toBe(1);
      expect(sent[0].m.content).toContain("redirect me");
      expect(sent[0].m.details.body).toBe("redirect me");
      expect(sent[0].m.details.messageId).toBe("m1");
      expect(sent[0].o).toMatchObject({
        triggerTurn: true,
        deliverAs: "steer",
      });
      // Consumed from the re-wake queue: no second delivery at agent_end.
      expect(midTurnQueues.has("ch1")).toBe(false);
    });

    test("no duplicate delivery after interrupt (agent_end sees an empty queue)", async () => {
      await handleInbound(pi, inbound("redirect", "m1"), ctx);
      jest.advanceTimersByTime(interruptStepTimeoutMs());
      expect(sent.length).toBe(1);

      // The aborted run's agent_end: nothing queued, so no re-wake send.
      await handlers.agent_end({ messages: [] }, ctx);
      expect(sent.length).toBe(1);
      expect(midTurnQueues.has("ch1")).toBe(false);
    });

    test("aborted run from an interrupt posts no failure line", async () => {
      await handleInbound(pi, inbound("redirect", "m1"), ctx);
      jest.advanceTimersByTime(interruptStepTimeoutMs());
      expect(abortCount).toBe(1);

      // pi's aborted run ends with an empty assistant message shaped
      // stopReason "error" + errorMessage "This operation was aborted".
      // userStoppedRun suppresses the failure post for that shape.
      const fail = {
        role: "assistant",
        content: [{ type: "text", text: "" }],
        stopReason: "error",
        errorMessage: "This operation was aborted",
      };
      await handlers.agent_end({ messages: [fail] }, ctx);
      const posts = fetchCalls.filter(
        (c) => c.method === "POST" && c.url.endsWith("/messages"),
      );
      expect(
        posts.every(
          (p) => !String(JSON.parse(p.body).content).startsWith("[!]"),
        ),
      ).toBe(true);
    });

    test("no raw abort string reaches the send mock when the user-stopped flag raced", async () => {
      // The race: the interrupt sets the flag, then the re-wake's fresh
      // run starts (turn_start resets the flag) BEFORE the aborted run's
      // agent_end runs its failure check. The abort marker must still
      // suppress the post.
      await handleInbound(pi, inbound("redirect", "m1"), ctx);
      jest.advanceTimersByTime(interruptStepTimeoutMs());
      expect(abortCount).toBe(1);
      // The fresh run's turn_start reset the flag (mock pi never fires
      // it, so drive it here, in the real pi's ordering).
      await handlers.turn_start(null, ctx);

      const fail = {
        role: "assistant",
        content: [{ type: "text", text: "" }],
        stopReason: "error",
        errorMessage: "This operation was aborted",
      };
      await handlers.agent_end({ messages: [fail] }, ctx);
      const posts = fetchCalls.filter(
        (c) => c.method === "POST" && c.url.endsWith("/messages"),
      );
      expect(
        posts.every(
          (p) => !String(JSON.parse(p.body).content).includes("aborted"),
        ),
      ).toBe(true);
    });

    test("aborted run with a genuine API error still posts the short marker", async () => {
      await handleInbound(pi, inbound("redirect", "m1"), ctx);
      jest.advanceTimersByTime(interruptStepTimeoutMs());
      expect(abortCount).toBe(1);
      await handlers.turn_start(null, ctx); // flag raced to false

      const fail = {
        role: "assistant",
        content: [{ type: "text", text: "" }],
        stopReason: "error",
        errorMessage: "429 Too Many Requests",
      };
      await handlers.agent_end({ messages: [fail] }, ctx);
      const posts = fetchCalls.filter(
        (c) => c.method === "POST" && c.url.endsWith("/messages"),
      );
      expect(
        posts.some(
          (p) =>
            String(JSON.parse(p.body).content) ===
            styleGuard("rate limited, retrying"),
        ),
      ).toBe(true);
    });

    test("command during a run is NOT interrupted", async () => {
      await handleInbound(pi, inbound("/status", "m1"), ctx);
      expect(midTurnQueues.has("ch1")).toBe(false);
      expect(pendingInterrupts.has("ch1")).toBe(false);
      jest.advanceTimersByTime(interruptStepTimeoutMs() * 3);
      expect(abortCount).toBe(0);
      expect(sent.length).toBe(0);
    });

    test("PISCORD_INTERRUPT_STEP_TIMEOUT_MS is honored", async () => {
      process.env.PISCORD_INTERRUPT_STEP_TIMEOUT_MS = "500";
      try {
        expect(interruptStepTimeoutMs()).toBe(500);
        await handleInbound(pi, inbound("go", "m1"), ctx);
        jest.advanceTimersByTime(499);
        expect(abortCount).toBe(0);
        jest.advanceTimersByTime(1);
        expect(abortCount).toBe(1);
        expect(sent.length).toBe(1);
      } finally {
        delete process.env.PISCORD_INTERRUPT_STEP_TIMEOUT_MS;
      }
    });

    test("invalid env value falls back to the 3000ms default", async () => {
      process.env.PISCORD_INTERRUPT_STEP_TIMEOUT_MS = "not-a-number";
      try {
        expect(interruptStepTimeoutMs()).toBe(3000);
        await handleInbound(pi, inbound("go", "m1"), ctx);
        jest.advanceTimersByTime(2999);
        expect(abortCount).toBe(0);
        jest.advanceTimersByTime(1);
        expect(abortCount).toBe(1);
      } finally {
        delete process.env.PISCORD_INTERRUPT_STEP_TIMEOUT_MS;
      }
    });

    // ── arm window pins ────────────────────────────────────────────
    // Mid-settle (an interrupt already in flight) arms at the 4x (12s)
    // window — the rapid-fire cascade guard (the in-flight disjunct).
    // Every other mid-run inbound arms the 3s default (quick cut-in);
    // machine wakes arm nothing from #177 on (queue-only). The
    // queued message always has the guaranteed re-wake as fallback, so
    // the longer window only changes WHEN the interrupt cuts in, never
    // WHETHER it delivers. (2026-10-06 abort RCA: a mid-run reply armed
    // the 3s DEFAULT mid-settle and expired mid-REST-POST; the 4x
    // window now keys off the in-flight state, not the sender.)

    test("mid-settle inbound arms the 4x in-flight window; #124 order intact", async () => {
      // The settle window (an interrupt already in flight) arms at 4x
      // via the in-flight disjunct — the arm must not double, shorten,
      // or reorder the #124 delivery.
      expect(idle).toBe(false);
      const baseSends = sent.length;
      const baseAborts = abortCount;
      ctx.abort = () => {
        abortCount += 1;
      }; // slow settle: interrupt stays in flight across the window
      // 1. Human m1 mid-run: 3s arm, fires, settle polling begins.
      await handleInbound(pi, inbound("first", "m1"), ctx);
      jest.advanceTimersByTime(interruptStepTimeoutMs());
      await Promise.resolve();
      expect(abortCount).toBe(baseAborts + 1);
      expect(sent.length).toBe(baseSends); // still settling
      // 2. Inbound m2 arrives mid-settle (interrupt in flight): 4x arm.
      await handleInbound(pi, inbound("second", "m2"), ctx);
      expect(midTurnQueues.get("ch1")?.length).toBe(1);
      const armed = pendingInterrupts
        .get("ch1")
        ?.find((p) => p.messageId === "m2");
      expect(armed).toBeDefined();
      expect(
        Math.abs(armed!.at - Date.now() - interruptStepTimeoutMs() * 4),
      ).toBeLessThanOrEqual(1);
      // 3. A plain 3s elapse must NOT fire m2 (no early re-arm, no abort).
      jest.advanceTimersByTime(interruptStepTimeoutMs());
      await Promise.resolve();
      expect(abortCount).toBe(baseAborts + 1);
      expect(sent.length).toBe(baseSends);
      // 4. The run settles: m1 (the in-flight interrupt) gets the next run.
      idle = true;
      jest.advanceTimersByTime(25);
      await Promise.resolve();
      expect(sent.length).toBe(baseSends + 1);
      expect(sent[baseSends].m.details.messageId).toBe("m1");
      // 5. m1's re-wake run is now active; m2's 4x timer fires on schedule.
      idle = false;
      jest.advanceTimersByTime(interruptStepTimeoutMs() * 3 - 25);
      await Promise.resolve();
      expect(abortCount).toBe(baseAborts + 2);
      idle = true;
      jest.advanceTimersByTime(25);
      await Promise.resolve();
      expect(sent.length).toBe(baseSends + 2);
      expect(sent[baseSends + 1].m.details.messageId).toBe("m2");
      expect(midTurnQueues.has("ch1")).toBe(false);
    });

    test("machine wake (Author: pi-bg) is queue-only, arms nothing (#177)", async () => {
      expect(idle).toBe(false);
      const baseAborts = abortCount;
      const baseSends = sent.length;
      // the 2026-10-21 de-prefix shape: content "" + one embed whose
      // author starts pi-bg (the bridge-built body is the serialized
      // embed)
      const wake = {
        ...inbound(
          "<embed>\nAuthor: pi-bg etl \u00b7 t1\nTitle: etl \u00b7 OK\nresult: ticket\n</embed>",
          "bm1",
        ),
        from: "bg",
      };
      await handleInbound(pi, wake, ctx);
      // Queue-only: not the 3s default, not the 4x in-flight window.
      expect(midTurnQueues.get("ch1")?.length).toBe(1);
      expect(pendingInterrupts.has("ch1")).toBe(false);
      jest.advanceTimersByTime(interruptStepTimeoutMs() * 4);
      await Promise.resolve();
      expect(abortCount).toBe(baseAborts);
      expect(sent.length).toBe(baseSends);
      // The run ends → the re-wake queue owns delivery.
      idle = true;
      await handlers.agent_end({ messages: [] }, ctx);
      expect(sent.length).toBe(baseSends + 1);
      expect(sent[baseSends].m.details.messageId).toBe("bm1");
      expect(midTurnQueues.has("ch1")).toBe(false);
    });

    test("inbound with no run in flight delivers directly, arms no interrupt", async () => {
      idle = true; // no run in flight
      const baseSends = sent.length;
      const baseAborts = abortCount;
      await handleInbound(pi, inbound("idle inbound", "pi1"), ctx);
      // Not queued, not armed — straight to pi as a fresh run.
      expect(midTurnQueues.has("ch1")).toBe(false);
      expect(pendingInterrupts.has("ch1")).toBe(false);
      expect(sent.length).toBe(baseSends + 1);
      expect(sent[baseSends].m.details.messageId).toBe("pi1");
      // Nothing pending to fire at 3s or 12s.
      jest.advanceTimersByTime(interruptStepTimeoutMs() * 5);
      await Promise.resolve();
      expect(abortCount).toBe(baseAborts);
      expect(sent.length).toBe(baseSends + 1);
    });

    test("run that ends before the timeout: re-wake delivers, timer is a no-op", async () => {
      await handleInbound(pi, inbound("later", "m1"), ctx);
      idle = true; // the run ends
      await handlers.agent_end({ messages: [] }, ctx);
      expect(sent.length).toBe(1); // re-wake fired
      expect(midTurnQueues.has("ch1")).toBe(false);
      jest.advanceTimersByTime(interruptStepTimeoutMs() + 1000);
      expect(sent.length).toBe(1); // timer found no entry, no double send
      expect(abortCount).toBe(0);
    });

    test("/stop clears armed interrupts", async () => {
      await handleInbound(pi, inbound("x", "m1"), ctx);
      expect(pendingInterrupts.get("ch1")?.length).toBe(1);
      await handleInbound(pi, inbound("/stop", "m2"), ctx);
      expect(pendingInterrupts.has("ch1")).toBe(false);
      expect(abortCount).toBe(1); // /stop's own abort
      jest.advanceTimersByTime(interruptStepTimeoutMs() + 1000);
      expect(abortCount).toBe(1); // no interrupt abort
      expect(sent.length).toBe(0);
    });

    test("interrupt does not fire when pi is idle at timer time", async () => {
      await handleInbound(pi, inbound("x", "m1"), ctx);
      idle = true; // run settled before the timer fires
      jest.advanceTimersByTime(interruptStepTimeoutMs());
      expect(abortCount).toBe(0);
      expect(sent.length).toBe(0);
      // message stays in the re-wake queue, owned by agent_end
      expect(midTurnQueues.get("ch1")?.length).toBe(1);
    });

    test("interrupt waits for a slow settle before sending", async () => {
      // abort does NOT settle immediately — the wait loop must poll isIdle
      ctx.abort = () => {
        abortCount += 1;
      };
      await handleInbound(pi, inbound("slow", "m1"), ctx);
      jest.advanceTimersByTime(interruptStepTimeoutMs());
      await Promise.resolve();
      expect(abortCount).toBe(1);
      expect(sent.length).toBe(0); // not sent while the run is still settling
      // settle after 2 polls (microtask flush after each fake-timer advance)
      jest.advanceTimersByTime(50);
      await Promise.resolve();
      idle = true;
      jest.advanceTimersByTime(25);
      await Promise.resolve();
      expect(sent.length).toBe(1);
      expect(sent[0].m.details.messageId).toBe("m1");
    });

    test("settle beyond the cap leaves the message to the re-wake queue", async () => {
      // abort never settles: the poll loop must hit its 120 s cap, restore
      // the entry (FIFO position) and let the re-wake path own it — never
      // steer into a still-active run (the lossy path).
      ctx.abort = () => {
        abortCount += 1;
      };
      await handleInbound(pi, inbound("stuck", "m1"), ctx);
      // 120 x 25 ms covers the interrupt arm; 4800 x 25 ms is the poll cap.
      for (let i = 0; i < 4925; i++) {
        jest.advanceTimersByTime(25);
        await Promise.resolve();
      }
      expect(abortCount).toBe(1);
      expect(sent.length).toBe(0);
      const q = midTurnQueues.get("ch1");
      expect(q?.length).toBe(1);
      expect(q?.[0].msg.messageId).toBe("m1");
    });

    test("re-wake yields to an in-flight interrupt; deferred entry re-wakes after the interrupt run", async () => {
      // Slow settle: the abort does NOT settle the run immediately, so the
      // interrupt stays in flight across the aborted run's agent_end — the
      // real pi ordering (pi awaits the agent_end handler before clearing
      // the run-active flag).
      ctx.abort = () => {
        abortCount += 1;
      };
      await handleInbound(pi, inbound("first queued msg", "m1"), ctx);
      // m1's interrupt fires and starts its settle wait (run still active).
      jest.advanceTimersByTime(interruptStepTimeoutMs());
      await Promise.resolve();
      expect(abortCount).toBe(1);
      expect(sent.length).toBe(0); // settle still polling
      // A second message arrives mid-settle: queued + armed.
      await handleInbound(pi, inbound("second queued msg", "m2"), ctx);
      expect(midTurnQueues.get("ch1")?.length).toBe(1);
      // The aborted run's agent_end lands while m1's interrupt is in
      // flight: the re-wake DEFERS — m2 stays queued, no run starts, no
      // send. (Before the fix this started m2's full run, which held
      // isIdle() false and ate m1's 120 s settle cap — the 2026-09-30
      // incident.)
      await handlers.agent_end({ messages: [] }, ctx);
      expect(sent.length).toBe(0);
      expect(midTurnQueues.get("ch1")?.length).toBe(1);
      expect(midTurnQueues.get("ch1")?.[0].msg.messageId).toBe("m2");
      // The run settles: the interrupt message gets the next run.
      idle = true;
      jest.advanceTimersByTime(25);
      await Promise.resolve();
      expect(sent.length).toBe(1);
      expect(sent[0].m.details.messageId).toBe("m1");
      // The interrupt run ends: the deferred entry re-wakes in order.
      await handlers.agent_end({ messages: [] }, ctx);
      expect(sent.length).toBe(2);
      expect(sent[1].m.details.messageId).toBe("m2");
      expect(midTurnQueues.has("ch1")).toBe(false);
    });

    test("/stop during the settle window drops the pending send", async () => {
      ctx.abort = () => {
        abortCount += 1;
      }; // does not settle immediately
      await handleInbound(pi, inbound("redirect me", "m1"), ctx);
      jest.advanceTimersByTime(interruptStepTimeoutMs());
      await Promise.resolve();
      expect(abortCount).toBe(1);
      expect(sent.length).toBe(0);
      // /stop while the settle wait is pending
      await handleInbound(pi, inbound("/stop", "m2"), ctx);
      jest.advanceTimersByTime(25);
      await Promise.resolve();
      expect(sent.length).toBe(0); // send dropped, entry not restored
      expect(midTurnQueues.has("ch1")).toBe(false);
    });

    test("/stop while idle does not poison later interrupts (F7 guard)", async () => {
      // /stop with no in-flight interrupt must not set the cancel flag
      idle = true;
      await handleInbound(pi, inbound("/stop", "m0"), ctx);
      // A run becomes active; a plain message is queued and armed
      idle = false;
      await handleInbound(pi, inbound("m9 message", "m9"), ctx);
      expect(pendingInterrupts.get("ch1")?.length).toBe(1);
      // Timer fires while the run is still active: the interrupt must be
      // delivered, not dropped by a stale flag (abort mock settles at once)
      jest.advanceTimersByTime(interruptStepTimeoutMs());
      await Promise.resolve();
      expect(abortCount).toBe(1);
      expect(sent.length).toBe(1);
      expect(sent[0].m.details.messageId).toBe("m9");
    });

    test("a dropped interrupt does not poison later interrupts (F7 consume)", async () => {
      ctx.abort = () => {
        abortCount += 1;
      }; // does not settle immediately
      // Relative zero-asserts (MEDIUM-1, review 3005244): a late
      // send/abort leaked from a prior test lands in this test's shared
      // `sent` binding / abortCount — only GROWTH during this test's
      // window counts.
      const baseSends = sent.length;
      const baseAborts = abortCount;
      await handleInbound(pi, inbound("first", "m1"), ctx);
      jest.advanceTimersByTime(interruptStepTimeoutMs());
      await Promise.resolve();
      expect(abortCount).toBe(baseAborts + 1);
      // /stop during the settle window: drops m1 AND consumes the flag
      await handleInbound(pi, inbound("/stop", "m2"), ctx);
      jest.advanceTimersByTime(25);
      await Promise.resolve();
      expect(sent.length).toBe(baseSends);
      // Run still active; m3 is queued and armed. While m1's cancel poll
      // still holds the in-flight flag (it waits for the settle so its
      // re-wake kick cannot race the agent_end window, #124), m3's
      // interrupt is DEFERRED like any in-flight one (re-armed, long
      // delay) — not dropped. Its delivery is guaranteed by the settle
      // the poll is waiting for.
      await handleInbound(pi, inbound("third", "m3"), ctx);
      // The run settles: m1's cancel poll exits and kicks m3 (the oldest
      // queued entry) — delivered exactly once, no second abort.
      idle = true;
      jest.advanceTimersByTime(25);
      await Promise.resolve();
      await flushUntil(() =>
        sent.some((s) => s.m?.details?.messageId === "m3"),
      );
      expect(sent.length).toBe(baseSends + 1);
      expect(sent.some((s) => s.m?.details?.messageId === "m3")).toBe(true);
      expect(abortCount).toBe(baseAborts + 2); // m1's abort + /stop's abort
      // m3's armed interrupt (4x delay while the flag was held) later
      // finds pi idle and the queue empty: no double send, no spurious
      // abort.
      jest.advanceTimersByTime(interruptStepTimeoutMs() * 5);
      await Promise.resolve();
      for (let i = 0; i < 10; i++)
        await new Promise<void>((r) => setImmediate(r));
      expect(sent.length).toBe(baseSends + 1);
      expect(abortCount).toBe(baseAborts + 2);
    });

    test("/status shows the armed interrupt state", async () => {
      ctx.isIdle = () => false;
      await handleInbound(pi, inbound("x", "m1"), ctx);
      await handleInbound(pi, inbound("/status", "m2"), ctx);
      const posts = fetchCalls.filter(
        (c) => c.method === "POST" && c.url.endsWith("/messages"),
      );
      const statusPost = posts
        .map((p) => String(JSON.parse(p.body).content))
        .find((t) => t.includes("running"));
      expect(statusPost).toBeDefined();
      expect(statusPost).toContain("interrupt in ");
    });

    // ── Interrupt tick lifecycle (ack message is the tick target) ────
    const ackFlush = async () => {
      for (let i = 0; i < 20; i++) await Promise.resolve();
    };

    test("tick: success path settles the tick before the ack delete", async () => {
      verboseOverride.set("ch1", 1); // verbose 1: the [queued] ack posts
      await handlers.session_start?.(null, ctx); // configRoot for ack REST
      await handleInbound(pi, inbound("redirect me", "m1"), ctx);
      await ackFlush(); // ack post resolves -> tick armed on the ack id
      const ackId = queuedAcks.get("m1")?.ackId;
      expect(ackId).toBeDefined();

      jest.advanceTimersByTime(interruptStepTimeoutMs());
      await ackFlush();
      expect(abortCount).toBe(1);
      expect(sent.length).toBe(1);

      // The final edit (settle) must land on the ack BEFORE the delete:
      // a PATCH after the DELETE would re-create the message with a stale
      // line that nothing cleans up. Op status is prose — unfenced (v4).
      const settleIdx = fetchCalls.findIndex(
        (c) =>
          c.method === "PATCH" &&
          c.url.includes(`/channels/ch1/messages/${ackId}`) &&
          String(JSON.parse(c.body).content) === "interrupted",
      );
      const deleteIdx = fetchCalls.findIndex(
        (c) =>
          c.method === "DELETE" &&
          c.url.endsWith(`/channels/ch1/messages/${ackId}`),
      );
      expect(settleIdx).toBeGreaterThanOrEqual(0);
      expect(deleteIdx).toBeGreaterThan(settleIdx);
    });

    test("tick: cancel path settles the tick before the ack delete", async () => {
      verboseOverride.set("ch1", 1); // verbose 1: the [queued] ack posts
      await handlers.session_start?.(null, ctx); // configRoot for ack REST
      ctx.abort = () => {
        abortCount += 1;
      }; // does not settle immediately
      await handleInbound(pi, inbound("redirect me", "m1"), ctx);
      await ackFlush();
      const ackId = queuedAcks.get("m1")?.ackId;
      expect(ackId).toBeDefined();

      jest.advanceTimersByTime(interruptStepTimeoutMs());
      await ackFlush();
      expect(abortCount).toBe(1);
      // /stop while the settle wait is pending: cancels the in-flight
      // interrupt (its ack must be cleaned up, tick settled first).
      await handleInbound(pi, inbound("/stop", "m2"), ctx);
      jest.advanceTimersByTime(25);
      await ackFlush();
      expect(sent.length).toBe(0); // send dropped

      const settleIdx = fetchCalls.findIndex(
        (c) =>
          c.method === "PATCH" &&
          c.url.includes(`/channels/ch1/messages/${ackId}`) &&
          String(JSON.parse(c.body).content) === "interrupted",
      );
      const deleteIdx = fetchCalls.findIndex(
        (c) =>
          c.method === "DELETE" &&
          c.url.endsWith(`/channels/ch1/messages/${ackId}`),
      );
      expect(settleIdx).toBeGreaterThanOrEqual(0);
      expect(deleteIdx).toBeGreaterThan(settleIdx);
      // tick is gone: no tick edit can re-create the deleted ack
      expect(settleOpTick(`interrupt:ch1`, "[probe]")).toBe(false);
    });

    test("tick: settle-cap path settles the tick back to the queued line (#84 L1)", async () => {
      verboseOverride.set("ch1", 1); // verbose 1: the [queued] ack posts
      await handlers.session_start?.(null, ctx); // configRoot for ack REST
      ctx.abort = () => {
        abortCount += 1;
      }; // never settles: the poll loop must hit its 120 s cap
      await handleInbound(pi, inbound("stuck", "m1"), ctx);
      await ackFlush();
      const ackId = queuedAcks.get("m1")?.ackId;
      expect(ackId).toBeDefined();

      // 120 x 25 ms covers the interrupt arm; 4800 x 25 ms is the poll cap.
      for (let i = 0; i < 4925; i++) {
        jest.advanceTimersByTime(25);
        await Promise.resolve();
      }
      await ackFlush();
      expect(abortCount).toBe(1);
      expect(sent.length).toBe(0);
      // entry restored to the re-wake queue (existing behavior)
      expect(midTurnQueues.get("ch1")?.[0]?.msg.messageId).toBe("m1");

      const ackPatches = fetchCalls
        .filter(
          (c) =>
            c.method === "PATCH" &&
            c.url.includes(`/channels/ch1/messages/${ackId}`),
        )
        .map((c) => String(JSON.parse(c.body).content));
      // the tick moved while the settle wait ran (one-line status = prose,
      // no fence, v4 §2.3)...
      expect(ackPatches).toContain("[..] interrupting… 5s");
      // ...but the cap path SETTLES the tick back to the queued line (the
      // message's TRUE state — an interrupt did not happen), NOT a frozen
      // mid-interrupt line (#84 L1)...
      expect(ackPatches.at(-1)).toBe("[queued] 1 in line");
      expect(ackPatches).not.toContain("interrupted");
      // ...and the ack is NOT deleted (it stays with the queued entry).
      expect(
        fetchCalls.some(
          (c) =>
            c.method === "DELETE" &&
            c.url.endsWith(`/channels/ch1/messages/${ackId}`),
        ),
      ).toBe(false);
      // tick is gone: advancing further must not edit the ack again
      expect(settleOpTick(`interrupt:ch1`, "[probe]")).toBe(false);
      const patchesBefore = ackPatches.length;
      jest.advanceTimersByTime(10000);
      await ackFlush();
      const ackPatchesAfter = fetchCalls.filter(
        (c) =>
          c.method === "PATCH" &&
          c.url.includes(`/channels/ch1/messages/${ackId}`),
      ).length;
      expect(ackPatchesAfter).toBe(patchesBefore);
    });

    // ── Queue ack + interrupt verbosity (2026-10-20) ──────────────────
    // Verbose 0: the "[queued] N in line" ack and the mid-run interrupt
    // (which only ticks that ack) are SILENT. Verbose 1+: both post.
    // The entry always queues (and re-wakes) - only the line changes.
    test("verbose 0 (default): mid-run inbound queues silently - no [queued] line, no interrupt tick, entry still delivered", async () => {
      // The default fixture channel has no forwardToolCalls: level 0.
      expect(verboseLevel(loadChannelConfig(ctx.cwd)[0]!)).toBe(0);
      await handleInbound(pi, inbound("redirect me", "m1"), ctx);
      await ackFlush();
      // Queued for the re-wake, but the ack line never posts.
      expect(midTurnQueues.get("ch1")?.length).toBe(1);
      expect(queuedAcks.has("m1")).toBe(false);
      const ackPosts = fetchCalls.filter(
        (c) =>
          c.method === "POST" &&
          c.url.endsWith("/channels/ch1/messages") &&
          String(JSON.parse(c.body).content).includes("in line"),
      );
      expect(ackPosts.length).toBe(0);

      // The interrupt fires: no ack to tick, so it is fully silent -
      // no tick edit, no settle post - and the entry still goes through
      // as a fresh run.
      jest.advanceTimersByTime(interruptStepTimeoutMs());
      await ackFlush();
      expect(abortCount).toBe(1);
      expect(sent.length).toBe(1);
      expect(
        fetchCalls.some(
          (c) =>
            c.method === "PATCH" && c.url.includes("/channels/ch1/messages/"),
        ),
      ).toBe(false);
      expect(
        fetchCalls.some(
          (c) =>
            c.method === "POST" &&
            c.url.endsWith("/channels/ch1/messages") &&
            String(JSON.parse(c.body).content).includes("interrupt"),
        ),
      ).toBe(false);
    });

    test("verbose 1: mid-run inbound posts the [queued] line and the interrupt settles it", async () => {
      verboseOverride.set("ch1", 1);
      await handlers.session_start?.(null, ctx); // configRoot for ack REST
      await handleInbound(pi, inbound("redirect me", "m1"), ctx);
      await ackFlush();
      const ackId = queuedAcks.get("m1")?.ackId;
      expect(ackId).toBeDefined();
      expect(
        fetchCalls.some(
          (c) =>
            c.method === "POST" &&
            c.url.endsWith("/channels/ch1/messages") &&
            String(JSON.parse(c.body).content) === "[queued] 1 in line",
        ),
      ).toBe(true);

      // The interrupt settles the ack in place (the one visible edit).
      jest.advanceTimersByTime(interruptStepTimeoutMs());
      await ackFlush();
      expect(abortCount).toBe(1);
      expect(sent.length).toBe(1);
      const ackPatches = fetchCalls
        .filter(
          (c) =>
            c.method === "PATCH" &&
            c.url.includes(`/channels/ch1/messages/${ackId}`),
        )
        .map((c) => String(JSON.parse(c.body).content));
      expect(ackPatches).toContain("interrupted");
    });
  });

  describe("mid-run interrupt (#177 machine-wake queue-only)", () => {
    // #177: machine-wake webhook inbounds (pi-bg callbacks - the
    // `Author: pi-bg` embed author, or legacy `[bg:` content -
    // dead-letter re-posts, not-yet-restyled cross-repo producers) ride
    // the re-wake queue and deliver at agent_end; they arm NO mid-run
    // interrupt — the queue already guarantees delivery, the interrupt
    // only jumps the line, and a machine alert is never more urgent than
    // the in-flight turn. Human 3s arming and peer-bot 12s arming
    // (#165/#175) are untouched; a later human cut-in still arms even
    // with a machine-wake entry queued ahead of it.
    let abortCount: number;
    let idle: boolean;

    beforeEach(() => {
      jest.useFakeTimers();
      abortCount = 0;
      idle = false;
      // Model the real session: abort kills the run and it settles (idle).
      ctx.isIdle = () => idle;
      ctx.abort = () => {
        abortCount += 1;
        idle = true;
      };
      setInterruptCtx(ctx);
    });

    afterEach(() => {
      clearDiscordStatesForTest(); // no auto-react suppression leaks across tests
      resetRuntimeStateForTest(); // sessionStartTs/held/verbose: no leaks
      setInterruptCtx(null);
      clearAllInterrupts();
      pendingInterrupts.clear();
      queuedAcks.clear();
      jest.useRealTimers();
    });

    test("isBgInbound classifies the machine-wake shapes (legacy [bg: prefix + Author: pi-bg embed marker)", () => {
      expect(isBgInbound(inbound("[bg:worker:OK] x", "1"))).toBe(true);
      expect(isBgInbound(inbound("  [bg:etl] y", "2"))).toBe(true);
      expect(isBgInbound(inbound("[bg] no colon", "3"))).toBe(false);
      expect(isBgInbound(inbound("plain", "4"))).toBe(false);
      expect(isBgInbound(inbound("see [bg: ticket", "5"))).toBe(false);
      // the 2026-10-21 de-prefix shape: content "" + embed author pi-bg
      // (serializeEmbeds renders it as "Author: pi-bg …")
      expect(
        isBgInbound(
          inbound("<embed>\nAuthor: pi-bg ticket \u00b7 r1\n</embed>", "6"),
        ),
      ).toBe(true);
    });

    test("[bg:pat] tap wake mid-run: queued, no arm, delivered at agent_end (#220)", async () => {
      // The wake is posted via the dispatch webhook — to the gateway it
      // is a bot-authored message (Beepy-style), like the [bg: callback.
      // Legacy `[bg:` content shape (producer outside this repo - restyle
      // lands with the migration arm's one-release window).
      const body =
        "[bg:pat] approved pat_a (monky, triage) — claim within 60s: jarate pat-run pat_a -- <cmd>";
      const msg = {
        ...inbound(body, "wke1"),
        from: "Beepy",
        fromId: "1546769099252695103",
      };
      const baseSends = sent.length;
      const baseAborts = abortCount;
      const baseTimers = pendingInterrupts.size;
      await handleInbound(pi, msg, ctx);
      // Queued for the guaranteed re-wake...
      expect(midTurnQueues.get("ch1")?.length).toBe(1);
      // ...but nothing armed: the timer count is unchanged.
      expect(pendingInterrupts.size).toBe(baseTimers);
      expect(pendingInterrupts.has("ch1")).toBe(false);
      jest.advanceTimersByTime(interruptStepTimeoutMs() * 2);
      await Promise.resolve();
      expect(abortCount).toBe(baseAborts);
      expect(sent.length).toBe(baseSends);
      // The run ends → the re-wake queue owns delivery.
      idle = true;
      await handlers.agent_end({ messages: [] }, ctx);
      expect(sent.length).toBe(baseSends + 1);
      expect(sent[baseSends].m.details.body).toBe(body);
      expect(sent[baseSends].m.details.messageId).toBe("wke1");
      expect(midTurnQueues.has("ch1")).toBe(false);
    });

    test("legacy [bg: content inbound mid-run: no interrupt armed (migration arm, one release), delivered at agent_end via re-wake", async () => {
      const baseSends = sent.length;
      const baseAborts = abortCount;
      const baseTimers = pendingInterrupts.size;
      await handleInbound(
        pi,
        inbound("[bg:worker:OK] task 42 done", "bm1"),
        ctx,
      );
      // Queued for the guaranteed re-wake...
      expect(midTurnQueues.get("ch1")?.length).toBe(1);
      // ...but nothing armed: the timer count is unchanged.
      expect(pendingInterrupts.size).toBe(baseTimers);
      expect(pendingInterrupts.has("ch1")).toBe(false);
      // The 3s point (and beyond) passes with no abort, no early delivery.
      jest.advanceTimersByTime(interruptStepTimeoutMs() * 2);
      await Promise.resolve();
      expect(abortCount).toBe(baseAborts);
      expect(sent.length).toBe(baseSends);
      // The run ends → the re-wake queue owns delivery.
      idle = true;
      await handlers.agent_end({ messages: [] }, ctx);
      expect(sent.length).toBe(baseSends + 1);
      expect(sent[baseSends].m.details.body).toBe(
        "[bg:worker:OK] task 42 done",
      );
      expect(sent[baseSends].m.details.messageId).toBe("bm1");
      expect(midTurnQueues.has("ch1")).toBe(false);
    });

    test("embed-only pi-bg callback (content='', Author: pi-bg) mid-run: queued, no arm, delivered at agent_end — EXACT lost-callback shape (2026-10-06, ticket 3580612)", async () => {
      // The standard pi-bg completion callback is embed-only by
      // construction (content='', embed author "pi-bg ticket · <rid>") -
      // and since 2026-10-21 the de-prefix shape of EVERY jarate
      // producer. Legacy "[bg:" content (in-flight posts, dead letters,
      // not-yet-restyled cross-repo producers) is the other arm.
      // The bridge-built body is the serialized embed — no "[bg:" prefix
      // anywhere. The 2026-10-06 incident lost EXACTLY this shape
      // (msg 1556883632919150653, Beepy webhook author, mid-run):
      // pre-fix isBgInbound missed it and the 3s interrupt armed + was
      // lost at compact.
      const body = [
        "<embed>",
        "Author: pi-bg ticket · 20261006-040516-3580612",
        "Title: reviewer · PASS · 14m27s",
        "```bash",
        "┌ jarate-bg 20261006-040516-3580612",
        "└",
        "```",
        "task: adversarially review marzukia/jarate PR #179",
        "result: VERDICT: PASS (pack: /var/tmp/reviews/pr-179-result.md)",
        "Footer: pi-bg",
        "</embed>",
      ].join("\n");
      const baseSends = sent.length;
      const baseAborts = abortCount;
      const baseTimers = pendingInterrupts.size;
      // Beepy-style author: a webhook bot.
      const msg = {
        ...inbound(body, "1556883632919150653"),
        from: "Beepy",
        fromId: "1546769099252695103",
      };
      await handleInbound(pi, msg, ctx);
      // Queued for the guaranteed re-wake (depth +1)...
      expect(midTurnQueues.get("ch1")?.length).toBe(1);
      // ...but NO timer armed (arm count unchanged, nothing pending for
      // ch1) — the embed-only shape is a machine wake like the [bg:
      // prefix shape.
      expect(pendingInterrupts.size).toBe(baseTimers);
      expect(pendingInterrupts.has("ch1")).toBe(false);
      // The 3s point (and beyond) passes with no abort, no early
      // delivery: the in-flight run survives intact.
      jest.advanceTimersByTime(interruptStepTimeoutMs() * 2);
      await Promise.resolve();
      expect(abortCount).toBe(baseAborts);
      expect(sent.length).toBe(baseSends);
      // The run ends → the re-wake queue owns delivery.
      idle = true;
      await handlers.agent_end({ messages: [] }, ctx);
      expect(sent.length).toBe(baseSends + 1);
      expect(sent[baseSends].m.details.body).toBe(body);
      expect(sent[baseSends].m.details.messageId).toBe("1556883632919150653");
      expect(midTurnQueues.has("ch1")).toBe(false);
    });

    test("legacy [bg: content inbound idle: immediate delivery, nothing queued or armed (regression pin)", async () => {
      const baseSends = sent.length;
      const baseAborts = abortCount;
      idle = true; // no run in flight
      await handleInbound(
        pi,
        inbound("[bg:worker:OK] task 43 done", "bm2"),
        ctx,
      );
      // Straight to pi as a fresh run: the delivery path is unchanged.
      expect(midTurnQueues.has("ch1")).toBe(false);
      expect(pendingInterrupts.has("ch1")).toBe(false);
      expect(sent.length).toBe(baseSends + 1);
      expect(sent[baseSends].m.details.messageId).toBe("bm2");
      // Nothing pending to fire later.
      jest.advanceTimersByTime(interruptStepTimeoutMs() * 2);
      await Promise.resolve();
      expect(sent.length).toBe(baseSends + 1);
      expect(abortCount).toBe(baseAborts);
    });

    test("human inbound mid-run: 3s arm (regression pin)", async () => {
      const baseSends = sent.length;
      const baseAborts = abortCount;
      await handleInbound(pi, inbound("human mid-run", "hm1"), ctx);
      expect(midTurnQueues.get("ch1")?.length).toBe(1);
      const armed = pendingInterrupts.get("ch1")?.[0];
      expect(armed).toBeDefined();
      expect(armed!.messageId).toBe("hm1");
      expect(
        Math.abs(armed!.at - Date.now() - interruptStepTimeoutMs()),
      ).toBeLessThanOrEqual(1);
      // Fires at the 3s point: the quick cut-in is intact.
      jest.advanceTimersByTime(interruptStepTimeoutMs());
      await Promise.resolve();
      expect(abortCount).toBe(baseAborts + 1);
      expect(sent.length).toBe(baseSends + 1);
      expect(sent[baseSends].m.details.messageId).toBe("hm1");
    });

    test("human arriving mid-run after a machine wake (Author: pi-bg) was queued: still arms (the queue does not suppress later human cuts)", async () => {
      const baseSends = sent.length;
      const baseAborts = abortCount;
      // 1. Machine wake (the 2026-10-21 de-prefix shape) lands mid-run:
      // queued, no arm.
      const wakeBody =
        "<embed>\nAuthor: pi-bg worker \u00b7 r44\nTitle: worker \u00b7 OK\nresult: task 44 done\n</embed>";
      await handleInbound(pi, inbound(wakeBody, "bm1"), ctx);
      expect(midTurnQueues.get("ch1")?.length).toBe(1);
      expect(pendingInterrupts.has("ch1")).toBe(false);
      // 2. Human arrives while the wake is queued: the cut-in still arms.
      await handleInbound(pi, inbound("human cut", "hm1"), ctx);
      expect(midTurnQueues.get("ch1")?.length).toBe(2);
      const armed = pendingInterrupts
        .get("ch1")
        ?.find((p) => p.messageId === "hm1");
      expect(armed).toBeDefined();
      expect(
        Math.abs(armed!.at - Date.now() - interruptStepTimeoutMs()),
      ).toBeLessThanOrEqual(1);
      // 3. The 3s point fires: the HUMAN's message is force-delivered...
      jest.advanceTimersByTime(interruptStepTimeoutMs());
      await Promise.resolve();
      expect(abortCount).toBe(baseAborts + 1);
      expect(sent.length).toBe(baseSends + 1);
      expect(sent[baseSends].m.details.messageId).toBe("hm1");
      // ...and the machine-wake entry stays queued for its agent_end
      // re-wake.
      expect(midTurnQueues.get("ch1")?.length).toBe(1);
      expect(midTurnQueues.get("ch1")?.[0]?.msg.messageId).toBe("bm1");
    });
  });

  describe("mid-run interrupt (two channels)", () => {
    let abortCount: number;
    let idle: boolean;

    // Two-channel variant of the `inbound` helper: channelId selects the
    // fixture channel (ch1 = interrupted, ch2 = the entry at risk).
    const inboundCh = (
      body: string,
      id: string,
      channelId = "ch1",
    ): ChannelMessage => ({
      channelId,
      channelName: channelId === "ch1" ? "Test" : "Test2",
      channelType: "discord",
      messageId: id,
      from: "u",
      fromId: "uid",
      body,
      timestamp: new Date().toISOString(),
      attachments: [],
      isRoom: false,
    });

    beforeEach(() => {
      jest.useFakeTimers();
      abortCount = 0;
      idle = false;
      // Two-channel settings fixture (ch1 + ch2, both owned by "uid").
      fs.writeFileSync(
        path.join(tmp, ".pi", "settings.json"),
        JSON.stringify({
          channels: [
            {
              id: "ch1",
              name: "Test",
              type: "discord",
              botToken: "tok1",
              ownerUserId: "uid",
              ack: true,
            },
            {
              id: "ch2",
              name: "Test2",
              type: "discord",
              botToken: "tok2",
              ownerUserId: "uid",
              ack: true,
            },
          ],
        }),
      );
      // Re-run the extension so handler closures (the re-wake
      // handleInbound, pi.sendMessage) target this fixture.
      handlers = {};
      pi = {
        registerMessageRenderer: () => {},
        registerTool: () => {},
        on: (n: string, fn: any) => {
          handlers[n] = fn;
        },
        sendMessage: (m: any, o?: any) => {
          sent.push({ m, o });
        },
      };
      extension(pi);
      // Slow settle: the abort does NOT settle the run immediately, so
      // the interrupt stays in flight across the aborted run's agent_end
      // (the real pi ordering: pi awaits the agent_end handler before
      // clearing the run-active flag).
      ctx.isIdle = () => idle;
      ctx.abort = () => {
        abortCount += 1;
      };
      setInterruptCtx(ctx);
    });

    afterEach(() => {
      clearDiscordStatesForTest(); // no auto-react suppression leaks across tests
      setInterruptCtx(null);
      clearAllInterrupts();
      pendingInterrupts.clear();
      queuedAcks.clear();
      jest.useRealTimers();
    });

    test("/stop in the deferral window re-wakes the cross-channel queued entry (cancel-branch kick)", async () => {
      await handlers.session_start?.(null, ctx); // configRoot for ack REST
      expect(idle).toBe(false);
      // Relative zero-asserts (MEDIUM-1, review 3005244): a late send
      // from a prior test can land in this test's shared `sent` binding
      // — only GROWTH during this test's window counts.
      const baseSends = sent.length;
      const baseAborts = abortCount;
      // 1. m1 (ch1) arrives mid-run: queued, interrupt armed.
      await handleInbound(pi, inboundCh("m1 body", "m1"), ctx);
      // 2. m1's interrupt fires: abort in flight, settle polling — the
      //    run is still active, so no send yet.
      jest.advanceTimersByTime(interruptStepTimeoutMs());
      await Promise.resolve();
      expect(abortCount).toBe(baseAborts + 1);
      expect(sent.length).toBe(baseSends);
      // 3. m2 (ch2) arrives mid-settle: queued in a DIFFERENT channel —
      //    the entry the deferred agent_end should re-wake.
      await handleInbound(pi, inboundCh("m2 body", "m2", "ch2"), ctx);
      expect(midTurnQueues.get("ch2")?.length).toBe(1);
      // 4. The aborted run's agent_end lands while m1's interrupt is in
      //    flight: the re-wake DEFERS — m2 stays queued, no run starts,
      //    no send.
      await handlers.agent_end({ messages: [] }, ctx);
      expect(sent.length).toBe(baseSends);
      expect(midTurnQueues.get("ch2")?.length).toBe(1);
      // 5. The run settles and /stop on ch1 wins the race: the interrupt
      //    send is dropped at the next settle tick. /stop clears only
      //    ch1's queue — m2 (ch2) is NOT cleared, and with the interrupt
      //    dropped there is no run left to re-wake it.
      idle = true;
      await handleInbound(pi, inboundCh("/stop", "m3"), ctx);
      jest.advanceTimersByTime(25);
      await Promise.resolve();
      // m1's send never happened. Assert on m1's id, not total growth:
      // the cancel-branch kick's m2 send can land inside this window
      // (no I/O hop before send on the plain path).
      expect(sent.some((s) => s.m?.details?.messageId === "m1")).toBe(false);
      expect(midTurnQueues.has("ch1")).toBe(false);
      // The cancel branch's re-wake kick runs handleInbound for m2
      // fire-and-forget: wait for it on the bounded clock-time budget
      // (flushUntil), not a fixed hop count.
      await flushUntil(() =>
        sent.some((s) => s.m?.details?.messageId === "m2"),
      );
      // 6. m2 was re-woken by the cancel branch: no orphaned entry with a
      //    stale [queued] ack (fails without the kick).
      expect(sent.some((s) => s.m?.details?.messageId === "m2")).toBe(true);
      expect(midTurnQueues.has("ch2")).toBe(false);
      expect(sent.length).toBe(baseSends + 1);
      // m2's own armed interrupt now finds pi idle and the queue empty:
      // no double send, no spurious abort.
      jest.advanceTimersByTime(interruptStepTimeoutMs());
      await Promise.resolve();
      expect(sent.length).toBe(baseSends + 1);
      expect(abortCount).toBe(baseAborts + 1);
    });

    test("/stop INSIDE the agent_end handler window re-wakes the cross-channel entry exactly once (#124)", async () => {
      await handlers.session_start?.(null, ctx); // configRoot for ack REST
      expect(idle).toBe(false);
      // Relative zero-asserts (MEDIUM-1, review 3005244): a late send
      // from a prior test can land in this test's shared `sent` binding
      // — only GROWTH during this test's window counts.
      const baseSends = sent.length;
      const baseAborts = abortCount;
      // 1. m1 (ch1) arrives mid-run: queued, interrupt armed.
      await handleInbound(pi, inboundCh("m1 body", "m1"), ctx);
      // 2. m1's interrupt fires: abort in flight, settle polling — the
      //    run is still active, so no send yet.
      jest.advanceTimersByTime(interruptStepTimeoutMs());
      await Promise.resolve();
      expect(abortCount).toBe(baseAborts + 1);
      expect(sent.length).toBe(baseSends);
      // 3. m2 (ch2) arrives mid-settle: queued in a DIFFERENT channel —
      //    the entry the deferred agent_end should re-wake.
      await handleInbound(pi, inboundCh("m2 body", "m2", "ch2"), ctx);
      expect(midTurnQueues.get("ch2")?.length).toBe(1);
      // 4. The aborted run's agent_end starts carrying a real final: the
      //    re-wake DEFERS (interrupt in flight), then the handler suspends
      //    on the final's Discord POST. That models the real pi ordering:
      //    the deferral decision is made, but pi clears the run flag only
      //    in _emitAgentSettled — AFTER the awaited handler resolves. The
      //    orphan window is exactly this suspension.
      let resolveFinal: (() => void) | undefined;
      const finalGate = new Promise<void>((r) => (resolveFinal = r));
      const prevFetch = globalThis.fetch;
      globalThis.fetch = (async (url: any, init?: any) => {
        const body = init?.body ? JSON.parse(String(init.body)) : null;
        const isFinalPost =
          init?.method === "POST" &&
          typeof body?.content === "string" &&
          body.content.includes("final answer");
        if (isFinalPost) await finalGate;
        return prevFetch(url, init);
      }) as any;
      const logs: string[] = [];
      const realLog = console.log;
      console.log = (...args: unknown[]) => {
        logs.push(args.map(String).join(" "));
      };
      try {
        const ae = handlers.agent_end(
          {
            messages: [
              {
                role: "assistant",
                content: [{ type: "text", text: "final answer" }],
              },
            ],
          },
          ctx,
        );
        // Flush until the deferral decision has run (observable: the
        // deferral log). The handler then sits on the gated final POST —
        // in flight, flag still held, isIdle still false.
        for (
          let i = 0;
          i < 100 && !logs.some((l) => l.includes("re-wake deferred"));
          i++
        ) {
          await new Promise<void>((r) => setImmediate(r));
        }
        expect(logs.some((l) => l.includes("re-wake deferred"))).toBe(true);
        await new Promise<void>((r) => setImmediate(r));
        expect(idle).toBe(false); // pi has not cleared the run flag yet
        expect(midTurnQueues.get("ch2")?.length).toBe(1); // deferral held
        // 5. /stop on ch1 lands INSIDE the handler window: the settle tick
        //    sees the cancel with isIdle still FALSE (the old one-shot
        //    check skips the kick here and orphans m2 — #124). /stop also
        //    re-aborts: from its view the run is still active.
        await handleInbound(pi, inboundCh("/stop", "m3"), ctx);
        expect(abortCount).toBe(baseAborts + 2);
        jest.advanceTimersByTime(25);
        await Promise.resolve();
        expect(sent.length).toBe(baseSends); // m1's send never happened
        expect(midTurnQueues.has("ch1")).toBe(false);
        expect(midTurnQueues.get("ch2")?.length).toBe(1); // still queued
        // 6. The handler finishes; pi clears the run flag.
        resolveFinal!();
        await ae;
        idle = true;
        // 7. The cancel-branch kick must fire on the next settle tick —
        //    exactly once for m2 (the atomic pop is the dedupe). The
        //    kick is fire-and-forget: wait for m2 on the bounded
        //    clock-time budget (flushUntil), not a fixed hop count
        //    (MEDIUM-1, review 3005244).
        await flushUntil(() =>
          sent.some((s) => s.m?.details?.messageId === "m2"),
        );
        const m2Sends = sent.filter((s) => s.m?.details?.messageId === "m2");
        expect(m2Sends.length).toBe(1);
        expect(midTurnQueues.has("ch2")).toBe(false);
        expect(sent.length).toBe(baseSends + 1); // m2 is the only send
        // 8. No double-wake: m2's own armed interrupt fires into an idle
        //    session with an empty queue — no second send, no abort.
        jest.advanceTimersByTime(interruptStepTimeoutMs());
        await Promise.resolve();
        for (let i = 0; i < 10; i++)
          await new Promise<void>((r) => setImmediate(r));
        expect(sent.length).toBe(baseSends + 1);
        expect(abortCount).toBe(baseAborts + 2);
      } finally {
        console.log = realLog;
        globalThis.fetch = prevFetch;
      }
    });

    test("/stop in the settle window with nothing queued: no wake (cancel-branch kick finds an empty queue)", async () => {
      await handlers.session_start?.(null, ctx); // configRoot for ack REST
      expect(idle).toBe(false);
      // Relative zero-asserts (MEDIUM-1, review 3005244): a late send
      // from the prior test's fire-and-forget kick can land in this
      // test's shared `sent` binding after its `sent = []` reset (the
      // leak is documented in the outer afterEach comment) and fail an
      // absolute 0. Only GROWTH during this test's own window counts.
      const baseSends = sent.length;
      const baseAborts = abortCount;
      // m1 (ch1) arrives mid-run: queued, interrupt armed. No other
      // channel's entry exists — the only line is m1's.
      await handleInbound(pi, inboundCh("m1 body", "m1"), ctx);
      jest.advanceTimersByTime(interruptStepTimeoutMs());
      await Promise.resolve();
      expect(abortCount).toBe(baseAborts + 1); // m1's interrupt aborted
      expect(sent.length).toBe(baseSends); // settling: no send yet
      // /stop while the settle wait is pending; the run settles on the
      // next tick. The cancel branch's kick must find an empty queue.
      await handleInbound(pi, inboundCh("/stop", "m3"), ctx);
      idle = true;
      jest.advanceTimersByTime(25);
      await Promise.resolve();
      expect(sent.length).toBe(baseSends); // m1 dropped, nothing else: no wake
      expect(midTurnQueues.has("ch1")).toBe(false);
      // More settle ticks: still nothing to wake, no stray send.
      jest.advanceTimersByTime(interruptStepTimeoutMs());
      for (let i = 0; i < 10; i++)
        await new Promise<void>((r) => setImmediate(r));
      expect(sent.length).toBe(baseSends);
    });

    test("/stop twice during the cancel poll does not drop the next same-channel interrupt (#167 LOW-2)", async () => {
      await handlers.session_start?.(null, ctx); // configRoot for ack REST
      expect(idle).toBe(false);
      // Relative zero-asserts (MEDIUM-1, review 3005244): a late send
      // from a prior test can land in this test's shared `sent` binding
      // after its reset and fail an absolute 0. Only GROWTH during this
      // test's own window counts.
      const baseSends = sent.length;
      const baseAborts = abortCount;
      const ackFlush = async () => {
        for (let i = 0; i < 20; i++) await Promise.resolve();
      };
      // 1. Run active. m1 arrives mid-run: queued, interrupt armed.
      await handleInbound(pi, inboundCh("m1 body", "m1"), ctx);
      await ackFlush(); // ack post resolves -> tick can arm on the ack id
      // 2. m1's interrupt fires: abort, settle polling (the slow-settle
      //    mock keeps the run active).
      jest.advanceTimersByTime(interruptStepTimeoutMs());
      await Promise.resolve();
      expect(abortCount).toBe(baseAborts + 1);
      expect(sent.length).toBe(baseSends); // settling: no send yet
      // 3. /stop#1 while the settle wait is pending: the cancel branch
      //    drops m1, CONSUMES the flag, then polls for settle (not idle).
      await handleInbound(pi, inboundCh("/stop", "m2"), ctx);
      jest.advanceTimersByTime(25);
      await Promise.resolve();
      expect(sent.length).toBe(baseSends); // m1's send dropped
      expect(abortCount).toBe(baseAborts + 2); // /stop#1's own abort
      expect(midTurnQueues.has("ch1")).toBe(false);
      // 4. /stop#2 lands DURING the cancel poll (the in-flight flag is
      //    still held, so /stop re-sets interruptCancelled). This re-set
      //    has no consumer: the cancel branch already consumed /stop#1's.
      await handleInbound(pi, inboundCh("/stop", "m3"), ctx);
      expect(abortCount).toBe(baseAborts + 3); // /stop#2's own abort
      // 5. The aborted run never settles: the cancel poll hits its
      //    120 s cap (4800 x 25 ms), skips the kick, and releases the
      //    channel. The run is STILL active (cap corner, INFO-3), so a
      //    later interrupt fires against a run that predates /stop#2 with
      //    no sendToPi in between to clear the stale flag.
      for (let i = 0; i < 4800; i++) {
        jest.advanceTimersByTime(25);
        await Promise.resolve();
      }
      expect(idle).toBe(false); // the run outlived the poll cap
      // 6. m4 arrives mid-run: queued, interrupt armed (normal delay: no
      //    interrupt in flight anymore).
      await handleInbound(pi, inboundCh("m4 body", "m4"), ctx);
      await ackFlush();
      // 7. m4's interrupt fires while the run is still active. Without
      //    the fix the stale /stop#2 flag makes the settle loop exit
      //    immediately and m4 is dropped once (message + ack). With the
      //    fix the flag was swept when the first interrupt released the
      //    channel, so m4 waits for the settle and is delivered.
      jest.advanceTimersByTime(interruptStepTimeoutMs());
      await Promise.resolve();
      expect(abortCount).toBe(baseAborts + 4); // m4's interrupt aborted
      expect(sent.length).toBe(baseSends); // still settling
      // 8. The run settles: m4's interrupt must deliver, not drop.
      idle = true;
      jest.advanceTimersByTime(25);
      await Promise.resolve();
      await flushUntil(() =>
        sent.some((s) => s.m?.details?.messageId === "m4"),
      );
      const m4Sends = sent.filter((s) => s.m?.details?.messageId === "m4");
      expect(m4Sends.length).toBe(1);
      expect(sent.length).toBe(baseSends + 1); // m4 is the only send
      expect(midTurnQueues.has("ch1")).toBe(false);
      // 9. No double-wake: more settle ticks find nothing queued.
      jest.advanceTimersByTime(interruptStepTimeoutMs());
      await Promise.resolve();
      for (let i = 0; i < 10; i++)
        await new Promise<void>((r) => setImmediate(r));
      expect(sent.length).toBe(baseSends + 1);
      expect(abortCount).toBe(baseAborts + 4);
    });
  });

  describe("queue control (. queue suffix, edit, delete)", () => {
    let abortCount: number;
    let idle: boolean;
    const flush = async () => {
      for (let i = 0; i < 20; i++) await Promise.resolve();
    };

    beforeEach(() => {
      abortCount = 0;
      idle = false;
      ctx.isIdle = () => idle;
      ctx.abort = () => {
        abortCount += 1;
        idle = true;
      };
      setInterruptCtx(ctx);
    });

    afterEach(() => {
      clearDiscordStatesForTest(); // no auto-react suppression leaks across tests
      setInterruptCtx(null);
      clearAllInterrupts();
      pendingInterrupts.clear();
      queuedAcks.clear();
      jest.useRealTimers();
    });

    test("queued ack shows the position in line (and suppresses the 👀)", async () => {
      verboseOverride.set("ch1", 1); // verbose 1: the [queued] ack posts
      ctx.isIdle = () => false;
      await handleInbound(pi, inbound("first", "m1"), ctx);
      await flush();
      expect(midTurnQueues.get("ch1")?.length).toBe(1);
      const ack1 = fetchCalls.find(
        (c) =>
          c.method === "POST" &&
          String(JSON.parse(c.body).content).includes("[queued] 1 in line"),
      );
      expect(ack1).toBeDefined();
      expect(JSON.parse(ack1!.body).message_reference?.message_id).toBe("m1");

      await handleInbound(pi, inbound("second", "m2"), ctx);
      await flush();
      expect(midTurnQueues.get("ch1")?.length).toBe(2);
      const ack2 = fetchCalls.find(
        (c) =>
          c.method === "POST" &&
          String(JSON.parse(c.body).content).includes("[queued] 2 in line"),
      );
      expect(ack2).toBeDefined();

      // The [queued] line IS the ack: no 👀 reaction on the queued message.
      const react = fetchCalls.find(
        (c) => c.method === "PUT" && c.url.includes("/messages/m1/reactions/"),
      );
      expect(react).toBeUndefined();
    });

    test("#231 P2: machine wake (Author: pi-bg) mid-run queues silently (no [queued] post)", async () => {
      ctx.isIdle = () => false; // a run is in flight
      await handleInbound(
        pi,
        inbound(
          "<embed>\nAuthor: pi-bg worker \u00b7 20261017-000000-1\nTitle: worker \u00b7 OK\nresult: test task\n</embed>",
          "m1",
        ),
        ctx,
      );
      await flush();
      // queued for the re-wake exactly as a human message is…
      expect(midTurnQueues.get("ch1")?.length).toBe(1);
      // …but no "[queued] N in line" post (no human waits in line).
      expect(
        fetchCalls.find(
          (c) =>
            c.method === "POST" &&
            String(JSON.parse(c.body).content).includes("[queued]"),
        ),
      ).toBeUndefined();
      // the entry still re-wakes at agent_end (queue semantics unchanged)
      idle = true;
      await handlers.agent_end({ messages: [] }, ctx);
      expect(sent.length).toBe(1);
      expect(sent[0].m.details.messageId).toBe("m1");
      expect(midTurnQueues.has("ch1")).toBe(false);
    });

    test("#231 P2: human inbound mid-run still posts the [queued] line", async () => {
      verboseOverride.set("ch1", 1); // verbose 1: the [queued] ack posts
      ctx.isIdle = () => false;
      await handleInbound(pi, inbound("hello", "m1"), ctx);
      await flush();
      expect(midTurnQueues.get("ch1")?.length).toBe(1);
      const ack = fetchCalls.find(
        (c) =>
          c.method === "POST" &&
          String(JSON.parse(c.body).content).includes("[queued] 1 in line"),
      );
      expect(ack).toBeDefined();
    });

    test("'. queue' parks in the re-wake queue and does NOT arm the interrupt", async () => {
      verboseOverride.set("ch1", 1); // verbose 1: the [queued] ack posts
      jest.useFakeTimers();
      idle = false;
      await handleInbound(pi, inbound("later. queue", "m1"), ctx);
      await flush();
      expect(midTurnQueues.get("ch1")?.length).toBe(1);
      expect(pendingInterrupts.has("ch1")).toBe(false);
      // The ack still shows the position.
      const ack = fetchCalls.find(
        (c) =>
          c.method === "POST" &&
          String(JSON.parse(c.body).content).includes("[queued] 1 in line"),
      );
      expect(ack).toBeDefined();
      jest.advanceTimersByTime(interruptStepTimeoutMs() + 1000);
      expect(abortCount).toBe(0);
      expect(sent.length).toBe(0);
      jest.useRealTimers();

      // The run ends → re-wake delivers the SUFFIX-STRIPPED text.
      idle = true;
      await handlers.agent_end({ messages: [] }, ctx);
      expect(sent.length).toBe(1);
      expect(sent[0].m.details.body).toBe("later");
      expect(sent[0].m.content).not.toContain(". queue");
      expect(midTurnQueues.has("ch1")).toBe(false);
    });

    test("plain message still arms the interrupt (unchanged behavior)", async () => {
      jest.useFakeTimers();
      idle = false;
      await handleInbound(pi, inbound("plain", "m1"), ctx);
      await flush();
      expect(midTurnQueues.get("ch1")?.length).toBe(1);
      expect(pendingInterrupts.get("ch1")?.length).toBe(1);
      jest.advanceTimersByTime(interruptStepTimeoutMs());
      expect(abortCount).toBe(1);
      expect(sent.length).toBe(1);
      expect(sent[0].m.details.body).toBe("plain");
      // Consumed entry's ack is dropped with it.
      expect(queuedAcks.has("m1")).toBe(false);
      jest.useRealTimers();
    });

    test("mid-sentence 'queue' is NOT treated as the suffix", async () => {
      verboseOverride.set("ch1", 1); // verbose 1: the [queued] ack posts
      ctx.isIdle = () => false;
      await handleInbound(pi, inbound("put it in the queue", "m1"), ctx);
      await flush();
      expect(midTurnQueues.get("ch1")?.length).toBe(1);
      // No suffix → interrupt armed...
      expect(pendingInterrupts.get("ch1")?.length).toBe(1);
      // ...and the queued ack still shows the position.
      const ack = fetchCalls.find(
        (c) =>
          c.method === "POST" &&
          String(JSON.parse(c.body).content).includes("[queued] 1 in line"),
      );
      expect(ack).toBeDefined();
    });

    test("edit re-renders the queued entry (interrupt delivers the new text)", async () => {
      jest.useFakeTimers();
      idle = false;
      await handleInbound(pi, inbound("original text", "m1"), ctx);
      await flush();
      expect(
        await updateQueuedInbound(ctx, "ch1", "m1", "edited text", [], "uid"),
      ).toBe(true);
      const entry = midTurnQueues.get("ch1")?.[0];
      expect(entry?.msg.body).toBe("edited text");
      expect(entry?.text).toContain("edited text");

      jest.advanceTimersByTime(interruptStepTimeoutMs());
      expect(abortCount).toBe(1);
      expect(sent.length).toBe(1);
      expect(sent[0].m.content).toContain("edited text");
      expect(sent[0].m.content).not.toContain("original text");
      expect(sent[0].m.details.messageId).toBe("m1");
      jest.useRealTimers();
    });

    test("edit of a non-queued message is a no-op", async () => {
      expect(
        await updateQueuedInbound(ctx, "ch1", "nope", "x", [], "uid"),
      ).toBe(false);
    });

    test("edit is owner-only", async () => {
      fs.writeFileSync(
        path.join(tmp, ".pi", "settings.json"),
        JSON.stringify({
          channels: [
            {
              id: "ch1",
              name: "Test",
              type: "discord",
              botToken: "tok1",
              ownerUserId: "owner1",
            },
          ],
        }),
      );
      ctx.isIdle = () => false;
      await handleInbound(pi, inbound("orig", "m1"), ctx);
      await flush();
      expect(
        await updateQueuedInbound(ctx, "ch1", "m1", "nope", [], "uid"),
      ).toBe(false);
      expect(midTurnQueues.get("ch1")?.[0].msg.body).toBe("orig");
      expect(
        await updateQueuedInbound(ctx, "ch1", "m1", "yes", [], "owner1"),
      ).toBe(true);
      expect(midTurnQueues.get("ch1")?.[0].msg.body).toBe("yes");
    });

    test("delete drops the entry (other channels untouched) and disarms it", async () => {
      ctx.isIdle = () => false;
      await handleInbound(pi, inbound("first", "m1"), ctx);
      await flush();
      const m2: ChannelMessage = {
        ...inbound("other channel", "cm2"),
        channelId: "ch2",
        channelName: "Other",
      };
      queueMidTurnInbound("ch2", m2, "ctx\n\ntext", "discord/Other", "text");
      expect(midTurnQueues.get("ch1")?.length).toBe(1);
      expect(midTurnQueues.get("ch2")?.length).toBe(1);
      expect(pendingInterrupts.get("ch1")?.length).toBe(1);
      expect(pendingInterrupts.get("ch2")?.length).toBe(1);

      await deleteQueuedInbound(ctx, "ch1", "m1");
      expect(midTurnQueues.has("ch1")).toBe(false);
      expect(pendingInterrupts.has("ch1")).toBe(false);
      // ch2's entry + armed interrupt survive.
      expect(midTurnQueues.get("ch2")?.length).toBe(1);
      expect(pendingInterrupts.get("ch2")?.length).toBe(1);
      // Deleting an unknown message is a no-op.
      await deleteQueuedInbound(ctx, "ch1", "ghost");
      expect(midTurnQueues.has("ch1")).toBe(false);
    });

    test("delete cleans up the ack and renumbers the remaining line", async () => {
      verboseOverride.set("ch1", 1); // verbose 1: the [queued] ack posts
      await handlers.session_start?.(null, ctx); // configRoot for ack REST
      ctx.isIdle = () => false;
      await handleInbound(pi, inbound("first", "m1"), ctx);
      await handleInbound(pi, inbound("second", "m2"), ctx);
      await flush();
      expect(queuedAcks.get("m1")?.pos).toBe(1);
      expect(queuedAcks.get("m2")?.pos).toBe(2);

      await deleteQueuedInbound(ctx, "ch1", "m1");
      await flush();
      expect(queuedAcks.has("m1")).toBe(false);
      expect(queuedAcks.get("m2")?.pos).toBe(1);
      const del = fetchCalls.find(
        (c) =>
          c.method === "DELETE" && c.url.includes("/channels/ch1/messages/"),
      );
      expect(del).toBeDefined();
      const patch = fetchCalls.find(
        (c) =>
          c.method === "PATCH" &&
          String(JSON.parse(c.body).content).includes("[queued] 1 in line"),
      );
      expect(patch).toBeDefined();
    });

    test("delete is owner-only", async () => {
      verboseOverride.set("ch1", 1); // verbose 1: the [queued] ack posts
      fs.writeFileSync(
        path.join(tmp, ".pi", "settings.json"),
        JSON.stringify({
          channels: [
            {
              id: "ch1",
              name: "Test",
              type: "discord",
              botToken: "tok1",
              ownerUserId: "owner1",
            },
          ],
        }),
      );
      ctx.isIdle = () => false;
      await handleInbound(pi, inbound("first", "m1"), ctx);
      await flush();
      // m1's author is "uid" — not the owner → entry and ack survive.
      await deleteQueuedInbound(ctx, "ch1", "m1");
      expect(midTurnQueues.get("ch1")?.length).toBe(1);
      expect(queuedAcks.has("m1")).toBe(true);
    });

    test("consumed re-wake drops its ack and renumbers the rest", async () => {
      verboseOverride.set("ch1", 1); // verbose 1: the [queued] ack posts
      await handlers.session_start?.(null, ctx); // configRoot for ack REST
      ctx.isIdle = () => false;
      await handleInbound(pi, inbound("first", "m1"), ctx);
      await handleInbound(pi, inbound("second", "m2"), ctx);
      await flush();
      expect(queuedAcks.get("m2")?.pos).toBe(2);

      idle = true; // the run ends
      await handlers.agent_end({ messages: [] }, ctx);
      await flush();
      expect(sent.length).toBe(1);
      expect(sent[0].m.details.body).toBe("first");
      expect(queuedAcks.has("m1")).toBe(false);
      expect(queuedAcks.get("m2")?.pos).toBe(1);
      const del = fetchCalls.find(
        (c) =>
          c.method === "DELETE" && c.url.includes("/channels/ch1/messages/"),
      );
      expect(del).toBeDefined();
    });
  });

  test("F2: second-channel inbound during the re-wake await does not retarget the first run's failure post", async () => {
    // Two channels configured so the second channel resolves.
    fs.writeFileSync(
      path.join(tmp, ".pi", "settings.json"),
      JSON.stringify({
        channels: [
          {
            id: "ch1",
            name: "One",
            type: "discord",
            botToken: "tok1",
            ownerUserId: "uid",
            ack: true,
          },
          {
            id: "ch2",
            name: "Two",
            type: "discord",
            botToken: "tok2",
            ack: true,
          },
        ],
      }),
    );
    const ch2 = (body: string, id: string): ChannelMessage => ({
      channelId: "ch2",
      channelName: "Two",
      channelType: "discord",
      messageId: id,
      from: "u2",
      fromId: "uid2",
      body,
      timestamp: new Date().toISOString(),
      attachments: [],
      isRoom: false,
    });

    ctx.isIdle = () => false; // a run is in flight on ch1
    await handleInbound(pi, inbound("queued cb", "m900"), ctx);
    expect(midTurnQueues.get("ch1")?.length).toBe(1);

    // The run ends with a failure; the re-wake starts (suspended mid-await).
    const failure = {
      role: "assistant",
      content: [{ type: "text", text: "" }],
      stopReason: "error",
      errorMessage: "boom",
    };
    const p = handlers.agent_end({ messages: [failure] }, ctx);

    // While the re-wake is in flight, a second channel's inbound lands and
    // becomes the last active channel (itself queued — still mid-run).
    await handleInbound(pi, ch2("other channel", "m901"), ctx);
    expect(midTurnQueues.get("ch2")?.length).toBe(1);

    await p;

    // The re-wake fired for ch1's queued message.
    expect(sent.length).toBe(1);
    // The ORIGINAL run's failure post targets ch1 (channel captured before
    // the re-wake await), not ch2 — what lastActiveChannel points at after.
    const ch1Posts = fetchCalls.filter(
      (c) => c.method === "POST" && c.url.endsWith("/channels/ch1/messages"),
    );
    expect(
      ch1Posts.some((c) => String(JSON.parse(c.body).content).includes("boom")),
    ).toBe(true);
    const ch2FailPosts = fetchCalls.filter(
      (c) =>
        c.method === "POST" &&
        c.url.endsWith("/channels/ch2/messages") &&
        String(JSON.parse(c.body).content).includes("boom"),
    );
    expect(ch2FailPosts.length).toBe(0);
  });

  test("F3: re-wake preserves the pending attachment batch", async () => {
    // #24 flipped the default (file-only now fires a turn); this test pins
    // the explicit bufferFileOnly: true behavior.
    fs.writeFileSync(
      path.join(tmp, ".pi", "settings.json"),
      JSON.stringify({
        channels: [
          {
            id: "ch1",
            name: "Test",
            type: "discord",
            botToken: "tok1",
            ownerUserId: "uid",
            bufferFileOnly: true,
          },
        ],
      }),
    );
    ctx.isIdle = () => false; // a run is in flight
    // 1. File-only message → buffered (no text, no voice note).
    const fileOnly = inbound("", "m300");
    fileOnly.attachments = [
      { id: "b1", filename: "notes.txt", contentType: "text/plain", size: 50 },
    ];
    await handleInbound(pi, fileOnly, ctx);
    expect(pendingAttachments.get("ch1")?.length).toBe(1);
    expect(sent.length).toBe(0);
    // 2. Text follow-up mid-run → gated for a re-wake; the pending batch must
    //    survive (the re-wake pass re-applies the file context).
    await handleInbound(pi, inbound("read this", "m301"), ctx);
    expect(sent.length).toBe(0);
    expect(midTurnQueues.get("ch1")?.length).toBe(1);
    expect(pendingAttachments.get("ch1")?.length).toBe(1);
    // 3. The re-wake sends the text WITH the buffered file context.
    await handlers.agent_end({ messages: [] }, ctx);
    expect(sent.length).toBe(1);
    expect(sent[0].m.content).toContain("notes.txt");
    expect(sent[0].m.details.body).toContain("read this");
    // The batch was consumed by the re-wake pass.
    expect(pendingAttachments.has("ch1")).toBe(false);
  });

  test("#24: file-only with default config fires a turn immediately (no buffer)", async () => {
    // No bufferFileOnly in settings → default FALSE → file-only fires a turn.
    const fileOnly = inbound("", "m400");
    fileOnly.attachments = [
      { id: "b1", filename: "notes.txt", contentType: "text/plain", size: 50 },
    ];
    await handleInbound(pi, fileOnly, ctx);
    expect(pendingAttachments.has("ch1")).toBe(false);
    expect(sent.length).toBe(1);
    expect(sent[0].m.content).toContain(
      "[user sent 1 file without text: notes.txt]",
    );
    expect(sent[0].m.content).toContain("notes.txt");
    // No [buffered] ack posted on the default path.
    const bufferedAck = fetchCalls.find(
      (c) =>
        c.method === "POST" &&
        String(JSON.parse(c.body).content).includes("[buffered]"),
    );
    expect(bufferedAck).toBeUndefined();
  });

  test("#24: bufferFileOnly:true buffers, posts ONE [buffered] ack, text follow-up consumes", async () => {
    fs.writeFileSync(
      path.join(tmp, ".pi", "settings.json"),
      JSON.stringify({
        channels: [
          {
            id: "ch1",
            name: "Test",
            type: "discord",
            botToken: "tok1",
            ownerUserId: "uid",
            bufferFileOnly: true,
          },
        ],
      }),
    );
    const fileOnly = inbound("", "m401");
    fileOnly.attachments = [
      { id: "b1", filename: "a.txt", contentType: "text/plain", size: 10 },
      { id: "b2", filename: "b.jpg", contentType: "image/jpeg", size: 20 },
    ];
    await handleInbound(pi, fileOnly, ctx);
    // Buffered, no turn.
    expect(sent.length).toBe(0);
    expect(pendingAttachments.get("ch1")?.length).toBe(1);
    // Exactly one visible [buffered] ack line.
    const acks = fetchCalls.filter(
      (c) =>
        c.method === "POST" &&
        String(JSON.parse(c.body).content).includes("[buffered]"),
    );
    expect(acks.length).toBe(1);
    expect(JSON.parse(acks[0].body).content).toContain(
      "[buffered] 2 files - send text to attach them",
    );
    // v4: the [buffered] ack ships BARE - no code fence (STYLE §3.1 ruling,
    // 2026-10-20; pins the unfence so a re-added fence fails this test)
    expect(JSON.parse(acks[0].body).content).not.toContain("```");
    // No regression: text after buffer consumes the batch with file context.
    fetchCalls.length = 0;
    await handleInbound(pi, inbound("look at these", "m402"), ctx);
    expect(sent.length).toBe(1);
    expect(sent[0].m.content).toContain("a.txt");
    expect(sent[0].m.content).toContain("b.jpg");
    expect(sent[0].m.details.body).toContain("look at these");
    expect(pendingAttachments.has("ch1")).toBe(false);
    // The text follow-up posts no second [buffered] ack.
    const acks2 = fetchCalls.filter(
      (c) =>
        c.method === "POST" &&
        String(JSON.parse(c.body).content).includes("[buffered]"),
    );
    expect(acks2.length).toBe(0);
  });

  test("#24: buffered batch auto-flushes as a file-only turn at 10 minutes (frozen clock)", async () => {
    jest.useFakeTimers();
    const t0 = Date.now();
    const nowSpy = jest.spyOn(Date, "now").mockReturnValue(t0);
    try {
      fs.writeFileSync(
        path.join(tmp, ".pi", "settings.json"),
        JSON.stringify({
          channels: [
            {
              id: "ch1",
              name: "Test",
              type: "discord",
              botToken: "tok1",
              ownerUserId: "uid",
              bufferFileOnly: true,
            },
          ],
        }),
      );
      const fileOnly = inbound("", "m403");
      fileOnly.attachments = [
        { id: "b1", filename: "late.txt", contentType: "text/plain", size: 30 },
      ];
      await handleInbound(pi, fileOnly, ctx);
      expect(pendingAttachments.get("ch1")?.length).toBe(1);
      expect(sent.length).toBe(0);
      // session_start arms the 60s flush ticker (sleepPoller alongside).
      await handlers.session_start(null, ctx);
      // 9 minutes of ticks: batch not yet due, nothing fires.
      nowSpy.mockReturnValue(t0 + 9 * 60_000);
      jest.advanceTimersByTime(9 * 60_000);
      expect(sent.length).toBe(0);
      expect(pendingAttachments.has("ch1")).toBe(true);
      // Cross the 10-minute boundary: next tick flushes a file-only turn.
      nowSpy.mockReturnValue(t0 + 11 * 60_000);
      jest.advanceTimersByTime(2 * 60_000);
      expect(sent.length).toBe(1);
      expect(sent[0].m.content).toContain(
        "[user sent 1 file without text: late.txt]",
      );
      expect(sent[0].m.details.body).toContain("late.txt");
      // The batch was consumed by the flush.
      expect(pendingAttachments.has("ch1")).toBe(false);
    } finally {
      nowSpy.mockRestore();
      jest.useRealTimers();
    }
  });

  test("#24: voice-note-only message is not buffered (unaffected by the default flip)", async () => {
    fs.writeFileSync(
      path.join(tmp, ".pi", "settings.json"),
      JSON.stringify({
        channels: [
          {
            id: "ch1",
            name: "Test",
            type: "discord",
            botToken: "tok1",
            ownerUserId: "uid",
            bufferFileOnly: true,
          },
        ],
      }),
    );
    const voice = inbound("", "m404");
    voice.attachments = [
      {
        id: "v1",
        filename: "recording.m4a",
        contentType: "audio/ogg",
        size: 1000,
        duration: 12,
      },
    ];
    await handleInbound(pi, voice, ctx);
    // Voice note fires a turn with its marker line; nothing buffered, no ack.
    expect(pendingAttachments.has("ch1")).toBe(false);
    expect(sent.length).toBe(1);
    expect(sent[0].m.content).toContain("[voice note: recording.m4a (12s)]");
    expect(sent[0].m.content).not.toContain("[buffered]");
    const acks = fetchCalls.filter(
      (c) =>
        c.method === "POST" &&
        String(JSON.parse(c.body).content).includes("[buffered]"),
    );
    expect(acks.length).toBe(0);
  });

  test("repetition: 3 consecutive identical finals → abort + one warning, 3rd dropped", async () => {
    let aborts = 0;
    ctx.abort = () => {
      aborts++;
    };
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    await handlers.turn_start(null, ctx);
    const fin = (t: string) => ({
      role: "assistant",
      content: [{ type: "text", text: t }],
    });
    await handlers.message_end({ message: fin("same") }, ctx);
    await handlers.message_end({ message: fin("same") }, ctx);
    await handlers.message_end({ message: fin("same") }, ctx);

    expect(aborts).toBe(1);
    const contents = fetchCalls
      .filter(
        (c) => c.method === "POST" && c.url.endsWith("/channels/ch1/messages"),
      )
      .map((c) => JSON.parse(c.body).content);
    expect(contents.filter((t) => t === "same").length).toBe(2); // 3rd dropped
    expect(contents.filter((t) => t.includes(REPEAT_WARNING)).length).toBe(1);

    // 4th identical does not re-warn (counter reset after the trip).
    await handlers.message_end({ message: fin("same") }, ctx);
    expect(aborts).toBe(1);
    const after = fetchCalls
      .filter(
        (c) => c.method === "POST" && c.url.endsWith("/channels/ch1/messages"),
      )
      .map((c) => JSON.parse(c.body).content);
    expect(after.filter((t) => t.includes(REPEAT_WARNING)).length).toBe(1);
  });

  test("repetition: a different final resets the counter", async () => {
    let aborts = 0;
    ctx.abort = () => {
      aborts++;
    };
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    await handlers.turn_start(null, ctx);
    const fin = (t: string) => ({
      role: "assistant",
      content: [{ type: "text", text: t }],
    });
    for (const t of ["a", "a", "b", "a", "a"]) {
      await handlers.message_end({ message: fin(t) }, ctx);
    }
    expect(aborts).toBe(0);
  });

  test("repetition: a new inbound user message resets the counter", async () => {
    let aborts = 0;
    ctx.abort = () => {
      aborts++;
    };
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    await handlers.turn_start(null, ctx);
    const fin = (t: string) => ({
      role: "assistant",
      content: [{ type: "text", text: t }],
    });
    await handlers.message_end({ message: fin("a") }, ctx);
    await handlers.message_end({ message: fin("a") }, ctx);
    await handleInbound(pi, inbound("more", "m2"), ctx); // resets the counter
    await handlers.message_end({ message: fin("a") }, ctx);
    await handlers.message_end({ message: fin("a") }, ctx);
    expect(aborts).toBe(0);
  });

  test("repetition: agent_end finals trip the guard once, warning posted", async () => {
    let aborts = 0;
    ctx.abort = () => {
      aborts++;
    };
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    const fin = (t: string) => ({
      role: "assistant",
      content: [{ type: "text", text: t }],
    });
    await handlers.agent_end({ messages: [fin("x"), fin("x")] }, ctx);
    expect(aborts).toBe(0);
    await handlers.agent_end({ messages: [fin("x")] }, ctx);
    expect(aborts).toBe(1);
    const contents = fetchCalls
      .filter(
        (c) => c.method === "POST" && c.url.endsWith("/channels/ch1/messages"),
      )
      .map((c) => JSON.parse(c.body).content);
    // agent_end posts go through mdToDiscord: the bare warning line is
    // guarded (fenced; no 40-col wrap since 2026-10-18)
    expect(
      contents.filter((t) => t === styleGuard(REPEAT_WARNING)).length,
    ).toBe(1);
  });

  test("F1: /undo re-run — session_start re-sends the parked trigger after the undo-restart", async () => {
    // Redirect HOME so the undo store + sessions dir live under tmp.
    const oldHome = process.env.HOME || "";
    process.env.HOME = path.join(tmp, "home");
    const sessDir = path.join(
      process.env.HOME,
      ".pi",
      "agent",
      "sessions",
      `-${tmp}-`,
    );
    fs.mkdirSync(sessDir, { recursive: true });
    const sess = path.join(sessDir, "s.jsonl");
    const lines = [
      { type: "session", version: 3, id: "s1", timestamp: "t", cwd: tmp },
      {
        type: "custom_message",
        id: "t1",
        parentId: null,
        customType: "channel-inbound",
        content: "<channel-ctx>ch: Test</channel-ctx>\n\nfix the bug",
        details: { title: "Test", body: "fix the bug" },
      },
      {
        type: "message",
        id: "a1",
        parentId: "t1",
        message: {
          role: "assistant",
          content: [{ type: "text", text: "done" }],
        },
      },
    ];
    fs.writeFileSync(
      sess,
      `${lines.map((l) => JSON.stringify(l)).join("\n")}\n`,
    );

    // /undo: truncate + park the re-run trigger (restarted=true would then
    // scheduleRestart -> systemd respawns pi -> fresh process, new session_start).
    const r = performUndo(sess);
    expect(r.restarted).toBe(true);
    expect(r.reRun).toBe(true);
    expect(fs.readFileSync(sess, "utf8").trim().split("\n")).toHaveLength(2); // through t1 (a1 removed)

    const sentBefore = sent.length;
    await handlers.session_start?.(null, ctx);
    process.env.HOME = oldHome;

    // the bridge re-sent the kept trigger through the normal inbound path
    const rerun = sent
      .slice(sentBefore)
      .find(
        (s) =>
          s.m.customType === "channel-inbound" &&
          s.m.details?.body === "fix the bug",
      );
    expect(rerun).toBeDefined();
    expect(rerun?.o?.triggerTurn).toBe(true);
  });

  test("F1: session_start without a parked rerun sends nothing", async () => {
    const oldHome = process.env.HOME || "";
    process.env.HOME = path.join(tmp, "home"); // keep the store away from the real HOME
    fs.mkdirSync(process.env.HOME, { recursive: true });
    const sentBefore = sent.length;
    await handlers.session_start?.(null, ctx);
    process.env.HOME = oldHome;
    expect(sent.length).toBe(sentBefore);
  });
});

// ─── #42 voice-note transcription: wiring in the attachment branch ──────
// Stub convention (jobs.test.ts): sh scripts in a temp dir, prepended to
// PATH. The whisper-cli stub echoes a fixed transcript; the ffmpeg stub
// stands in for the m4a -> 16 kHz wav conversion (it writes the output
// file whisper-cli would read).

describe("voice transcription (#42)", () => {
  let tmp = "";
  let scriptsDir = "";
  let pi: any;
  let ctx: any;
  let handlers: Record<string, (...a: any[]) => any> = {};
  let sent: { m: any; o?: any }[] = [];
  let fetchCalls: { url: string; method: string; body?: any }[] = [];
  const realFetch = globalThis.fetch;
  const savedEnv: Record<string, string | undefined> = {};
  const ENV_KEYS = [
    "PATH",
    "JB_TRANSCRIBE_BIN",
    "JB_TRANSCRIBE_MODEL",
    "JB_TRANSCRIBE_FFMPEG",
    "JB_TRANSCRIBE_TIMEOUT_S",
    "JB_TRANSCRIBE_THREADS",
  ];

  const inbound = (body: string, id: string): ChannelMessage => ({
    channelId: "ch1",
    channelName: "Test",
    channelType: "discord",
    messageId: id,
    from: "u",
    fromId: "uid",
    body,
    timestamp: new Date().toISOString(),
    attachments: [],
    isRoom: false,
  });

  const voiceAtt = (over: Partial<any> = {}): any => ({
    id: "v1",
    filename: "recording.m4a",
    contentType: "audio/mp4",
    size: 1000,
    duration: 12,
    url: "https://files.example/recording.m4a",
    ...over,
  });

  function stub(name: string, body: string): void {
    const p = path.join(scriptsDir, name);
    fs.writeFileSync(p, body);
    fs.chmodSync(p, 0o755);
  }

  function writeSettings(channels: any[]): void {
    fs.writeFileSync(
      path.join(tmp, ".pi", "settings.json"),
      JSON.stringify({ channels }),
    );
  }

  const FFMPEG_OK = `#!/bin/sh
out=""
for a in "$@"; do out="$a"; done
printf RIFF > "$out"
exit 0
`;
  const WHISPER_OK = (sentinel?: string) =>
    `#!/bin/sh\n` +
    (sentinel ? `echo x >> ${sentinel}\n` : "") +
    `echo "hello transcript words"\n`;

  beforeEach(() => {
    tmp = fs.mkdtempSync(path.join(os.tmpdir(), "voice-42-"));
    fs.mkdirSync(path.join(tmp, ".pi"), { recursive: true });
    scriptsDir = path.join(tmp, "scripts");
    fs.mkdirSync(scriptsDir, { recursive: true });
    writeSettings([
      { id: "ch1", name: "Test", type: "discord", botToken: "tok1" },
    ]);
    handlers = {};
    sent = [];
    midTurnQueues.clear();
    pendingAttachments.clear();
    verboseOverride.clear();
    fetchCalls = [];
    pi = {
      registerMessageRenderer: () => {},
      registerTool: () => {},
      on: (n: string, fn: any) => {
        handlers[n] = fn;
      },
      sendMessage: (m: any, o?: any) => {
        sent.push({ m, o });
      },
    };
    extension(pi);
    ctx = {
      cwd: tmp,
      ui: { setStatus: () => {} },
      isIdle: () => true,
      hasPendingMessages: () => false,
      abort: () => {},
    };
    // fetch mock: audio URLs serve a small buffer, everything else is the
    // plain REST stub (message posts return { id }).
    globalThis.fetch = (async (url: any, init?: any) => {
      const u = String(url);
      fetchCalls.push({
        url: u,
        method: init?.method ?? "GET",
        body: init?.body,
      });
      if (u.startsWith("https://files.example/")) {
        return {
          ok: true,
          status: 200,
          headers: {
            get: (h: string) =>
              h.toLowerCase() === "content-length" ? "1000" : null,
          },
          arrayBuffer: async () => new Uint8Array([1, 2, 3, 4]).buffer,
        };
      }
      return {
        ok: true,
        status: 200,
        json: async () => ({ id: "out" }),
        text: async () => "",
      };
    }) as any;
    // PATH: stub dir first; drop JB_TRANSCRIBE_* so defaults apply, then
    // point JB_TRANSCRIBE_MODEL at a fake model in tmp so the existsSync
    // gate passes on fresh HOMEs (CI runners without the real
    // ggml-base.bin). The stub whisper-cli never parses it.
    for (const k of ENV_KEYS) savedEnv[k] = process.env[k];
    process.env.PATH = `${scriptsDir}${path.delimiter}${savedEnv.PATH ?? ""}`;
    for (const k of ENV_KEYS.slice(1)) delete process.env[k];
    const fakeModel = path.join(tmp, "ggml-fake.bin");
    fs.writeFileSync(fakeModel, "FAKE-WHISPER-MODEL\n");
    process.env.JB_TRANSCRIBE_MODEL = fakeModel;
  });

  afterEach(async () => {
    clearDiscordStatesForTest(); // no auto-react suppression leaks across tests
    for (const k of ENV_KEYS) {
      if (savedEnv[k] === undefined) delete process.env[k];
      else process.env[k] = savedEnv[k];
    }
    midTurnQueues.clear();
    pendingAttachments.clear();
    clearAllInterrupts();
    setInterruptCtx(null);
    await handlers.agent_end?.({ messages: [] }, ctx);
    globalThis.fetch = realFetch;
    fs.rmSync(tmp, { recursive: true, force: true });
  });

  test("m4a + working stubs -> transcript inlined, marker gone", async () => {
    stub("ffmpeg", FFMPEG_OK);
    stub("whisper-cli", WHISPER_OK());
    const v = inbound("", "m42a");
    v.attachments = [voiceAtt()];
    await handleInbound(pi, v, ctx);
    expect(sent.length).toBe(1);
    expect(sent[0].m.content).toContain("hello transcript words");
    expect(sent[0].m.content).not.toContain("[voice note:");
    // the agent sees the words as plain message text (display body too)
    expect(sent[0].m.details.body).toContain("hello transcript words");
  });

  test("stub exits 1 -> marker fallback kept", async () => {
    stub("ffmpeg", FFMPEG_OK);
    stub("whisper-cli", "#!/bin/sh\nexit 1\n");
    const v = inbound("", "m42b");
    v.attachments = [voiceAtt()];
    await handleInbound(pi, v, ctx);
    expect(sent.length).toBe(1);
    expect(sent[0].m.content).toContain("[voice note: recording.m4a (12s)]");
    expect(sent[0].m.content).not.toContain("hello transcript words");
  });

  test("opt-out channel (transcribe: false) -> no transcribe call", async () => {
    const sentinel = path.join(tmp, "whisper-called");
    writeSettings([
      {
        id: "ch1",
        name: "Test",
        type: "discord",
        botToken: "tok1",
        ownerUserId: "uid",
        transcribe: false,
      },
    ]);
    stub("ffmpeg", FFMPEG_OK);
    stub("whisper-cli", WHISPER_OK(sentinel));
    const v = inbound("", "m42c");
    v.attachments = [voiceAtt()];
    await handleInbound(pi, v, ctx);
    expect(sent.length).toBe(1);
    expect(sent[0].m.content).toContain("[voice note: recording.m4a (12s)]");
    expect(sent[0].m.content).not.toContain("hello transcript words");
    expect(fs.existsSync(sentinel)).toBe(false);
  });

  test("non-audio attachment -> no transcribe call", async () => {
    const sentinel = path.join(tmp, "whisper-called");
    stub("whisper-cli", WHISPER_OK(sentinel));
    const m = inbound("read this", "m42d");
    m.attachments = [
      {
        id: "t1",
        filename: "notes.txt",
        contentType: "text/plain",
        size: 30,
        url: "https://files.example/notes.txt",
      },
    ];
    await handleInbound(pi, m, ctx);
    expect(sent.length).toBe(1);
    expect(sent[0].m.content).toContain("notes.txt");
    expect(fs.existsSync(sentinel)).toBe(false);
  });

  test("voice note with failed download -> marker, no transcribe call", async () => {
    const sentinel = path.join(tmp, "whisper-called");
    stub("ffmpeg", FFMPEG_OK);
    stub("whisper-cli", WHISPER_OK(sentinel));
    const v = inbound("", "m42e");
    v.attachments = [voiceAtt({ url: undefined })]; // download fails
    await handleInbound(pi, v, ctx);
    expect(sent.length).toBe(1);
    expect(sent[0].m.content).toContain("[voice note: recording.m4a (12s)]");
    expect(fs.existsSync(sentinel)).toBe(false);
  });

  test("wav voice note -> native path, no ffmpeg needed", async () => {
    stub("whisper-cli", WHISPER_OK());
    const v = inbound("", "m42f");
    v.attachments = [
      voiceAtt({
        id: "v2",
        filename: "tone.wav",
        contentType: "audio/wav",
        url: "https://files.example/tone.wav",
      }),
    ];
    await handleInbound(pi, v, ctx);
    expect(sent.length).toBe(1);
    expect(sent[0].m.content).toContain("hello transcript words");
    expect(sent[0].m.content).not.toContain("[voice note:");
  });

  test("voice note + text -> transcript replaces marker, text kept", async () => {
    stub("ffmpeg", FFMPEG_OK);
    stub("whisper-cli", WHISPER_OK());
    const v = inbound("what did I just say?", "m42g");
    v.attachments = [voiceAtt()];
    await handleInbound(pi, v, ctx);
    expect(sent.length).toBe(1);
    expect(sent[0].m.content).toContain("what did I just say?");
    expect(sent[0].m.content).toContain("hello transcript words");
    expect(sent[0].m.content).not.toContain("[voice note:");
  });
});

// ─── #39 /hold: channel-wide queue mode ──────────────────────────────

describe("#39 /hold", () => {
  let tmp = "";
  let pi: any;
  let ctx: any;
  let handlers: Record<string, (...a: any[]) => any> = {};
  let sent: { m: any; o?: any }[] = [];
  let fetchCalls: { url: string; method: string; body?: any }[] = [];
  const realFetch = globalThis.fetch;

  const OWNER = "1000000000000000001";
  const inbound = (body: string, id: string): ChannelMessage => ({
    channelId: "ch1",
    channelName: "Test",
    channelType: "discord",
    messageId: id,
    from: "u",
    fromId: OWNER,
    body,
    timestamp: new Date().toISOString(),
    attachments: [],
    isRoom: false,
  });
  const otherInbound = (body: string, id: string): ChannelMessage => ({
    ...inbound(body, id),
    fromId: "someone-else",
  });
  const flush = async () => {
    for (let i = 0; i < 5; i++) await new Promise((r) => setImmediate(r));
  };
  const posts = () =>
    fetchCalls
      .filter(
        (c) => c.method === "POST" && c.url.endsWith("/channels/ch1/messages"),
      )
      .map((c) => String(JSON.parse(c.body).content));
  const mockBusy = (b: boolean) => {
    ctx.isIdle = () => !b;
  };

  beforeEach(() => {
    tmp = fs.mkdtempSync(path.join(os.tmpdir(), "jarate-hold-"));
    fs.mkdirSync(path.join(tmp, ".pi"), { recursive: true });
    fs.writeFileSync(
      path.join(tmp, ".pi", "settings.json"),
      JSON.stringify({
        channels: [
          {
            id: "ch1",
            name: "Test",
            type: "discord",
            botToken: "tok1",
            ack: true,
            ownerUserId: OWNER,
            forwardToolCalls: false,
          },
        ],
      }),
    );
    handlers = {};
    sent = [];
    fetchCalls = [];
    midTurnQueues.clear();
    pendingAttachments.clear();
    verboseOverride.clear();
    heldChannels.clear();
    setRuntimeStateDir(null);
    pi = {
      registerMessageRenderer: () => {},
      registerTool: () => {},
      on: (n: string, fn: any) => {
        handlers[n] = fn;
      },
      sendMessage: (m: any, o?: any) => {
        sent.push({ m, o });
      },
    };
    extension(pi);
    ctx = {
      cwd: tmp,
      ui: { setStatus: () => {} },
      isIdle: () => true,
      hasPendingMessages: () => false,
      abort: () => {},
    };
    globalThis.fetch = (async (url: any, init?: any) => {
      fetchCalls.push({
        url: String(url),
        method: init?.method ?? "GET",
        body: init?.body,
      });
      return {
        ok: true,
        status: 200,
        json: async () => ({ id: "out1" }),
        text: async () => "",
      };
    }) as any;
  });

  afterEach(async () => {
    clearDiscordStatesForTest(); // no auto-react suppression leaks across tests
    jest.useRealTimers();
    midTurnQueues.clear();
    pendingAttachments.clear();
    clearAllInterrupts();
    setInterruptCtx(null);
    setRuntimeStateDir(null);
    await handlers.agent_end?.({ messages: [] }, ctx); // clears any typing interval
    globalThis.fetch = realFetch;
    fs.rmSync(tmp, { recursive: true, force: true });
  });

  test("matchCommand: /hold variants", () => {
    expect(matchCommand("/hold")!.name).toBe("hold");
    expect(matchCommand("/hold on")!.arg).toBe("on");
    expect(matchCommand("/hold OFF")!.arg).toBe("OFF");
    expect(matchCommand("/holdup")).toBeNull();
  });

  test("popChannelQueuedInbound: FIFO per channel, rest stays", async () => {
    mockBusy(true);
    await handleInbound(pi, inbound("a", "m1"), ctx);
    await handleInbound(pi, inbound("b", "m2"), ctx);
    const e1 = popChannelQueuedInbound("ch1");
    expect(e1?.msg.body).toBe("a");
    expect(midTurnQueues.get("ch1")?.length).toBe(1);
    const e2 = popChannelQueuedInbound("ch1");
    expect(e2?.msg.body).toBe("b");
    expect(popChannelQueuedInbound("ch1")).toBeNull();
    expect(midTurnQueues.has("ch1")).toBe(false);
  });

  test("held + idle: plain message queues, no run, no interrupt armed", async () => {
    verboseOverride.set("ch1", 1); // verbose 1: the [queued] ack posts
    await handleInbound(pi, inbound("/hold on", "m1"), ctx);
    expect(
      posts().some((t) =>
        t.includes("[ok] hold on - buffered until /hold off"),
      ),
    ).toBe(true);
    expect(isHeld(loadChannelConfig(ctx.cwd)[0]!)).toBe(true);

    await handleInbound(pi, inbound("hello there", "m2"), ctx);
    await flush();
    expect(sent).toHaveLength(0); // buffered, not sent to pi
    expect(midTurnQueues.get("ch1")?.length).toBe(1);
    expect(posts().some((t) => t.includes("[queued] 1 in line"))).toBe(true);
    expect(pendingInterrupts.get("ch1")).toBeUndefined(); // no armed interrupt

    // second message stacks behind it
    await handleInbound(pi, inbound("and this too", "m3"), ctx);
    expect(midTurnQueues.get("ch1")?.length).toBe(2);
  });

  test("agent_end skips a held channel; /hold off drains FIFO", async () => {
    mockBusy(true);
    await handleInbound(pi, inbound("/hold on", "m1"), ctx);
    await handleInbound(pi, inbound("first", "m2"), ctx);
    await handleInbound(pi, inbound("second", "m3"), ctx);
    // run ends while held: the buffer must NOT drain
    await handlers.agent_end({ messages: [] }, ctx);
    expect(sent).toHaveLength(0);
    expect(midTurnQueues.get("ch1")?.length).toBe(2);

    // release while the channel is idle: oldest runs now
    mockBusy(false);
    await handleInbound(pi, inbound("/hold off", "m4"), ctx);
    await flush();
    expect(sent.map((s) => s.m.details.body)).toEqual(["first"]);
    expect(sent[0].o.triggerTurn).toBe(true);
    expect(
      posts().some((t) => t.includes("[ok] hold off - 2 in line, running")),
    ).toBe(true);

    // that run ends: the re-wake loop chains the rest
    await handlers.agent_end({ messages: [] }, ctx);
    expect(sent.map((s) => s.m.details.body)).toEqual(["first", "second"]);
    expect(midTurnQueues.has("ch1")).toBe(false);
  });

  test("/hold off while a run is in flight: no immediate send, drains at run end", async () => {
    mockBusy(true);
    await handleInbound(pi, inbound("/hold on", "m1"), ctx);
    await handleInbound(pi, inbound("first", "m2"), ctx);
    await handleInbound(pi, inbound("second", "m3"), ctx);
    await handleInbound(pi, inbound("/hold off", "m4"), ctx);
    await flush();
    expect(sent).toHaveLength(0); // still running: wait for agent_end
    expect(
      posts().some((t) => t.includes("[ok] hold off - 2 in line, will run")),
    ).toBe(true);
    expect(midTurnQueues.get("ch1")?.length).toBe(2);

    await handlers.agent_end({ messages: [] }, ctx);
    expect(sent.map((s) => s.m.details.body)).toEqual(["first"]);
    await handlers.agent_end({ messages: [] }, ctx);
    expect(sent.map((s) => s.m.details.body)).toEqual(["first", "second"]);
  });

  test("/stop while held keeps the buffer and reports it", async () => {
    mockBusy(true);
    await handleInbound(pi, inbound("/hold on", "m1"), ctx);
    await handleInbound(pi, inbound("first", "m2"), ctx);
    await handleInbound(pi, inbound("second", "m3"), ctx);
    expect(midTurnQueues.get("ch1")?.length).toBe(2);

    await handleInbound(pi, inbound("/stop", "m4"), ctx);
    expect(
      posts().some((t) => t.includes("[-] stopped - 2 held in line")),
    ).toBe(true);
    expect(midTurnQueues.get("ch1")?.length).toBe(2); // buffer intact

    // /stop on a NON-held channel still drains (regression guard)
    heldChannels.clear();
    await handleInbound(pi, inbound("/stop", "m5"), ctx);
    expect(posts().some((t) => t.includes("[-] stopped"))).toBe(true);
    expect(midTurnQueues.has("ch1")).toBe(false);
  });

  test("/hold on preserves an existing (non-held) line; off drains it", async () => {
    mockBusy(true);
    await handleInbound(pi, inbound("early", "m1"), ctx); // queued, interrupt armed
    expect(pendingInterrupts.get("ch1")?.length).toBe(1);
    await handleInbound(pi, inbound("/hold on", "m2"), ctx);
    // arming stopped + the pending interrupt disarmed
    expect(pendingInterrupts.get("ch1")).toBeUndefined();
    expect(midTurnQueues.get("ch1")?.length).toBe(1);
    await handleInbound(pi, inbound("late", "m3"), ctx);
    expect(midTurnQueues.get("ch1")?.length).toBe(2);

    mockBusy(false); // channel settles before the release
    await handleInbound(pi, inbound("/hold off", "m4"), ctx);
    await flush();
    expect(sent.map((s) => s.m.details.body)).toEqual(["early"]);
  });

  test("commands still run while held", async () => {
    await handleInbound(pi, inbound("/hold on", "m1"), ctx);
    await handleInbound(pi, inbound("/status", "m2"), ctx);
    expect(posts().some((p) => p.includes("[status]"))).toBe(true);
    expect(sent).toHaveLength(0); // status is not a pi run
  });

  test("bare /hold toggles; bad arg is a usage error; non-owner rejected", async () => {
    await handleInbound(pi, inbound("/hold", "m1"), ctx);
    expect(isHeld(loadChannelConfig(ctx.cwd)[0]!)).toBe(true);
    await handleInbound(pi, inbound("/hold", "m2"), ctx);
    expect(isHeld(loadChannelConfig(ctx.cwd)[0]!)).toBe(false);

    await handleInbound(pi, inbound("/hold maybe", "m3"), ctx);
    expect(posts().some((t) => t.includes("[!] usage: /hold on|off"))).toBe(
      true,
    );

    await handleInbound(pi, otherInbound("/hold on", "m4"), ctx);
    // text-form command from a non-owner: not executed, and refused
    // explicitly. A recognised command must never fall through to pi as
    // plain text — the agent then answers the command as a prompt, which
    // reads as "the bridge is ignoring my commands" (2026-09-23).
    expect(isHeld(loadChannelConfig(ctx.cwd)[0]!)).toBe(false);
    expect(posts().some((t) => t.includes("[!] owner only"))).toBe(true);
    expect(sent).toHaveLength(0);
  });

  test("hold flag persists to channel-state.json and reloads after restart", async () => {
    const dir = path.join(tmp, ".tmp");
    setRuntimeStateDir(dir);
    await handleInbound(pi, inbound("/hold on", "m1"), ctx);
    const onDisk = JSON.parse(
      fs.readFileSync(path.join(dir, "channel-state.json"), "utf-8"),
    );
    expect(onDisk.channels.ch1.hold).toBe(true);

    // simulated process restart: in-memory wiped, file reloaded
    resetRuntimeStateForTest();
    setRuntimeStateDir(dir);
    expect(isHeld(loadChannelConfig(ctx.cwd)[0]!)).toBe(true);

    // release: file updates, reload sees it off
    await handleInbound(pi, inbound("/hold off", "m2"), ctx);
    resetRuntimeStateForTest();
    setRuntimeStateDir(dir);
    expect(isHeld(loadChannelConfig(ctx.cwd)[0]!)).toBe(false);
  });
});

// ─── #10 3-level persistent verbosity ────────────────────────────────

describe("#10 verbosity levels", () => {
  let tmp = "";
  let pi: any;
  let ctx: any;
  let handlers: Record<string, (...a: any[]) => any> = {};
  let sent: { m: any; o?: any }[] = [];
  let fetchCalls: { url: string; method: string; body?: any }[] = [];
  const realFetch = globalThis.fetch;

  const OWNER = "1000000000000000001";
  const inbound = (body: string, id: string): ChannelMessage => ({
    channelId: "ch1",
    channelName: "Test",
    channelType: "discord",
    messageId: id,
    from: "u",
    fromId: OWNER,
    body,
    timestamp: new Date().toISOString(),
    attachments: [],
    isRoom: false,
  });
  const posts = () =>
    fetchCalls
      .filter(
        (c) => c.method === "POST" && c.url.endsWith("/channels/ch1/messages"),
      )
      .map((c) => String(JSON.parse(c.body).content));
  const patches = () =>
    fetchCalls.filter((c) => c.method === "PATCH").map((c) => String(c.body));

  const setup = (channelOpts: Record<string, unknown> = {}) => {
    handlers = {};
    sent = [];
    fetchCalls = [];
    midTurnQueues.clear();
    pendingAttachments.clear();
    verboseOverride.clear();
    heldChannels.clear();
    setRuntimeStateDir(null);
    pi = {
      registerMessageRenderer: () => {},
      registerTool: () => {},
      on: (n: string, fn: any) => {
        handlers[n] = fn;
      },
      sendMessage: (m: any, o?: any) => {
        sent.push({ m, o });
      },
    };
    extension(pi);
    ctx = {
      cwd: tmp,
      ui: { setStatus: () => {} },
      isIdle: () => true,
      hasPendingMessages: () => false,
      abort: () => {},
    };
    fs.writeFileSync(
      path.join(tmp, ".pi", "settings.json"),
      JSON.stringify({
        channels: [
          {
            id: "ch1",
            name: "Test",
            type: "discord",
            botToken: "tok1",
            ack: true,
            ownerUserId: OWNER,
            forwardToolCalls: false,
            ...channelOpts,
          },
        ],
      }),
    );
  };

  beforeEach(() => {
    tmp = fs.mkdtempSync(path.join(os.tmpdir(), "jarate-verb-"));
    fs.mkdirSync(path.join(tmp, ".pi"), { recursive: true });
    setup();
    globalThis.fetch = (async (url: any, init?: any) => {
      fetchCalls.push({
        url: String(url),
        method: init?.method ?? "GET",
        body: init?.body,
      });
      return {
        ok: true,
        status: 200,
        json: async () => ({ id: "out1" }),
        text: async () => "",
      };
    }) as any;
  });

  afterEach(async () => {
    clearDiscordStatesForTest(); // no auto-react suppression leaks across tests
    jest.useRealTimers();
    midTurnQueues.clear();
    pendingAttachments.clear();
    clearAllInterrupts();
    setInterruptCtx(null);
    setRuntimeStateDir(null);
    await handlers.agent_end?.({ messages: [] }, ctx);
    globalThis.fetch = realFetch;
    fs.rmSync(tmp, { recursive: true, force: true });
  });

  test("parseVerboseLevel: digits, legacy, kimaki names, garbage", () => {
    expect(parseVerboseLevel("0")).toBe(0);
    expect(parseVerboseLevel("off")).toBe(0);
    expect(parseVerboseLevel("text")).toBe(0);
    expect(parseVerboseLevel("text-only")).toBe(0);
    expect(parseVerboseLevel("1")).toBe(1);
    expect(parseVerboseLevel("essential")).toBe(1);
    expect(parseVerboseLevel("text-and-essential-tools")).toBe(1);
    expect(parseVerboseLevel("2")).toBe(2);
    expect(parseVerboseLevel("on")).toBe(2);
    expect(parseVerboseLevel("all")).toBe(2);
    expect(parseVerboseLevel("tools-and-text")).toBe(2);
    expect(parseVerboseLevel("ON")).toBe(2);
    expect(parseVerboseLevel("3")).toBeNull();
    expect(parseVerboseLevel("maybe")).toBeNull();
  });

  test("bashToolEssential: read-only hidden, side effects shown", () => {
    const t = (c: string) => bashToolEssential({ command: c });
    // read-only
    expect(t("ls")).toBe(false);
    expect(t("cat /etc/hosts")).toBe(false);
    expect(t("git log --oneline")).toBe(false);
    expect(t("git status")).toBe(false);
    expect(t("git diff")).toBe(false);
    expect(t("git branch")).toBe(false);
    expect(t("git tag")).toBe(false);
    expect(t("git tag -l")).toBe(false);
    expect(t("git stash list")).toBe(false);
    expect(t("rg foo bar/")).toBe(false);
    expect(t("FOO=1 BAR=2 ls -la")).toBe(false);
    expect(t("ls | grep x")).toBe(false);
    expect(t("cat a && head b")).toBe(false);
    // side effects
    expect(t("git commit -m x")).toBe(true);
    expect(t("git push")).toBe(true);
    expect(t("git branch -d old")).toBe(true);
    expect(t("mkdir -p out")).toBe(true);
    expect(t("rm -rf node_modules")).toBe(true);
    expect(t("echo hi > out.txt")).toBe(true);
    expect(t("ls && rm x")).toBe(true);
    expect(t("bun test")).toBe(true); // unknown head = shown
    expect(t("")).toBe(false); // empty: nothing to show
  });

  test("isEssentialToolCall: non-essential set, MCP always shown", () => {
    for (const n of ["read", "grep", "ls", "find"])
      expect(isEssentialToolCall(n, {})).toBe(false);
    expect(isEssentialToolCall("edit", {})).toBe(true);
    expect(isEssentialToolCall("write", {})).toBe(true);
    expect(isEssentialToolCall("todo", {})).toBe(true);
    expect(isEssentialToolCall("tavily_tavily_search", {})).toBe(true);
    expect(isEssentialToolCall("jarate", {})).toBe(true);
    expect(isEssentialToolCall("bash", { command: "ls" })).toBe(false);
    expect(isEssentialToolCall("bash", { command: "git push" })).toBe(true);
  });

  test("level 1: non-essential calls hidden live, essentials shown", async () => {
    verboseOverride.set("ch1", 1);
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    await handlers.turn_start(null, ctx);
    // reads + read-only bash: no block created, no frame edited
    await handlers.tool_call(
      { toolName: "read", input: { path: "a.txt" } },
      ctx,
    );
    await handlers.tool_call(
      { toolName: "bash", input: { command: "ls" } },
      ctx,
    );
    expect(posts().some((p) => p.includes("┌ working"))).toBe(false);
    // an edit shows up (fresh working frame)
    await handlers.tool_call(
      { toolName: "edit", input: { path: "a.txt" } },
      ctx,
    );
    expect(
      posts().some((p) => p.includes("┌ working") && p.includes("edit a.txt")),
    ).toBe(true);
    // a side-effect bash shows in the existing frame; the header count is
    // the ESSENTIAL count (2: edit + bash), not the total 4 (review L2)
    await handlers.tool_call(
      { toolName: "bash", input: { command: "git push" } },
      ctx,
    );
    expect(
      patches().some(
        (p) => p.includes("┌ working · 2 calls") && p.includes("bash git push"),
      ),
    ).toBe(true);
  });

  test("level 1 done frame lists essentials only; all-read run deletes the block", async () => {
    verboseOverride.set("ch1", 1);
    const fin = (t: string) => ({
      role: "assistant",
      content: [{ type: "text", text: t }],
    });
    // run A: read + edit + bash push -> frame shows 2 calls, no read
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    await handlers.turn_start(null, ctx);
    await handlers.tool_call(
      { toolName: "read", input: { path: "a.txt" } },
      ctx,
    );
    await handlers.tool_call(
      { toolName: "edit", input: { path: "a.txt" } },
      ctx,
    );
    await handlers.tool_call(
      { toolName: "bash", input: { command: "git push" } },
      ctx,
    );
    await handlers.agent_end({ messages: [fin("done A")] }, ctx);
    const donePatch = patches().find((p) => p.includes("┌ done"));
    expect(donePatch).toBeDefined();
    expect(donePatch).toContain("┌ done · 2 calls · ");
    expect(donePatch).toContain("edit a.txt");
    expect(donePatch).toContain("bash git push");
    expect(donePatch).not.toContain("read a.txt");

    // run B: only non-essential calls -> no live block at level 1 and no
    // done frame (nothing was ever posted to close)
    fetchCalls.length = 0;
    await handleInbound(pi, inbound("again", "m2"), ctx);
    await handlers.turn_start(null, ctx);
    await handlers.tool_call(
      { toolName: "read", input: { path: "b.txt" } },
      ctx,
    );
    await handlers.tool_call(
      { toolName: "bash", input: { command: "ls" } },
      ctx,
    );
    // level 1: no live block was created at all
    expect(posts().some((p) => p.includes("┣"))).toBe(false);
    await handlers.agent_end({ messages: [fin("done B")] }, ctx);
    expect(patches().some((p) => p.includes("┌ done"))).toBe(false);
    expect(
      fetchCalls.some(
        (c) =>
          c.method === "POST" &&
          c.url.endsWith("/channels/ch1/messages") &&
          String(JSON.parse(c.body).content).includes("done B"),
      ),
    ).toBe(true); // final still posts
  });

  test("level 2 shows everything (incl. reads) in the done frame", async () => {
    verboseOverride.set("ch1", 2);
    const fin = (t: string) => ({
      role: "assistant",
      content: [{ type: "text", text: t }],
    });
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    await handlers.turn_start(null, ctx);
    await handlers.tool_call(
      { toolName: "read", input: { path: "a.txt" } },
      ctx,
    );
    await handlers.tool_call(
      { toolName: "edit", input: { path: "a.txt" } },
      ctx,
    );
    await handlers.agent_end({ messages: [fin("done")] }, ctx);
    const donePatch = patches().find((p) => p.includes("┌ done"));
    expect(donePatch).toContain("┌ done · 2 calls · ");
    expect(donePatch).toContain("read a.txt");
  });

  test("/verbose sets + persists; bare shows; legacy on/off map to 2/0", async () => {
    setRuntimeStateDir(path.join(tmp, ".tmp"));
    const dir = path.join(tmp, ".tmp");
    await handleInbound(pi, inbound("/verbose 1", "m1"), ctx);
    expect(posts().some((t) => t.includes("[ok] verbose: 1 (essential)"))).toBe(
      true,
    );
    let onDisk = JSON.parse(
      fs.readFileSync(path.join(dir, "channel-state.json"), "utf-8"),
    );
    expect(onDisk.channels.ch1.verbose).toBe(1);

    // bare /verbose shows the current level and changes nothing
    await handleInbound(pi, inbound("/verbose", "m2"), ctx);
    expect(posts().some((t) => t.includes("[ok] verbose: 1 (essential)"))).toBe(
      true,
    );
    onDisk = JSON.parse(
      fs.readFileSync(path.join(dir, "channel-state.json"), "utf-8"),
    );
    expect(onDisk.channels.ch1.verbose).toBe(1);

    // legacy on/off still accepted
    await handleInbound(pi, inbound("/verbose on", "m3"), ctx);
    expect(posts().some((t) => t.includes("[ok] verbose: 2 (all)"))).toBe(true);
    await handleInbound(pi, inbound("/verbose off", "m4"), ctx);
    expect(posts().some((t) => t.includes("[ok] verbose: 0 (text)"))).toBe(
      true,
    );
    onDisk = JSON.parse(
      fs.readFileSync(path.join(dir, "channel-state.json"), "utf-8"),
    );
    expect(onDisk.channels.ch1.verbose).toBe(0);

    // bad arg: usage error, no change
    await handleInbound(pi, inbound("/verbose 3", "m5"), ctx);
    expect(posts().some((t) => t.includes("[!] usage: /verbose 0|1|2"))).toBe(
      true,
    );
    onDisk = JSON.parse(
      fs.readFileSync(path.join(dir, "channel-state.json"), "utf-8"),
    );
    expect(onDisk.channels.ch1.verbose).toBe(0);
  });

  test("verbosity level survives a simulated restart (state file reload)", async () => {
    setRuntimeStateDir(path.join(tmp, ".tmp"));
    await handleInbound(pi, inbound("/verbose 1", "m1"), ctx);
    // simulated process restart: in-memory wiped, file reloaded
    resetRuntimeStateForTest();
    setRuntimeStateDir(path.join(tmp, ".tmp"));
    const ch = loadChannelConfig(ctx.cwd)[0]!;
    expect(verboseLevel(ch)).toBe(1);
    expect(isVerbose(ch)).toBe(true);
    // and it renders at level 1
    await handleInbound(pi, inbound("hello", "m2"), ctx);
    await handlers.turn_start(null, ctx);
    await handlers.tool_call(
      { toolName: "read", input: { path: "a.txt" } },
      ctx,
    );
    expect(posts().some((p) => p.includes("┌ working"))).toBe(false); // read hidden at 1
  });

  test("forwardToolCalls=true defaults to level 2; override wins", async () => {
    setup({ forwardToolCalls: true });
    const ch = loadChannelConfig(ctx.cwd)[0]!;
    expect(verboseLevel(ch)).toBe(2);
    verboseOverride.set("ch1", 1);
    expect(verboseLevel(ch)).toBe(1);
    verboseOverride.set("ch1", 0);
    expect(verboseLevel(ch)).toBe(0);
  });

  test("level 2->1 transition keeps the live block; 1->0 deletes it", async () => {
    verboseOverride.set("ch1", 2);
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    await handlers.turn_start(null, ctx);
    await handlers.tool_call(
      { toolName: "read", input: { path: "a.txt" } },
      ctx,
    );
    expect(posts().some((p) => p.includes("┌ working"))).toBe(true); // block at level 2

    // 2 -> 1: block stays (still verbose); reads stop rendering
    await handleInbound(pi, inbound("/verbose 1", "m2"), ctx);
    expect(
      fetchCalls.some(
        (c) => c.method === "DELETE" && c.url.includes("/messages/out1"),
      ),
    ).toBe(false);
    fetchCalls.length = 0;
    await handlers.tool_call(
      { toolName: "read", input: { path: "b.txt" } },
      ctx,
    );
    expect(patches().length).toBe(0); // no edit: non-essential at 1

    // 1 -> 0: live block deleted on the transition
    await handleInbound(pi, inbound("/verbose off", "m3"), ctx);
    expect(
      fetchCalls.some(
        (c) => c.method === "DELETE" && c.url.includes("/messages/out1"),
      ),
    ).toBe(true);
  });
});

describe("live intermediate text (SPEC B)", () => {
  let tmp = "";
  let pi: any;
  let ctx: any;
  let handlers: Record<string, (...a: any[]) => any> = {};
  let fetchCalls: { url: string; method: string; body?: any }[] = [];
  /** message content -> sequential id (out1, out2, ...) in post order. */
  let posted: { content: string; id: string }[] = [];
  let msgN = 0;
  const realFetch = globalThis.fetch;
  const OWNER = "1000000000000000001";

  const inbound = (body: string, id: string): ChannelMessage => ({
    channelId: "ch1",
    channelName: "Test",
    channelType: "discord",
    messageId: id,
    from: "u",
    fromId: OWNER,
    body,
    timestamp: new Date().toISOString(),
    attachments: [],
    isRoom: false,
  });
  const posts = () =>
    fetchCalls
      .filter(
        (c) => c.method === "POST" && c.url.endsWith("/channels/ch1/messages"),
      )
      .map((c) => String(JSON.parse(c.body).content));
  const patches = (id?: string) =>
    fetchCalls
      .filter(
        (c) =>
          c.method === "PATCH" &&
          (id
            ? c.url.includes(`/messages/${id}`)
            : c.url.includes("/messages/")),
      )
      .map((c) => String(JSON.parse(c.body).content));
  const deletes = (id: string) =>
    fetchCalls.filter(
      (c) => c.method === "DELETE" && c.url.includes(`/messages/${id}`),
    );
  const idOf = (content: string) =>
    posted.find((p) => p.content === content)?.id;
  /** assistant message with intermediate text + tool call (not a final). */
  const inter = (text: string) => ({
    role: "assistant",
    content: [
      { type: "text", text },
      { type: "toolCall", toolName: "bash", arguments: {} },
    ],
  });
  const fin = (t: string) => ({
    role: "assistant",
    content: [{ type: "text", text: t }],
  });
  const tc = (toolName: string, input: Record<string, unknown> = {}) =>
    handlers.tool_call({ toolName, input }, ctx);

  beforeEach(() => {
    jest.useFakeTimers();
    tmp = fs.mkdtempSync(path.join(os.tmpdir(), "jarate-livetext-"));
    fs.mkdirSync(path.join(tmp, ".pi"), { recursive: true });
    fs.writeFileSync(
      path.join(tmp, ".pi", "settings.json"),
      JSON.stringify({
        channels: [
          {
            id: "ch1",
            name: "Test",
            type: "discord",
            botToken: "tok1",
            ack: true,
            ownerUserId: OWNER,
            forwardToolCalls: true, // level 2
          },
        ],
      }),
    );
    handlers = {};
    fetchCalls = [];
    posted = [];
    msgN = 0;
    midTurnQueues.clear();
    pendingAttachments.clear();
    verboseOverride.clear();
    heldChannels.clear();
    setRuntimeStateDir(null);
    pi = {
      registerMessageRenderer: () => {},
      registerTool: () => {},
      on: (n: string, fn: any) => {
        handlers[n] = fn;
      },
      sendMessage: () => {},
    };
    extension(pi);
    ctx = {
      cwd: tmp,
      ui: { setStatus: () => {} },
      isIdle: () => true,
      hasPendingMessages: () => false,
      abort: () => {},
    };
    globalThis.fetch = (async (url: any, init?: any) => {
      fetchCalls.push({
        url: String(url),
        method: init?.method ?? "GET",
        body: init?.body,
      });
      let id = "out1";
      if (
        init?.method === "POST" &&
        String(url).endsWith("/channels/ch1/messages")
      ) {
        id = `out${++msgN}`;
        posted.push({
          content: String(JSON.parse(init.body).content),
          id,
        });
      }
      return {
        ok: true,
        status: 200,
        json: async () => ({ id }),
        text: async () => "",
      };
    }) as any;
  });

  afterEach(async () => {
    clearDiscordStatesForTest(); // no auto-react suppression leaks across tests
    midTurnQueues.clear();
    pendingAttachments.clear();
    clearAllInterrupts();
    setInterruptCtx(null);
    setRuntimeStateDir(null);
    await handlers.agent_end?.({ messages: [] }, ctx);
    jest.useRealTimers();
    globalThis.fetch = realFetch;
    fs.rmSync(tmp, { recursive: true, force: true });
  });

  test("post-on-first-tool: first tool call posts the live-text message below the working frame", async () => {
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    await handlers.turn_start(null, ctx);
    await handlers.message_end(
      { message: inter("let me check the file") },
      ctx,
    );
    // nothing live-text posted yet: the post happens on the first tool call
    expect(idOf("let me check the file")).toBeUndefined();
    await tc("read", { path: "a.txt" });
    const tId = idOf("let me check the file");
    expect(tId).toBeDefined(); // live-text message carries the latest text
    // posted AFTER the working frame -> below it in the channel
    const frameIdx = posted.findIndex((p) => p.content.includes("┌ working"));
    const tIdx = posted.findIndex((p) => p.content === "let me check the file");
    expect(tIdx).toBeGreaterThan(frameIdx);
    // the intermediate text was NOT early-sent as a separate message
    expect(posts().filter((p) => p === "let me check the file")).toHaveLength(
      1,
    );
    // still in flight: not deleted
    expect(deletes(tId!)).toHaveLength(0);
  });

  test("post-on-first-text-after-tool: no placeholder, posted once real text arrives, edited in place", async () => {
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    await handlers.turn_start(null, ctx);
    await tc("bash", { command: "ls" });
    // tool call with no text yet: no live-text message posted (only the
    // working frame from turn_start exists)
    expect(posted.some((p) => p.content === "now I will edit it")).toBe(false);
    // text arrives after the tool: posts the live message
    await handlers.message_end({ message: inter("now I will edit it") }, ctx);
    const tId = idOf("now I will edit it");
    expect(tId).toBeDefined();
    // later text: same message edited in place, no second post
    jest.advanceTimersByTime(LIVE_TEXT_THROTTLE_MS + 100);
    await handlers.message_end({ message: inter("second thought") }, ctx);
    expect(patches(tId)).toContain("second thought");
    expect(
      posted.filter((p) => p.content === "now I will edit it"),
    ).toHaveLength(1);
  });

  test("edit-with-intermediate-text: segments edit the SAME message in place", async () => {
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    await handlers.turn_start(null, ctx);
    await handlers.message_end({ message: inter("step one text") }, ctx);
    await tc("read", { path: "a.txt" }); // posts live text with "step one text"
    const tId = idOf("step one text");
    expect(tId).toBeDefined();

    jest.advanceTimersByTime(LIVE_TEXT_THROTTLE_MS + 100);
    await handlers.message_end({ message: inter("step two text") }, ctx);
    expect(patches(tId)).toContain("step two text");

    // a later tool call re-checks the latest text: unchanged -> no extra edit
    const editsBefore = patches(tId).length;
    await tc("bash", { command: "git push" });
    expect(patches(tId).length).toBe(editsBefore);

    // one message total for both segments
    expect(
      posts().filter((p) => p === "step one text" || p === "step two text"),
    ).toHaveLength(1);
  });

  test("truncate-long-text: tail kept with ellipsis (unit + integration)", async () => {
    // unit
    expect(truncateLiveText("short")).toBe("short");
    expect(truncateLiveText("x".repeat(900))).toBe("x".repeat(900));
    expect(truncateLiveText("y".repeat(901))).toBe(`…${"y".repeat(900)}`);
    expect(truncateLiveText("abc", 2)).toBe(`…bc`);
    // integration: a 2000-char intermediate segment posts truncated
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    await handlers.turn_start(null, ctx);
    await handlers.message_end({ message: inter("z".repeat(2000)) }, ctx);
    await tc("read", { path: "a.txt" });
    const truncated = `…${"z".repeat(900)}`;
    expect(posts()).toContain(truncated);
    expect(posted.find((p) => p.content === truncated)!.content.length).toBe(
      901,
    );
  });

  test("edit-throttle: edits closer than 1.5s are skipped; the next event after the window lands the latest text", async () => {
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    await handlers.turn_start(null, ctx);
    await handlers.message_end({ message: inter("text one") }, ctx);
    await tc("read", { path: "a.txt" }); // posts live text with "text one"
    const tId = idOf("text one");
    expect(tId).toBeDefined();

    // within the throttle window: skipped (message_end and tool_call)
    await handlers.message_end({ message: inter("text two") }, ctx);
    expect(patches(tId)).toHaveLength(0);
    await tc("bash", { command: "ls" });
    expect(patches(tId)).toHaveLength(0);

    // after the window: the LATEST text lands on the same message
    jest.advanceTimersByTime(LIVE_TEXT_THROTTLE_MS + 100);
    await tc("bash", { command: "git push" });
    expect(patches(tId)).toEqual(["text two"]);
    // and no second post
    expect(posts().filter((p) => p === "text two")).toHaveLength(0);
  });

  test("delete-on-final: final via message_end deletes the live-text message", async () => {
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    await handlers.turn_start(null, ctx);
    await handlers.message_end({ message: inter("working text") }, ctx);
    await tc("read", { path: "a.txt" });
    const tId = idOf("working text");
    expect(tId).toBeDefined();

    await handlers.message_end({ message: fin("all done") }, ctx);
    expect(deletes(tId!)).toHaveLength(1); // ephemeral message gone
    const finalPost = posted.find((p) => p.content === "all done");
    expect(finalPost).toBeDefined(); // the final still lands, as its own message
    expect(finalPost!.id).not.toBe(tId);
  });

  test("delete-on-final: a final collected at agent_end also deletes the message", async () => {
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    await handlers.turn_start(null, ctx);
    await handlers.message_end({ message: inter("working text") }, ctx);
    await tc("read", { path: "a.txt" });
    const tId = idOf("working text");
    // no message_end for the final: it is collected at agent_end
    await handlers.agent_end({ messages: [fin("all done")] }, ctx);
    expect(deletes(tId!)).toHaveLength(1);
    expect(posts()).toContain("all done");
  });

  test("delete-on-error: a failed run deletes the live-text message and still posts the error", async () => {
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    await handlers.turn_start(null, ctx);
    await handlers.message_end({ message: inter("working text") }, ctx);
    await tc("read", { path: "a.txt" });
    const tId = idOf("working text");
    const failure = {
      role: "assistant",
      content: [{ type: "text", text: "" }],
      stopReason: "error",
      errorMessage: "boom",
    };
    await handlers.agent_end({ messages: [failure] }, ctx);
    expect(deletes(tId!)).toHaveLength(1);
    expect(posts().some((p) => p === styleGuard("boom"))).toBe(true);
  });

  test("no-tools-no-status: zero tool calls -> no live-text message at all", async () => {
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    await handlers.turn_start(null, ctx);
    await handlers.message_end({ message: fin("hi there") }, ctx);
    await handlers.agent_end({ messages: [] }, ctx);
    // no placeholder, no intermediate post
    expect(posts()).not.toContain(LIVE_TEXT_PLACEHOLDER);
    // no edits of any kind (a live-text message would PATCH)
    expect(patches()).toHaveLength(0);
    // the only working-frame traffic: the 0-call placeholder, deleted at
    // run end
    const wf = posted.find((p) => p.content.includes("┌ working"));
    expect(wf).toBeDefined();
    expect(deletes(wf!.id)).toHaveLength(1);
    // the final landed directly
    expect(posts()).toContain("hi there");
  });

  test("level 0: live text posts on the first tool call, edits in place, deletes on the step-final (2026-10-19)", async () => {
    verboseOverride.set("ch1", 0);
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    await handlers.turn_start(null, ctx);
    await handlers.message_end({ message: inter("working text") }, ctx);
    // NOT early-sent as a standalone message: it waits in the live-text
    // slot for the post gate (the first tool call)
    expect(posts()).not.toContain("working text");
    await tc("read", { path: "a.txt" });
    // the tool call posts the ONE ephemeral live-text message
    const tId = idOf("working text");
    expect(tId).toBeDefined();
    // level 0: no tool frame, no placeholder
    expect(posts().some((p) => p.includes("┌ working"))).toBe(false);
    expect(posts()).not.toContain(LIVE_TEXT_PLACEHOLDER);
    // a second intermediate text edits the SAME message in place
    jest.advanceTimersByTime(LIVE_TEXT_THROTTLE_MS + 100);
    await handlers.message_end({ message: inter("second thought") }, ctx);
    expect(patches(tId!)).toContain("second thought");
    expect(posted.filter((p) => p.content === "working text")).toHaveLength(1);
    // the step-final deletes the ephemeral message and posts as its own
    await handlers.message_end({ message: fin("done") }, ctx);
    expect(deletes(tId!)).toHaveLength(1);
    expect(posts()).toContain("done");
  });

  test("verbose on->off mid-run deletes the live-text message", async () => {
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    await handlers.turn_start(null, ctx);
    await handlers.message_end({ message: inter("working text") }, ctx);
    await tc("read", { path: "a.txt" });
    const tId = idOf("working text");
    expect(tId).toBeDefined();

    await handleInbound(pi, inbound("/verbose off", "m2"), ctx);
    expect(deletes(tId!)).toHaveLength(1); // live-text goes with the block

    // next tool call at level 0: no re-arm, no traffic
    fetchCalls.length = 0;
    posted.length = 0;
    await tc("bash", { command: "ls" });
    expect(posts()).toHaveLength(0);
    expect(patches()).toHaveLength(0);
  });
});

describe("buildInteractionHandler (defer-first ack)", () => {
  const realFetch = globalThis.fetch;
  const ch: any = {
    id: "ich",
    name: "IntTest",
    type: "discord",
    botToken: "tok-i",
    channel: "888",
    ownerUserId: "owner1",
  };
  let pi: any;
  let ctx: any;
  let calls: { url: string; method: string; body?: any }[];
  let urlViolations: string[];

  const d = (name: string, extra: Record<string, any> = {}) => ({
    id: "i1",
    token: "tok123",
    application_id: "app1",
    channel_id: "888",
    // Live guild shape (capture 2026-10-08): the actor lives at
    // member.user; guild INTERACTION_CREATE payloads carry NO top-level
    // user. The top-level-only DM/older shape is kept by exactly one test
    // in this file (see the #206 block, "status (owner)").
    member: { user: { id: "owner1", username: "OwnerOne" } },
    data: { name, options: extra.options },
    ...extra,
  });

  beforeEach(() => {
    calls = [];
    urlViolations = [];
    pi = { setModel: async () => true, sendMessage: () => {} };
    ctx = {
      cwd: "/tmp",
      isIdle: () => true,
      hasPendingMessages: () => false,
      abort: () => {},
      compact: () => {},
      modelRegistry: { getAvailable: () => [] },
      getContextUsage: () => undefined,
      model: { id: "cur", name: "Cur" },
    };
    globalThis.fetch = (async (url: any, init?: any) => {
      // F2: pin the interaction URL contract — record every call that is
      // not one of the allowed (method, route) pairs; asserted clean at
      // test end (afterEach).
      const v = interactionUrlViolation(String(url), init?.method ?? "GET");
      if (v) urlViolations.push(v);
      calls.push({
        url: String(url),
        method: init?.method ?? "GET",
        body: init?.body,
      });
      return {
        ok: true,
        status: 200,
        json: async () => ({}),
        text: async () => "",
      };
    }) as any;
  });

  afterEach(() => {
    // F2: no interaction call may land outside the allowed routes.
    expect(urlViolations).toEqual([]);
    clearDiscordStatesForTest(); // no auto-react suppression leaks across tests
    globalThis.fetch = realFetch;
  });

  test("type-5 defer is the FIRST network call; result edits the deferred message", async () => {
    const h = buildInteractionHandler(pi, ctx, ch, "tok-i");
    await h(d("help"));
    expect(calls.length).toBe(2);
    expect(calls[0].url).toBe(
      "https://discord.com/api/v10/interactions/i1/tok123/callback",
    );
    expect(JSON.parse(calls[0].body).type).toBe(5);
    expect(calls[1].url).toBe(
      "https://discord.com/api/v10/webhooks/app1/tok123/messages/@original",
    );
    expect(calls[1].method).toBe("PATCH");
    expect(JSON.parse(calls[1].body).content).toContain("Commands");
  });

  test("a throwing command still produces the defer ack and an error edit", async () => {
    let abortCalled = false;
    ctx.isIdle = () => false; // a run is active, so /stop calls ctx.abort()
    ctx.abort = () => {
      abortCalled = true;
      throw new Error("boom");
    };
    const h = buildInteractionHandler(pi, ctx, ch, "tok-i");
    await h(d("stop")); // must not throw
    expect(abortCalled).toBe(true);
    expect(calls[0].url).toBe(
      "https://discord.com/api/v10/interactions/i1/tok123/callback",
    );
    expect(JSON.parse(calls[0].body).type).toBe(5);
    const edit = calls.find((c) =>
      c.url.endsWith("/webhooks/app1/tok123/messages/@original"),
    );
    expect(edit).toBeDefined();
    expect(JSON.parse(edit!.body).content).toContain("boom");
  });

  test("command path with a missing name fails readable, not TypeError", async () => {
    const h = buildInteractionHandler(pi, ctx, ch, "tok-i");
    await h({
      id: "i4",
      token: "t",
      application_id: "app1",
      channel_id: "888",
      member: { user: { id: "owner1", username: "OwnerOne" } },
      type: 2,
      data: {},
    }); // must not throw
    const edit = calls.find((c) =>
      c.url.endsWith("/webhooks/app1/t/messages/@original"),
    );
    expect(edit).toBeDefined();
    expect(JSON.parse(edit!.body).content).toContain("unknown command");
  });

  test("btw defers, sends to pi, and leaves the deferred message alone", async () => {
    let sent = false;
    pi.sendMessage = () => {
      sent = true;
    };
    const h = buildInteractionHandler(pi, ctx, ch, "tok-i");
    await h(d("btw", { options: [{ name: "question", value: "is 42 ok?" }] }));
    expect(sent).toBe(true);
    expect(JSON.parse(calls[0].body).type).toBe(5);
    expect(
      calls.find((c) => c.url.endsWith("/messages/@original")),
    ).toBeUndefined();
  });

  test("wrong channel: typed reply, no command run", async () => {
    const h = buildInteractionHandler(pi, ctx, ch, "tok-i");
    await h(d("help", { channel_id: "424242" }));
    expect(calls.length).toBe(1);
    expect(calls[0].url).toBe(
      "https://discord.com/api/v10/interactions/i1/tok123/callback",
    );
    const body = JSON.parse(calls[0].body);
    expect(body.type).toBe(4);
    expect(body.data.content).toBe("use me in #IntTest");
  });

  test("native /model routes through pi.setModel; /compact through ctx.compact", async () => {
    let set: any = null;
    pi.setModel = async (m: any) => {
      set = m;
      return true;
    };
    ctx.modelRegistry = {
      getAvailable: () => [
        { id: "qwen3.8-27b", name: "Qwen", provider: "vllm" },
        { id: "other-123", name: "Other", provider: "vllm" },
      ],
    };
    let compacted: any = null;
    ctx.compact = (o?: any) => {
      compacted = o;
    };
    const h = buildInteractionHandler(pi, ctx, ch, "tok-i");

    await h(d("model", { options: [{ name: "name", value: "qwen3.8-27b" }] }));
    expect(set?.id).toBe("qwen3.8-27b");
    const modelEdit = calls.at(-1);
    expect(JSON.parse(modelEdit!.body).content).toContain("vllm/qwen3.8-27b");

    await h(
      d("compact", {
        options: [{ name: "instructions", value: "focus on X" }],
      }),
    );
    expect(compacted?.customInstructions).toBe("focus on X");
    expect(typeof compacted?.onComplete).toBe("function");
    expect(typeof compacted?.onError).toBe("function");
  });

  test("/model with no arg lists available models", async () => {
    ctx.modelRegistry = {
      getAvailable: () => [
        { id: "m1", name: "M1", provider: "p" },
        { id: "m2", name: "M2", provider: "p" },
      ],
    };
    const h = buildInteractionHandler(pi, ctx, ch, "tok-i");
    await h(d("model"));
    const edit = calls.find((c) => c.url.endsWith("/messages/@original"));
    const content = JSON.parse(edit!.body).content;
    expect(content).toContain("p/m1");
    expect(content).toContain("p/m2");
  });

  test("owner-only command from a non-owner is refused on the interaction path (#169)", async () => {
    const h = buildInteractionHandler(pi, ctx, ch, "tok-i");
    // live guild shape: the non-owner actor is at member.user
    await h(
      d("status", {
        member: { user: { id: "not-owner", username: "NotOwner" } },
      }),
    );
    // defer first, then the refusal edits the deferred message
    expect(JSON.parse(calls[0].body).type).toBe(5);
    const edit = calls.find((c) => c.url.endsWith("/messages/@original"));
    expect(edit).toBeDefined();
    const content = JSON.parse(edit!.body).content;
    expect(content).toContain("[!] owner only");
    expect(content).not.toContain("ctx "); // no session state leaked
  });

  test("no owner configured: the interaction refusal names the misconfiguration (#169)", async () => {
    const chNoOwner = { ...ch, ownerUserId: undefined };
    const h = buildInteractionHandler(pi, ctx, chNoOwner, "tok-i");
    // live guild shape: actor at member.user (uid "u1", not the owner)
    await h(
      d("status", { member: { user: { id: "u1", username: "Someone" } } }),
    );
    const edit = calls.find((c) => c.url.endsWith("/messages/@original"));
    expect(JSON.parse(edit!.body).content).toContain("no owner configured");
  });

  test("raw command lines pass the same styleGuard sweep as text replies (#169)", async () => {
    // /usage last with no completed run returns a bare line (no fence, no tag
    // in the command) — the interaction edit carries exactly what the
    // sweep produces: v4 (operator 2026-10-19) tag lines are prose, so
    // it ships unfenced, same as the text path.
    const raw = "no completed run yet (run one first)";
    const saved = (lastRunUsage as { value: any }).value;
    (lastRunUsage as { value: any }).value = null;
    try {
      const h = buildInteractionHandler(pi, ctx, ch, "tok-i");
      await h(d("usage", { options: [{ name: "scope", value: "last" }] }));
      const edit = calls.find((c) => c.url.endsWith("/messages/@original"));
      const content = JSON.parse(edit!.body).content;
      expect(content).toBe(styleGuard(raw));
      expect(content).toBe(raw); // v4: tag lines ship unfenced
      expect(content.startsWith("```")).toBe(false);
    } finally {
      (lastRunUsage as { value: any }).value = saved;
    }
  });
});

// ─── Slash registry ↔ dispatch routing (2026-10-09) ─────────────────────────
// 2026-10-09 operator report: /usage, /context, /diff, /hold, /tasks,
// /new-worktree, /merge-worktree (+ /handover) had dispatch cases but no
// registered command, so the '/' menu never offered them. One routing test
// per newly registered command: the slash interaction must reach its
// runChannelCommand case WITH the option value (allowlist passthrough).
// Pattern: #206 vault-slash tests (real interaction payload, stubbed fetch,
// deferred-ack edits as the assertion surface).

describe("buildInteractionHandler: registered slash commands route to their dispatch case", () => {
  const realFetch = globalThis.fetch;
  const ch: any = {
    id: "ich-r",
    name: "IntRoute",
    type: "discord",
    botToken: "tok-r",
    channel: "777",
    ownerUserId: "owner1",
  };
  let pi: any;
  let ctx: any;
  let calls: { url: string; method: string; body?: any }[];

  const d = (name: string, extra: Record<string, any> = {}) => ({
    id: "ir1",
    token: "tokr123",
    application_id: "appr",
    channel_id: "777",
    user: { id: "owner1" },
    data: { name, options: extra.options ?? [] },
    ...extra,
  });

  function deferredTexts(): string[] {
    return calls
      .filter(
        (c) =>
          c.method === "PATCH" &&
          c.url.includes("/webhooks/appr/tokr123/messages/@original"),
      )
      .map((c) => String(JSON.parse(c.body as string).content ?? ""));
  }

  beforeEach(() => {
    calls = [];
    pi = { setModel: async () => true, sendMessage: () => {} };
    ctx = {
      cwd: "/tmp",
      isIdle: () => true,
      hasPendingMessages: () => false,
      abort: () => {},
      compact: () => {},
      modelRegistry: { getAvailable: () => [] },
      getContextUsage: () => undefined,
      model: { id: "cur", name: "Cur" },
    };
    globalThis.fetch = (async (url: any, init?: any) => {
      calls.push({
        url: String(url),
        method: init?.method ?? "GET",
        body: init?.body,
      });
      return {
        ok: true,
        status: 200,
        json: async () => ({}),
        text: async () => "",
      };
    }) as any;
  });

  afterEach(() => {
    clearDiscordStatesForTest();
    globalThis.fetch = realFetch;
  });

  test("/usage last: scope choice reaches renderUsage via the usage case", async () => {
    const saved = (lastRunUsage as { value: any }).value;
    (lastRunUsage as { value: any }).value = {
      stats: {
        turns: 3,
        input: 100,
        output: 50,
        cacheRead: 80,
        cacheWrite: 5,
      },
      at: new Date("2026-10-09T00:00:00Z"),
    };
    try {
      const h = buildInteractionHandler(pi, ctx, ch, "tok-r");
      await h(
        d("usage", {
          options: [{ type: 3, name: "scope", value: "last" }],
        }) as any,
      );
      expect(deferredTexts().at(-1)).toContain("usage · last run");
    } finally {
      (lastRunUsage as { value: any }).value = saved;
    }
  });

  test("/context: count option passes the allowlist into renderContext", async () => {
    const h = buildInteractionHandler(pi, ctx, ch, "tok-r");
    await h(
      d("context", {
        options: [{ type: 3, name: "count", value: "12x" }],
      }) as any,
    );
    expect(deferredTexts().at(-1)).toContain("[!] usage: /context [1-40]");
  });

  test("/diff: source option passes the allowlist into publishDiff", async () => {
    const h = buildInteractionHandler(pi, ctx, ch, "tok-r");
    await h(
      d("diff", {
        options: [{ type: 3, name: "source", value: "two words" }],
      }) as any,
    );
    // assert a substring of the usage line (only resolveDiffSource's null
    // path emits it); fence bodies ship verbatim - no 40-col wrap.
    expect(deferredTexts().at(-1)).toContain("usage: /diff [git-range");
  });

  test("/hold: mode option passes the allowlist into the hold case", async () => {
    const h = buildInteractionHandler(pi, ctx, ch, "tok-r");
    await h(
      d("hold", {
        options: [{ type: 3, name: "mode", value: "bogus" }],
      }) as any,
    );
    expect(deferredTexts().at(-1)).toContain("[!] usage: /hold on|off");
  });

  test("/tasks: action option passes the allowlist into the tasks case", async () => {
    const h = buildInteractionHandler(pi, ctx, ch, "tok-r");
    await h(
      d("tasks", {
        options: [{ type: 3, name: "action", value: "cancel" }],
      }) as any,
    );
    expect(deferredTexts().at(-1)).toContain("[!] usage: /tasks cancel <id>");
  });

  test("/new-worktree: ref option passes the allowlist into newWorktree", async () => {
    // Real scratch repo (worktree.test.ts pattern): in a plain tmp dir
    // newWorktree bails with "not a git repo" BEFORE the ref is read, so
    // the allowlist entry was never discriminated by this test.
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "ich-wt-"));
    const repo = path.join(tmp, "live");
    fs.mkdirSync(repo, { recursive: true });
    const git = (...args: string[]) =>
      execFileSync("git", args, {
        cwd: repo,
        encoding: "utf8",
        env: {
          ...process.env,
          GIT_AUTHOR_NAME: "t",
          GIT_AUTHOR_EMAIL: "t@t",
          GIT_COMMITTER_NAME: "t",
          GIT_COMMITTER_EMAIL: "t@t",
        },
      });
    git("init", "-b", "main");
    fs.writeFileSync(path.join(repo, "base.txt"), "base\n");
    git("add", "base.txt");
    git("commit", "-m", "base commit");
    const oldWtDir = process.env.PI_BG_WT_DIR;
    process.env.PI_BG_WT_DIR = path.join(tmp, "wt");
    ctx.cwd = repo;
    try {
      const h = buildInteractionHandler(pi, ctx, ch, "tok-r");
      // Existing ref: honored end-to-end. Dropping "ref" from the
      // allowlist makes it "from HEAD" -> this line fails.
      await h(
        d("new-worktree", {
          options: [{ type: 3, name: "ref", value: "main" }],
        }) as any,
      );
      const ok = unwarped(deferredTexts().at(-1) ?? "");
      expect(ok).toContain("[ok] worktree ");
      expect(ok).toContain("from main");
      // Ref-specific failure: a ref that does not exist in the repo makes
      // `git worktree add` fail - only reachable when the ref string
      // actually reached newWorktree through the allowlist.
      clearWorktreeState(repo);
      await h(
        d("new-worktree", {
          options: [{ type: 3, name: "ref", value: "nosuchref" }],
        }) as any,
      );
      const bad = unwarped(deferredTexts().at(-1) ?? "");
      expect(bad).toContain("[!] worktree add failed");
      expect(bad.replace(/ /g, "")).toContain("nosuchref");
    } finally {
      if (oldWtDir === undefined) delete process.env.PI_BG_WT_DIR;
      else process.env.PI_BG_WT_DIR = oldWtDir;
      fs.rmSync(tmp, { recursive: true, force: true });
    }
  });

  test("/merge-worktree: routes to the worktree case (no active state)", async () => {
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "ich-mw-"));
    ctx.cwd = tmp;
    try {
      const h = buildInteractionHandler(pi, ctx, ch, "tok-r");
      await h(
        d("merge-worktree", {
          options: [{ type: 3, name: "mode", value: "squash" }],
        }) as any,
      );
      expect(deferredTexts().at(-1)).toContain("[!] no active worktree");
    } finally {
      fs.rmSync(tmp, { recursive: true, force: true });
    }
  });

  test("/handover: instructions option reaches startCompact via the handover case", async () => {
    let compacted: any = null;
    ctx.compact = (o?: any) => {
      compacted = o;
    };
    const h = buildInteractionHandler(pi, ctx, ch, "tok-r");
    await h(
      d("handover", {
        options: [{ type: 3, name: "instructions", value: "focus on X" }],
      }) as any,
    );
    expect(compacted?.customInstructions).toBe("focus on X");
    expect(deferredTexts().at(-1)).toContain("compacting...");
  });
});

describe("compact: defer mid-run + always report", () => {
  let tmp = "";
  let pi: any;
  let ctx: any;
  let handlers: Record<string, (...a: any[]) => any> = {};
  let fetchCalls: { url: string; method: string; body?: any }[] = [];
  const realFetch = globalThis.fetch;

  const inbound = (body: string, id: string): ChannelMessage => ({
    channelId: "ch1",
    channelName: "Test",
    channelType: "discord",
    messageId: id,
    from: "u",
    fromId: "uid",
    body,
    timestamp: new Date().toISOString(),
    attachments: [],
    isRoom: false,
  });

  const tick = () => new Promise((r) => setTimeout(r, 0));

  // contents of the extension's posts to the Discord channel
  const channelPosts = () =>
    fetchCalls
      .filter(
        (c) => c.url.includes("/channels/ch1/messages") && c.method === "POST",
      )
      .map(
        (c) =>
          (typeof c.body === "string" ? JSON.parse(c.body) : c.body).content,
      );

  beforeEach(() => {
    tmp = fs.mkdtempSync(path.join(os.tmpdir(), "piscord-test-"));
    fs.mkdirSync(path.join(tmp, ".pi"), { recursive: true });
    fs.writeFileSync(
      path.join(tmp, ".pi", "settings.json"),
      JSON.stringify({
        channels: [
          {
            id: "ch1",
            name: "Test",
            type: "discord",
            botToken: "tok1",
            ownerUserId: "uid",
            ack: true,
          },
        ],
      }),
    );
    handlers = {};
    fetchCalls = [];
    pi = {
      registerMessageRenderer: () => {},
      on: (n: string, fn: any) => {
        handlers[n] = fn;
      },
      sendMessage: () => {},
    };
    extension(pi);
    ctx = {
      cwd: tmp,
      ui: { setStatus: () => {} },
      isIdle: () => true,
      hasPendingMessages: () => false,
      abort: () => {},
      compact: () => {},
      modelRegistry: { getAvailable: () => [] },
      getContextUsage: () => undefined,
      model: { id: "cur", name: "Cur" },
    };
    globalThis.fetch = (async (url: any, init?: any) => {
      fetchCalls.push({
        url: String(url),
        method: init?.method ?? "GET",
        body: init?.body,
      });
      return {
        ok: true,
        status: 200,
        json: async () => ({ id: "out1" }),
        text: async () => "",
      };
    }) as any;
  });

  afterEach(() => {
    clearDiscordStatesForTest(); // no auto-react suppression leaks across tests
    jest.useRealTimers();
    stopAllCompactTicks();
    clearAllCompacting();
    for (const id of [...midTurnQueues.keys()]) clearQueuedInbound(id);
    queuedAcks.clear();
    pendingInterrupts.clear();
    handlers.agent_end?.({ messages: [] }, ctx); // clears typing timer; flushes any pending compact
    stopAllCompactTicks();
    clearAllCompacting();
    globalThis.fetch = realFetch;
    fs.rmSync(tmp, { recursive: true, force: true });
  });

  test("idle /compact runs immediately and reports the token delta on completion", async () => {
    let opts: any = null;
    ctx.compact = (o?: any) => {
      opts = o;
    };
    await handleInbound(pi, inbound("/compact keep the jarate", "m1"), ctx);
    expect(opts?.customInstructions).toBe("keep the jarate");
    await tick();
    expect(channelPosts().some((t) => t.includes("[..] compacting..."))).toBe(
      true,
    );
    opts.onComplete({
      summary: "s",
      firstKeptEntryId: "e",
      tokensBefore: 219997,
      estimatedTokensAfter: 35000,
    });
    await tick();
    // The report REPLACES the ticking placeholder in place (PATCH), not a
    // fresh post — no double message when the compact lands. k/m form
    // (fmtTokensLC) so the line fits the 40-col budget even at 9-digit
    // token counts.
    const reportText = "compacted: 220k -> 35k";
    const edits = fetchCalls.filter(
      (c) => c.method === "PATCH" && c.url.includes("/messages/"),
    );
    // Settle ships the bare line — op status is prose, no fence (v4 §2.3).
    expect(
      edits.some(
        (c) =>
          (typeof c.body === "string" ? JSON.parse(c.body) : c.body).content ===
          reportText,
      ),
    ).toBe(true);
    expect(channelPosts().some((t) => t === reportText)).toBe(false);
  });

  test("idle /compact placeholder ticks in place every 5s while compaction runs", async () => {
    jest.useFakeTimers();
    let opts: any = null;
    ctx.compact = (o?: any) => {
      opts = o;
    };
    const edits = () =>
      fetchCalls
        .filter((c) => c.method === "PATCH" && c.url.includes("/messages/"))
        .map(
          (c) =>
            (typeof c.body === "string" ? JSON.parse(c.body) : c.body).content,
        );
    await handleInbound(pi, inbound("/compact", "m1"), ctx);
    // settle the fire-and-forget placeholder post (microtasks, no timers)
    await Promise.resolve();
    await Promise.resolve();
    await Promise.resolve();
    expect(channelPosts().some((t) => t.includes("[..] compacting..."))).toBe(
      true,
    );

    // No edit before the first 5s tick
    jest.advanceTimersByTime(4999);
    expect(edits().length).toBe(0);
    jest.advanceTimersByTime(1);
    expect(edits()).toEqual(["[..] compacting… 5s"]);
    // subsequent ticks keep updating the SAME message in place
    jest.advanceTimersByTime(5000);
    expect(edits()).toEqual(["[..] compacting… 5s", "[..] compacting… 10s"]);
    jest.advanceTimersByTime(5000);
    expect(edits()).toEqual([
      "[..] compacting… 5s",
      "[..] compacting… 10s",
      "[..] compacting… 15s",
    ]);

    // Settle: the report replaces the placeholder in place, tick stops.
    // Bare line, same form as the fresh-post fallback (v4 §2.3).
    opts.onComplete({ tokensBefore: 100, estimatedTokensAfter: 10 });
    await Promise.resolve();
    await Promise.resolve();
    await Promise.resolve();
    expect(edits().at(-1)).toBe("compacted: 100 -> 10");
    jest.advanceTimersByTime(60000);
    expect(edits().length).toBe(4); // no further ticks after settle
    expect(channelPosts().some((t) => t.startsWith("[ok]"))).toBe(false);
  });

  test("idle /compact onError replaces the ticking placeholder in place", async () => {
    let opts: any = null;
    ctx.compact = (o?: any) => {
      opts = o;
    };
    await handleInbound(pi, inbound("/compact", "m1"), ctx);
    await tick();
    expect(channelPosts().some((t) => t.includes("[..] compacting..."))).toBe(
      true,
    );
    opts.onError(new Error("model down"));
    await tick();
    const failText = "compact failed: model down";
    const edits = fetchCalls.filter(
      (c) => c.method === "PATCH" && c.url.includes("/messages/"),
    );
    expect(
      edits.some(
        (c) =>
          (typeof c.body === "string" ? JSON.parse(c.body) : c.body).content ===
          failText,
      ),
    ).toBe(true);
    expect(channelPosts().some((t) => t === failText)).toBe(false);
  });

  test("v4: compact op posts placeholder + ticks + settle BARE (no fence)", async () => {
    jest.useFakeTimers();
    let opts: any = null;
    ctx.compact = (o?: any) => {
      opts = o;
    };
    await handleInbound(pi, inbound("/compact", "m1"), ctx);
    // settle the fire-and-forget placeholder post (microtasks, no timers)
    await Promise.resolve();
    await Promise.resolve();
    await Promise.resolve();
    const edits = () =>
      fetchCalls
        .filter((c) => c.method === "PATCH" && c.url.includes("/messages/"))
        .map(
          (c) =>
            (typeof c.body === "string" ? JSON.parse(c.body) : c.body).content,
        );
    // the placeholder POST is the bare one-liner — status is prose (§2.3)
    expect(channelPosts()).toContain("[..] compacting...");
    // the 5s tick edits the SAME message in place, bare
    jest.advanceTimersByTime(5000);
    expect(edits()).toEqual(["[..] compacting… 5s"]);
    // the settle replaces it in place, bare — the fresh-post fallback form
    opts.onComplete({ tokensBefore: 220000, estimatedTokensAfter: 35000 });
    await Promise.resolve();
    await Promise.resolve();
    await Promise.resolve();
    expect(edits().at(-1)).toBe("compacted: 220k -> 35k");
    jest.advanceTimersByTime(60000);
    // nothing in the whole op window (posts + in-place edits) carries a fence
    for (const t of [...channelPosts(), ...edits()])
      expect(t).not.toContain("```");
  });

  test("v4: settle before the placeholder post lands -> fresh post is BARE, same text as the tick settle", async () => {
    // Hold the placeholder POST open so onComplete runs before the tick is
    // armed — the settle must fall back to a fresh post that carries the
    // SAME bare line the tick settle would have posted (the old race shipped
    // fenced via tick, bare via fallback).
    const baseFetch = globalThis.fetch as any;
    let plainPosts = 0;
    const release: { fn?: () => void } = {};
    globalThis.fetch = (async (url: any, init?: any) => {
      const u = String(url);
      if (init?.method === "POST" && u.endsWith("/channels/ch1/messages")) {
        plainPosts += 1;
        if (plainPosts === 1) await new Promise<void>((r) => (release.fn = r));
      }
      return baseFetch(url, init);
    }) as any;
    let opts: any = null;
    ctx.compact = (o?: any) => {
      opts = o;
    };
    await handleInbound(pi, inbound("/compact", "m1"), ctx);
    // POST still in flight -> tick not armed. Settle now.
    const settleText = "compacted: 220k -> 35k";
    opts.onComplete({ tokensBefore: 220000, estimatedTokensAfter: 35000 });
    await tick();
    // the fallback fresh post is bare and identical to the tick-settle form
    expect(channelPosts().filter((t) => t === settleText)).toEqual([
      settleText,
    ]);
    expect(settleText).not.toContain("```");
    // release the placeholder: it lands bare; the tick then arms onto an
    // already-closed window and renders null (no edit, no double post)
    release.fn?.();
    await tick();
    await tick();
    expect(channelPosts().filter((t) => t === "[..] compacting...")).toEqual([
      "[..] compacting...",
    ]);
    const editContents = fetchCalls
      .filter((c) => c.method === "PATCH")
      .map(
        (c) =>
          (typeof c.body === "string" ? JSON.parse(c.body) : c.body).content,
      );
    for (const t of editContents) expect(t).not.toContain("```");
    expect(channelPosts().filter((t) => t === settleText)).toHaveLength(1);
  });

  test("idle /compact with no instructions compacts without customInstructions", async () => {
    let opts: any = null;
    ctx.compact = (o?: any) => {
      opts = o;
    };
    await handleInbound(pi, inbound("/compact", "m1"), ctx);
    expect(opts).not.toBeNull();
    expect(opts.customInstructions).toBeUndefined();
  });

  test("idle /compact reports onError (the swallowed-error path)", async () => {
    let opts: any = null;
    ctx.compact = (o?: any) => {
      opts = o;
    };
    await handleInbound(pi, inbound("/compact", "m1"), ctx);
    opts.onError(new Error("Nothing to compact (session too small)"));
    await tick();
    expect(
      channelPosts().some(
        (t) =>
          t ===
          styleGuard("compact failed: Nothing to compact (session too small)"),
      ),
    ).toBe(true);
  });

  test("sync throw from ctx.compact is reported, not swallowed", async () => {
    ctx.compact = () => {
      throw new Error("boom-ctx");
    };
    await handleInbound(pi, inbound("/compact", "m1"), ctx);
    await tick();
    expect(
      channelPosts().some((t) => t.includes("compact failed: boom-ctx")),
    ).toBe(true);
    expect(channelPosts().some((t) => t.includes("[..] compacting..."))).toBe(
      false,
    );
  });

  test("mid-run /compact defers; agent_end flushes it with the stored instructions", async () => {
    let opts: any = null;
    ctx.compact = (o?: any) => {
      opts = o;
    };
    ctx.isIdle = () => false;
    // establish the active channel, then start a run
    await handleInbound(pi, inbound("hello", "m0"), ctx);
    await handlers.turn_start(null, ctx);
    // /compact mid-run
    await handleInbound(pi, inbound("/compact keep the jarate", "m1"), ctx);
    expect(opts).toBeNull(); // not started yet — the run would be aborted
    expect(
      channelPosts().some((t) =>
        t.includes("[queued] compact (run in progress)"),
      ),
    ).toBe(true);
    // run ends → flush (flushed compact posts its own ticking placeholder)
    await handlers.agent_end({ messages: [] }, ctx);
    expect(opts?.customInstructions).toBe("keep the jarate");
    await tick();
    expect(channelPosts().some((t) => t.includes("[..] compacting..."))).toBe(
      true,
    );
  });

  test("mid-run: a later /compact replaces the earlier pending one", async () => {
    let opts: any = null;
    ctx.compact = (o?: any) => {
      opts = o;
    };
    ctx.isIdle = () => false;
    await handleInbound(pi, inbound("hello", "m0"), ctx);
    await handlers.turn_start(null, ctx);
    await handleInbound(pi, inbound("/compact first", "m1"), ctx);
    await handleInbound(pi, inbound("/compact second", "m2"), ctx);
    expect(
      channelPosts().some((t) =>
        unwarped(t).includes(
          "[queued] compact (run in progress), replaces earlier",
        ),
      ),
    ).toBe(true);
    await handlers.agent_end({ messages: [] }, ctx);
    expect(opts?.customInstructions).toBe("second");
  });

  test("/compact while a compaction is in flight defers; session_compact flushes it", async () => {
    let opts: any = null;
    ctx.compact = (o?: any) => {
      opts = o;
    };
    ctx.isIdle = () => false; // isCompacting; agentBusy stays false
    await handleInbound(pi, inbound("/compact second", "m2"), ctx);
    expect(opts).toBeNull();
    expect(
      channelPosts().some((t) =>
        unwarped(t).includes("[queued] compact (compact already in progress)"),
      ),
    ).toBe(true);
    handlers.session_compact?.(
      {
        compactionEntry: {},
        fromExtension: true,
        reason: "manual",
        willRetry: false,
      },
      ctx,
    );
    await tick();
    expect(opts?.customInstructions).toBe("second");
  });

  test("/compact while a compaction is in flight defers; session_compact_failed also flushes", async () => {
    let opts: any = null;
    ctx.compact = (o?: any) => {
      opts = o;
    };
    ctx.isIdle = () => false;
    await handleInbound(pi, inbound("/compact second", "m2"), ctx);
    expect(opts).toBeNull();
    handlers.session_compact_failed?.(
      {
        reason: "manual",
        errorMessage: "model down",
        aborted: false,
        willRetry: false,
        fromExtension: false,
      },
      ctx,
    );
    await tick();
    expect(opts?.customInstructions).toBe("second");
  });
});

describe("compaction-queue guard", () => {
  let tmp = "";
  let pi: any;
  let ctx: any;
  let handlers: Record<string, (...a: any[]) => any> = {};
  let sent: { m: any; o: any }[] = [];
  let fetchCalls: { url: string; method: string; body?: any }[] = [];
  const realFetch = globalThis.fetch;

  const inbound = (
    body: string,
    id: string,
    channelId = "ch1",
    fromId = "owner1",
  ): ChannelMessage => ({
    channelId,
    channelName: channelId === "ch2" ? "Test2" : "Test",
    channelType: "discord",
    messageId: id,
    from: fromId,
    fromId,
    body,
    timestamp: new Date().toISOString(),
    attachments: [],
    isRoom: false,
  });

  const tick = () => new Promise((r) => setTimeout(r, 0));
  // The settle drain is macrotask-deferred, and the re-wake handleInbound
  // chain has its own awaits before pi.sendMessage — settle a few ticks.
  const settleTicks = async () => {
    await tick();
    await tick();
    await tick();
  };

  const channelPosts = (chId = "ch1") =>
    fetchCalls
      .filter(
        (c) =>
          (c.url.includes(`/channels/${chId}/messages`) ||
            // ch2 resolves its Discord channel id from settings
            (chId === "ch2" && c.url.includes("/channels/999/messages"))) &&
          c.method === "POST",
      )
      .map(
        (c) =>
          (typeof c.body === "string" ? JSON.parse(c.body) : c.body).content,
      );

  const piSends = () =>
    sent.filter((s) => s.m?.customType === "channel-inbound");

  beforeEach(() => {
    tmp = fs.mkdtempSync(path.join(os.tmpdir(), "piscord-test-"));
    fs.mkdirSync(path.join(tmp, ".pi"), { recursive: true });
    fs.writeFileSync(
      path.join(tmp, ".pi", "settings.json"),
      JSON.stringify({
        channels: [
          {
            id: "ch1",
            name: "Test",
            type: "discord",
            botToken: "tok1",
            channel: "ch1",
            ack: true,
            ownerUserId: "owner1",
          },
          {
            id: "ch2",
            name: "Test2",
            type: "discord",
            botToken: "tok2",
            channel: "999",
            ack: true,
            ownerUserId: "owner1",
          },
        ],
      }),
    );
    handlers = {};
    fetchCalls = [];
    sent = [];
    pi = {
      registerMessageRenderer: () => {},
      on: (n: string, fn: any) => {
        handlers[n] = fn;
      },
      sendMessage: (m: any, o: any) => {
        sent.push({ m, o });
      },
    };
    extension(pi);
    ctx = {
      cwd: tmp,
      ui: { setStatus: () => {} },
      isIdle: () => true,
      hasPendingMessages: () => false,
      abort: () => {},
      compact: () => {},
      modelRegistry: { getAvailable: () => [] },
      getContextUsage: () => undefined,
      model: { id: "cur", name: "Cur" },
    };
    globalThis.fetch = (async (url: any, init?: any) => {
      fetchCalls.push({
        url: String(url),
        method: init?.method ?? "GET",
        body: init?.body,
      });
      return {
        ok: true,
        status: 200,
        json: async () => ({ id: "out1" }),
        text: async () => "",
      };
    }) as any;
  });

  afterEach(async () => {
    clearDiscordStatesForTest(); // no auto-react suppression leaks across tests
    jest.useRealTimers();
    clearAllCompacting();
    for (const id of [...midTurnQueues.keys()]) clearQueuedInbound(id);
    queuedAcks.clear();
    pendingInterrupts.clear();
    handlers.agent_end?.({ messages: [] }, ctx); // flush any pending compact
    clearAllCompacting();
    globalThis.fetch = realFetch;
    fs.rmSync(tmp, { recursive: true, force: true });
    // A settleCompacting deferred drain (setTimeout 0) scheduled by the
    // last test's settle event can still be pending — fire it here, after
    // the queue is cleared, so it no-ops instead of draining the NEXT
    // test's queue (its ctx is stale; isIdle() is the mock default true).
    await tick();
  });

  test("flag lifecycle: set on /compact dispatch, cleared by session_compact and session_compact_failed", async () => {
    ctx.compact = () => {};
    await handleInbound(pi, inbound("/compact", "m1"), ctx);
    expect(isCompacting("ch1")).toBe(true);
    expect(isCompacting("ch2")).toBe(false);

    handlers.session_compact?.(
      {
        type: "session_compact",
        compactionEntry: {},
        fromExtension: false,
        reason: "manual",
        willRetry: false,
      },
      ctx,
    );
    expect(isCompacting("ch1")).toBe(false);

    // re-open, then a FAILED settle also clears
    await handleInbound(pi, inbound("/compact", "m2"), ctx);
    expect(isCompacting("ch1")).toBe(true);
    handlers.session_compact_failed?.(
      {
        type: "session_compact_failed",
        reason: "manual",
        errorMessage: "model down",
        aborted: false,
        willRetry: false,
        fromExtension: false,
      },
      ctx,
    );
    expect(isCompacting("ch1")).toBe(false);
  });

  test("fallback timer: clears the flag after 10 min with a console.warn", async () => {
    jest.useFakeTimers();
    const warns: string[] = [];
    const realWarn = console.warn;
    console.warn = (...a: any[]) => {
      warns.push(a.join(" "));
    };
    try {
      ctx.compact = () => {};
      await handleInbound(pi, inbound("/compact", "m1"), ctx); // dispatched idle
      expect(isCompacting("ch1")).toBe(true);
      jest.advanceTimersByTime(10 * 60 * 1000);
      expect(isCompacting("ch1")).toBe(false);
      expect(warns.some((w) => w.includes("still compacting"))).toBe(true);
    } finally {
      console.warn = realWarn;
      jest.useRealTimers();
    }
  });

  test("fallback timer drains a queued message behind the stuck window", async () => {
    jest.useFakeTimers();
    ctx.compact = () => {};
    await handleInbound(pi, inbound("/compact", "m1"), ctx); // dispatched idle
    // flag set: even with isIdle true the gate keeps the window active,
    // so a plain message queues (with the flag, isIdle stays moot)
    await handleInbound(pi, inbound("late msg", "m2"), ctx);
    expect(midTurnQueues.get("ch1")?.length).toBe(1);
    jest.advanceTimersByTime(10 * 60 * 1000); // fallback: clear + drain (idle)
    jest.useRealTimers(); // let the async re-wake run on real timers
    // the drain's handleInbound has its own async hops, so its
    // completion can land late under load; poll instead of a single tick
    for (let i = 0; i < 200; i++) {
      if (piSends().some((s) => s.m.details?.body === "late msg")) break;
      await tick();
    }
    expect(piSends().some((s) => s.m.details?.body === "late msg")).toBe(true);
    expect(isCompacting("ch1")).toBe(false);
  });

  test("plain message while compacting: queued with ack, interrupt NOT armed", async () => {
    verboseOverride.set("ch1", 1); // verbose 1: the [queued] ack posts
    ctx.compact = () => {};
    await handleInbound(pi, inbound("/compact", "m1"), ctx);
    ctx.isIdle = () => false; // compaction now in flight
    expect(isCompacting("ch1")).toBe(true);

    await handleInbound(pi, inbound("hello while compacting", "m2"), ctx);
    await tick();
    expect(midTurnQueues.get("ch1")?.length).toBe(1);
    expect(pendingInterrupts.has("ch1")).toBe(false); // no interrupt armed
    expect(channelPosts().some((t) => t.includes("[queued] 1 in line"))).toBe(
      true,
    );
    expect(piSends().length).toBe(0); // not sent to pi yet
  });

  test("queued message delivered on the SUCCESS settle without further inbound (pi emits session_compact BEFORE clearing its compaction state, so isIdle() is still false at event time)", async () => {
    ctx.compact = () => {};
    await handleInbound(pi, inbound("/compact", "m1"), ctx);
    ctx.isIdle = () => false; // compaction in flight
    await handleInbound(pi, inbound("queued one", "m2"), ctx);
    await handleInbound(pi, inbound("queued two", "m3"), ctx);
    expect(piSends().length).toBe(0);

    // pi real ordering (agent-session.js): await emit(session_compact) with
    // _compactionAbortController still set -> isIdle() false DURING the
    // handler; _clearManualCompactionState() runs only after the emit
    // returns. The settle drain is macrotask-deferred, so it must survive
    // the false-at-event-time isIdle.
    handlers.session_compact?.(
      {
        compactionEntry: {},
        reason: "manual",
        willRetry: false,
        fromExtension: false,
      },
      ctx,
    );
    ctx.isIdle = () => true; // _clearManualCompactionState() ran
    await settleTicks();
    // No further inbound: the queued message is re-woken by the settle.
    const first = piSends().find((s) => s.m.details?.body === "queued one");
    expect(first).toBeDefined();
    expect(first?.o?.triggerTurn).toBe(true);
    // one re-wake per settle; the run's agent_end drains the rest
    expect(midTurnQueues.get("ch1")?.length).toBe(1);
  });

  test("queued messages also drain after a failed compaction", async () => {
    ctx.compact = () => {};
    await handleInbound(pi, inbound("/compact", "m1"), ctx);
    ctx.isIdle = () => false;
    await handleInbound(pi, inbound("queued one", "m2"), ctx);
    // pi real ordering (failure path): _clearManualCompactionState() runs
    // BEFORE the emit, so isIdle() is already true at event time.
    ctx.isIdle = () => true;
    handlers.session_compact_failed?.(
      {
        reason: "manual",
        errorMessage: "model down",
        aborted: false,
        willRetry: false,
        fromExtension: false,
      },
      ctx,
    );
    await settleTicks();
    expect(piSends().some((s) => s.m.details?.body === "queued one")).toBe(
      true,
    );
  });

  test("/status works while compacting (read-only, shows compacting)", async () => {
    ctx.compact = () => {};
    await handleInbound(pi, inbound("/compact", "m1"), ctx);
    ctx.isIdle = () => false;
    await handleInbound(pi, inbound("/status", "m2"), ctx);
    await tick();
    const st = channelPosts().find((t) => t.includes("[status]"));
    expect(st).toBeDefined();
    expect(st).toContain("compacting");
    expect(midTurnQueues.has("ch1")).toBe(false); // consumed, not queued
  });

  test("/stop while compacting: owner clears the window, aborts, drops the queue", async () => {
    let aborted = 0;
    ctx.compact = () => {};
    ctx.abort = () => {
      aborted++;
    };
    await handleInbound(pi, inbound("/compact", "m1"), ctx);
    ctx.isIdle = () => false;
    await handleInbound(pi, inbound("wait for me", "m2"), ctx);
    expect(midTurnQueues.get("ch1")?.length).toBe(1);

    await handleInbound(pi, inbound("/stop", "m3"), ctx);
    await tick();
    expect(isCompacting("ch1")).toBe(false);
    expect(aborted).toBe(1);
    expect(midTurnQueues.has("ch1")).toBe(false); // /stop drained the queue
    expect(channelPosts().some((t) => t.includes("[-] stopped"))).toBe(true);
  });

  test("/stop while compacting is owner-only: non-owner gets an immediate reply, nothing queued, window stays", async () => {
    ctx.compact = () => {};
    await handleInbound(pi, inbound("/compact", "m1"), ctx);
    ctx.isIdle = () => false;
    await handleInbound(pi, inbound("/stop", "m2", "ch1", "other"), ctx);
    await tick();
    expect(isCompacting("ch1")).toBe(true); // window untouched
    expect(channelPosts().some((t) => t.includes("[!] owner only"))).toBe(true);
    // Not queued: a queued /stop would re-run ungated after the window
    // closes and drop the channel's re-wake queue + abort the next run.
    expect(midTurnQueues.has("ch1")).toBe(false);
    expect(piSends().length).toBe(0);
    expect(pendingInterrupts.has("ch1")).toBe(false);
  });

  test("/compact while compacting: 'already compacting', single dispatch", async () => {
    let compacts = 0;
    ctx.compact = () => {
      compacts++;
    };
    await handleInbound(pi, inbound("/compact", "m1"), ctx);
    ctx.isIdle = () => false;
    await handleInbound(pi, inbound("/compact again", "m2"), ctx);
    await tick();
    expect(compacts).toBe(1);
    expect(channelPosts().some((t) => t.includes("already compacting"))).toBe(
      true,
    );
    expect(isCompacting("ch1")).toBe(true); // window unchanged
  });

  test("other commands while compacting: queued, but /reset refuses", async () => {
    ctx.compact = () => {};
    await handleInbound(pi, inbound("/compact", "m1"), ctx);
    ctx.isIdle = () => false;
    // /reset would open a second op window on the re-wake — refuse now
    // (F5: names the ACTIVE op — compaction, not a restart)
    await handleInbound(pi, inbound("/reset", "m2"), ctx);
    await tick();
    expect(channelPosts().some((t) => t.includes("already compacting"))).toBe(
      true,
    );
    // a queued-eligible command (/undo) still waits like a plain message
    await handleInbound(pi, inbound("/undo", "m3"), ctx);
    await tick();
    expect(midTurnQueues.get("ch1")?.[0]?.msg.body).toBe("/undo");
    expect(pendingInterrupts.has("ch1")).toBe(false);
  });

  test("channel isolation: ch2 unaffected while ch1 is compacting", async () => {
    jest.useFakeTimers();
    ctx.compact = () => {};
    await handleInbound(pi, inbound("/compact", "m1"), ctx); // ch1
    ctx.isIdle = () => false;
    expect(isCompacting("ch1")).toBe(true);
    expect(isCompacting("ch2")).toBe(false);

    // ch1: queued, interrupt NOT armed
    await handleInbound(pi, inbound("ch1 msg", "m2"), ctx);
    expect(midTurnQueues.get("ch1")?.length).toBe(1);
    expect(pendingInterrupts.has("ch1")).toBe(false);

    // ch2: queued too (isIdle false) and interrupt NOT armed — compaction
    // is session-wide, a ch2 interrupt (ctx.abort()) would kill ch1's
    // compaction, so arming is suppressed while ANY window is open.
    await handleInbound(pi, inbound("ch2 msg", "m3", "ch2"), ctx);
    expect(midTurnQueues.get("ch2")?.length).toBe(1);
    expect(pendingInterrupts.has("ch2")).toBe(false);

    // ch2 /compact is allowed (its own window is closed): it defers behind
    // the session-wide in-flight compaction
    await handleInbound(pi, inbound("/compact", "m4", "ch2"), ctx);
    expect(
      channelPosts("ch2").some((t) =>
        unwarped(t).includes("[queued] compact (compact already in progress)"),
      ),
    ).toBe(true);
    jest.useRealTimers();
  });
});

describe("buildRepliedMessageBlock", () => {
  test("renders author attribute + escaped text (T1)", () => {
    const out = buildRepliedMessageBlock({
      author: 'al "ice"',
      text: "a < b & c",
    });
    expect(out).toBe(
      "This message was a reply to message\n\n<replied-message author=\"al 'ice'\">\na &lt; b &amp; c\n</replied-message>",
    );
  });

  test("empty/absent → empty string (T1)", () => {
    expect(buildRepliedMessageBlock()).toBe("");
    expect(buildRepliedMessageBlock(undefined)).toBe("");
    expect(buildRepliedMessageBlock({ author: "x", text: "" })).toBe("");
  });

  test("missing author omits the attribute (T1)", () => {
    expect(buildRepliedMessageBlock({ author: "", text: "t" })).toBe(
      "This message was a reply to message\n\n<replied-message>\nt\n</replied-message>",
    );
  });
});

// ─── Todo board: /todos command, context injection, tool, worker intake ──
// Same harness shape as the "extension handlers" block, plus a HOME
// override so ~/.pi/agent/todos stays out of the real home.

describe("todo board (integration)", () => {
  let tmp = "";
  let realHome = "";
  let pi: any;
  let ctx: any;
  let handlers: Record<string, (...a: any[]) => any> = {};
  let sent: { m: any; o?: any }[] = [];
  let tools: Record<string, any> = {};
  let fetchCalls: { url: string; method: string; body?: any }[] = [];
  let fetchImpl: ((url: any, init?: any) => Promise<any>) | null = null;
  const realFetch = globalThis.fetch;

  const inbound = (body: string, id: string): ChannelMessage => ({
    channelId: "ch1",
    channelName: "Test",
    channelType: "discord",
    messageId: id,
    from: "u",
    fromId: "uid",
    body,
    timestamp: new Date().toISOString(),
    attachments: [],
    isRoom: false,
  });

  const ok = { id: "out1" };
  const replyContent = (): string => {
    const posts = fetchCalls.filter(
      (c) => c.method === "POST" && c.url.endsWith("/channels/ch1/messages"),
    );
    return JSON.parse(posts.at(-1)!.body).content;
  };

  beforeEach(() => {
    tmp = fs.mkdtempSync(path.join(os.tmpdir(), "piscord-todo-"));
    realHome = process.env.HOME!;
    process.env.HOME = tmp; // isolate ~/.pi/agent/todos from the real home
    fs.mkdirSync(path.join(tmp, ".pi"), { recursive: true });
    fs.writeFileSync(
      path.join(tmp, ".pi", "settings.json"),
      JSON.stringify({
        channels: [
          {
            id: "ch1",
            name: "Test",
            type: "discord",
            botToken: "tok1",
            ownerUserId: "uid",
            ack: true,
          },
        ],
      }),
    );
    handlers = {};
    sent = [];
    tools = {};
    fetchCalls = [];
    fetchImpl = null;
    pi = {
      registerMessageRenderer: () => {},
      registerTool: (t: any) => {
        tools[t.name] = t;
      },
      on: (n: string, fn: any) => {
        handlers[n] = fn;
      },
      sendMessage: (m: any, o?: any) => {
        sent.push({ m, o });
      },
    };
    extension(pi);
    // The factory registers LLM tools in session_start, which this
    // harness does not run — register the todo tool directly.
    registerTodoTool(pi, loadChannelConfig(tmp));
    ctx = {
      cwd: tmp,
      ui: { setStatus: () => {} },
      isIdle: () => true,
      hasPendingMessages: () => false,
      abort: () => {},
    };
    globalThis.fetch = (async (url: any, init?: any) => {
      fetchCalls.push({
        url: String(url),
        method: init?.method ?? "GET",
        body: init?.body,
      });
      if (fetchImpl) return fetchImpl(url, init);
      return {
        ok: true,
        status: 200,
        json: async () => ok,
        text: async () => "",
      };
    }) as any;
  });

  afterEach(() => {
    clearDiscordStatesForTest(); // no auto-react suppression leaks across tests
    globalThis.fetch = realFetch;
    process.env.HOME = realHome;
    fs.rmSync(tmp, { recursive: true, force: true });
  });

  test("/todos prints the channel board", async () => {
    saveBoard(
      {
        channelId: "ch1",
        todos: [
          { content: "fix bug", status: "in_progress" },
          { content: "tests", status: "pending" },
        ],
        updatedAt: "t",
      },
      tmp,
    );
    await handleInbound(pi, inbound("/todos", "m1"), ctx);
    const content = replyContent();
    expect(content).toBe(
      renderBoard([
        { content: "fix bug", status: "in_progress" },
        { content: "tests", status: "pending" },
      ]),
    );
    expect(content).toContain("**todos · 2 open**");
  });

  test("/todos with an empty board says 'no open todos'", async () => {
    await handleInbound(pi, inbound("/todos", "m1"), ctx);
    expect(replyContent()).toBe(fence("[todos] no open todos"));
  });

  test("/todos needs no owner", async () => {
    fs.writeFileSync(
      path.join(tmp, ".pi", "settings.json"),
      JSON.stringify({
        channels: [
          {
            id: "ch1",
            name: "Test",
            type: "discord",
            botToken: "tok1",
            ownerUserId: "owner1",
          },
        ],
      }),
    );
    saveBoard(
      {
        channelId: "ch1",
        todos: [{ content: "x", status: "pending" }],
        updatedAt: "t",
      },
      tmp,
    );
    await handleInbound(pi, inbound("/todos", "m1"), ctx); // fromId "uid" ≠ owner1
    expect(replyContent()).toContain("- x");
  });

  test("/todos all prints every channel's board", async () => {
    saveBoard(
      {
        channelId: "ch1",
        todos: [{ content: "a", status: "pending" }],
        updatedAt: "t",
      },
      tmp,
    );
    saveBoard(
      {
        channelId: "ch2",
        todos: [{ content: "b", status: "completed" }],
        updatedAt: "t",
      },
      tmp,
    );
    await handleInbound(pi, inbound("/todos all", "m1"), ctx);
    const content = replyContent();
    expect(content).toContain("**Test · 1 open**");
    expect(content).toContain("- a");
    expect(content).toContain("**ch2 · 0 open**");
    expect(content).toContain("- ~~b~~");
    // each board = bold header line, blank line, bullet list
    const blocks = content.split("\n\n");
    expect(blocks.length).toBe(4);
    expect(blocks[0].startsWith("**")).toBe(true);
    expect(blocks[2].startsWith("**")).toBe(true);
    expect(blocks[1].startsWith("- ")).toBe(true);
    expect(blocks[3].startsWith("- ")).toBe(true);
  });

  test("/todos all with no boards says 'no open todos'", async () => {
    await handleInbound(pi, inbound("/todos all", "m1"), ctx);
    expect(replyContent()).toBe(fence("[todos] no open todos"));
  });

  test("/todos all ships the full channel name - no 40-col clip (2026-10-18)", async () => {
    const longName = "a".repeat(90);
    fs.writeFileSync(
      path.join(tmp, ".pi", "settings.json"),
      JSON.stringify({
        channels: [
          {
            id: "ch1",
            name: longName,
            type: "discord",
            botToken: "tok1",
            ownerUserId: "owner1",
          },
        ],
      }),
    );
    saveBoard(
      {
        channelId: "ch1",
        todos: [{ content: "a", status: "pending" }],
        updatedAt: "t",
      },
      tmp,
    );
    await handleInbound(pi, inbound("/todos all", "m1"), ctx);
    const header = replyContent()
      .split("\n")
      .find((l) => l.startsWith("**"))!;
    // no width budget: the full channel name ships, however long
    expect(header).toBe(`**${longName} · 1 open**`);
    expect(header.length).toBeGreaterThan(40);
    expect(header).not.toContain("…");
  });

  test("context injection: non-empty board appended after channel-ctx", async () => {
    saveBoard(
      {
        channelId: "ch1",
        todos: [{ content: "fix bug", status: "in_progress" }],
        updatedAt: "t",
      },
      tmp,
    );
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    const content = sent.at(-1)!.m.content;
    expect(content).toContain("</channel-ctx>");
    expect(content).toContain("<todo-board>\n- **fix bug**\n</todo-board>");
    expect(content.indexOf("</channel-ctx>")).toBeLessThan(
      content.indexOf("<todo-board>"),
    );
  });

  test("context injection: no board block when the board is empty", async () => {
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    expect(sent.at(-1)!.m.content).not.toContain("<todo-board>");
  });

  test("todo tool: posts the board, edits in place, deletes on clear", async () => {
    const t = tools.todo;
    expect(t).toBeDefined();
    expect(t.description).toBe(TODO_TOOL_DESCRIPTION);

    // 1) first call: posts one board message, stores the id in state
    const r1 = await t.execute(
      "1",
      {
        todos: [
          { content: "a", status: "in_progress" },
          { content: "b", status: "pending" },
        ],
      },
      undefined,
      undefined,
      ctx,
    );
    expect(r1.content[0].text).toBe(
      renderBoard([
        { content: "a", status: "in_progress" },
        { content: "b", status: "pending" },
      ]),
    );
    let board = loadBoard("ch1", tmp);
    expect(board?.boardMessageId).toBe("out1");
    let posts = fetchCalls.filter(
      (c) => c.method === "POST" && c.url.endsWith("/channels/ch1/messages"),
    );
    expect(posts.length).toBe(1);
    expect(JSON.parse(posts[0].body).content).toContain("**todos · 2 open**");

    // 2) second call: edits the SAME message, no new post
    const r2 = await t.execute(
      "2",
      {
        todos: [
          { content: "a", status: "completed" },
          { content: "b", status: "pending" },
        ],
      },
      undefined,
      undefined,
      ctx,
    );
    expect(r2.content[0].text).toContain("- ~~a~~");
    posts = fetchCalls.filter(
      (c) => c.method === "POST" && c.url.endsWith("/channels/ch1/messages"),
    );
    expect(posts.length).toBe(1);
    const patch = fetchCalls.find(
      (c) =>
        c.method === "PATCH" && c.url.endsWith("/channels/ch1/messages/out1"),
    );
    expect(patch).toBeDefined();
    expect(JSON.parse(patch!.body).content).toContain("- ~~a~~");
    expect(JSON.parse(patch!.body).content).toContain("**todos · 1 open**");

    // 3) empty list: deletes the board message, clears the state
    const r3 = await t.execute("3", { todos: [] }, undefined, undefined, ctx);
    expect(r3.content[0].text).toBe("todo board cleared");
    const del = fetchCalls.find(
      (c) =>
        c.method === "DELETE" && c.url.endsWith("/channels/ch1/messages/out1"),
    );
    expect(del).toBeDefined();
    board = loadBoard("ch1", tmp);
    expect(board?.todos).toEqual([]);
    expect(board?.boardMessageId).toBeUndefined();
  });

  test("todo tool: a failed board edit does not fail the call", async () => {
    saveBoard(
      {
        channelId: "ch1",
        todos: [{ content: "a", status: "pending" }],
        updatedAt: "t",
        boardMessageId: "gone1",
      },
      tmp,
    );
    fetchImpl = (_url: any, init?: any) => {
      if (init?.method === "PATCH") {
        return Promise.resolve({
          ok: false,
          status: 404,
          json: async () => ({}),
          text: async () => "Not Found",
        });
      }
      return Promise.resolve({
        ok: true,
        status: 200,
        json: async () => ok,
        text: async () => "",
      });
    };
    const t = tools.todo;
    const r = await t.execute(
      "1",
      { todos: [{ content: "a", status: "completed" }] },
      undefined,
      undefined,
      ctx,
    );
    expect(r.content[0].text).toContain("- ~~a~~");
    // state still updated; id kept so the next sync retries the edit
    const board = loadBoard("ch1", tmp);
    expect(board?.todos[0].status).toBe("completed");
    expect(board?.boardMessageId).toBe("gone1");
  });

  test("todo tool: no channel available", async () => {
    await handlers.session_shutdown(); // clears lastActiveChannel
    const barePi: any = {
      registerTool: (t: any) => {
        tools.todo = t;
      },
    };
    registerTodoTool(barePi, []);
    const r = await tools.todo.execute(
      "1",
      { todos: [{ content: "a", status: "pending" }] },
      undefined,
      undefined,
      ctx,
    );
    expect(r.content[0].text).toBe("No Discord channel available");
  });

  test("worker intake: bg callback TODO lines merge into the board and re-render it", async () => {
    saveBoard(
      {
        channelId: "ch1",
        todos: [{ content: "alpha", status: "in_progress" }],
        updatedAt: "t",
        boardMessageId: "board1",
      },
      tmp,
    );
    // the 2026-10-21 de-prefix shape: content "" - the bridge-built body
    // is the serialized embed (the wake rides Author: pi-bg)
    const body =
      "<embed>\nAuthor: pi-bg ticket \u00b7 r1\nTitle: worker\nresult: done\nTODO: follow up on X\nTODO: verify the deploy\n</embed>";
    await handleInbound(pi, inbound(body, "m1"), ctx);

    let board = loadBoard("ch1", tmp);
    expect(board?.todos).toEqual([
      { content: "alpha", status: "in_progress" },
      { content: "follow up on X", status: "pending" },
      { content: "verify the deploy", status: "pending" },
    ]);
    // board message edited in place with the new items
    const patch = fetchCalls.find(
      (c) =>
        c.method === "PATCH" && c.url.endsWith("/channels/ch1/messages/board1"),
    );
    expect(patch).toBeDefined();
    expect(JSON.parse(patch!.body).content).toContain("- follow up on X");
    expect(JSON.parse(patch!.body).content).toContain("- **alpha**");
    // the callback still woke the agent (run forwarded to pi)
    expect(sent.length).toBeGreaterThan(0);

    // repeat callback: exact-content dedupe, no growth
    await handleInbound(pi, inbound(body, "m2"), ctx);
    board = loadBoard("ch1", tmp);
    expect(board?.todos.length).toBe(3);
  });

  test("worker intake: plain messages with TODO: lines are not merged", async () => {
    await handleInbound(
      pi,
      inbound("TODO: something I typed by hand", "m1"),
      ctx,
    );
    const board = loadBoard("ch1", tmp);
    expect(board).toBeNull();
  });
});

describe("sleep (integration)", () => {
  let tmp = "";
  let realHome = "";
  let pi: any;
  let ctx: any;
  let sent: { m: any; o?: any }[] = [];
  let tools: Record<string, any> = {};
  let fetchCalls: { url: string; method: string; body?: any }[] = [];
  const realFetch = globalThis.fetch;

  const NOW = Date.parse("2026-09-10T12:00:00Z");

  const inbound = (body: string, id: string): ChannelMessage => ({
    channelId: "ch1",
    channelName: "Test",
    channelType: "discord",
    messageId: id,
    from: "u",
    fromId: "uid",
    body,
    timestamp: new Date().toISOString(),
    attachments: [],
    isRoom: false,
  });

  const replyContent = (): string => {
    const posts = fetchCalls.filter(
      (c) => c.method === "POST" && c.url.endsWith("/channels/ch1/messages"),
    );
    return JSON.parse(posts.at(-1)!.body).content;
  };

  beforeEach(() => {
    tmp = fs.mkdtempSync(path.join(os.tmpdir(), "piscord-sleep-"));
    realHome = process.env.HOME!;
    process.env.HOME = tmp; // isolate ~/.pi/agent/sleep from the real home
    fs.mkdirSync(path.join(tmp, ".pi"), { recursive: true });
    fs.writeFileSync(
      path.join(tmp, ".pi", "settings.json"),
      JSON.stringify({
        channels: [
          {
            id: "ch1",
            name: "Test",
            type: "discord",
            botToken: "tok1",
            ownerUserId: "uid",
            ack: true,
          },
        ],
      }),
    );
    sent = [];
    tools = {};
    fetchCalls = [];
    pi = {
      registerMessageRenderer: () => {},
      registerTool: (t: any) => {
        tools[t.name] = t;
      },
      on: () => {},
      sendMessage: (m: any, o?: any) => {
        sent.push({ m, o });
      },
    };
    registerSleepTool(pi, loadChannelConfig(tmp));
    ctx = {
      cwd: tmp,
      ui: { setStatus: () => {} },
      isIdle: () => true,
      hasPendingMessages: () => false,
      abort: () => {},
    };
    globalThis.fetch = (async (url: any, init?: any) => {
      fetchCalls.push({
        url: String(url),
        method: init?.method ?? "GET",
        body: init?.body,
      });
      return {
        ok: true,
        status: 200,
        json: async () => ({ id: "out1" }),
        text: async () => "",
      };
    }) as any;
  });

  afterEach(() => {
    clearDiscordStatesForTest(); // no auto-react suppression leaks across tests
    globalThis.fetch = realFetch;
    process.env.HOME = realHome;
    fs.rmSync(tmp, { recursive: true, force: true });
  });

  test("/sleep with no wakes says 'no pending wakes'", async () => {
    await handleInbound(pi, inbound("/sleep", "m1"), ctx);
    expect(replyContent()).toBe(fence("[wake] no pending wakes"));
  });

  test("/sleep list shows pending wakes with id, channel, time, note", async () => {
    const w = scheduleWake({
      channelId: "ch1",
      channelName: "Test",
      wakeAt: Date.now() + 30 * 60000,
      note: "check CI",
      home: tmp,
    });
    await handleInbound(pi, inbound("/sleep list", "m1"), ctx);
    const content = replyContent();
    expect(content).toContain("**[wake] 1 pending wake (of 1 total)**");
    expect(content).toContain(w.id);
    expect(content).toContain("Test");
    expect(content).toContain(new Date(w.wakeAt).toISOString());
    expect(content).toContain("in 30m");
    expect(content).toContain("note: check CI");
  });

  test("/sleep cancel removes the wake from disk", async () => {
    const w = scheduleWake({
      channelId: "ch1",
      wakeAt: Date.now() + 30 * 60000,
      home: tmp,
    });
    await handleInbound(pi, inbound(`/sleep cancel ${w.id}`, "m1"), ctx);
    expect(replyContent()).toBe(fence(`[ok] cancelled wake ${w.id}`));
    expect(loadWakes(tmp)).toHaveLength(0);
  });

  test("/sleep cancel: unknown id, missing id, bogus subcommand", async () => {
    await handleInbound(pi, inbound("/sleep cancel nope", "m1"), ctx);
    expect(replyContent()).toBe(fence("[!] no wake with id nope"));
    await handleInbound(pi, inbound("/sleep cancel", "m2"), ctx);
    expect(replyContent()).toBe(fence("[!] usage: /sleep cancel <id>"));
    await handleInbound(pi, inbound("/sleep xyz", "m3"), ctx);
    expect(replyContent()).toBe(
      fence("[!] usage: /sleep [list | cancel <id>]"),
    );
  });

  test("due-on-startup delivery: injects a channel-inbound wake, completes it, no double delivery", () => {
    const w = scheduleWake({
      channelId: "ch1",
      channelName: "Test",
      wakeAt: NOW - 1000,
      note: "check the deploy",
      home: tmp,
      now: NOW - 2000,
    });
    const channels = loadChannelConfig(tmp);
    expect(deliverDueWakes(pi, channels, tmp, NOW)).toBe(1);
    const s = sent.at(-1)!;
    expect(s.o?.triggerTurn).toBe(true);
    expect(s.m.customType).toBe("channel-inbound");
    expect(s.m.content).toContain("Woke after sleeping until");
    expect(s.m.content).toContain("Note: check the deploy");
    expect(s.m.details.title).toBe("discord/Test");
    // completed on disk (removed) — a healthy process never re-delivers it
    expect(loadWakes(tmp).find((x) => x.id === w.id)).toBeUndefined();
    // immediate re-check: no double delivery
    expect(deliverDueWakes(pi, channels, tmp, NOW)).toBe(0);
    expect(sent).toHaveLength(1);
  });

  test("stale claim after PROCESS DEATH re-delivers once after CLAIM_TTL_MS", () => {
    const w = scheduleWake({
      channelId: "ch1",
      wakeAt: NOW - 1000,
      home: tmp,
      now: NOW - 2000,
    });
    // claim, then the process dies before completion (crash guard state)
    markClaimed(w.id, NOW, tmp);
    expect(loadWakes(tmp)[0]).toMatchObject({
      id: w.id,
      status: "claimed",
      claimedAt: NOW,
    });
    // a new session starts long after the claim (bridge was down through the TTL window)
    const channels = loadChannelConfig(tmp);
    expect(deliverDueWakes(pi, channels, tmp, NOW + CLAIM_TTL_MS + 1)).toBe(1);
    expect(sent).toHaveLength(1);
    // that redelivery is also completed — the loop must end
    expect(loadWakes(tmp)).toHaveLength(0);
    expect(deliverDueWakes(pi, channels, tmp, NOW + 2 * CLAIM_TTL_MS + 2)).toBe(
      0,
    );
    expect(sent).toHaveLength(1);
  });

  test("same-process late tick: a delivered wake is NOT re-delivered after the TTL (F1)", () => {
    scheduleWake({
      channelId: "ch1",
      wakeAt: NOW - 1000,
      home: tmp,
      now: NOW - 2000,
    });
    const channels = loadChannelConfig(tmp);
    expect(deliverDueWakes(pi, channels, tmp, NOW)).toBe(1);
    // 10 minutes later, same live process: the wake was completed, not claimed-stale
    expect(deliverDueWakes(pi, channels, tmp, NOW + CLAIM_TTL_MS + 1)).toBe(0);
    expect(sent).toHaveLength(1);
  });

  test("deliverDueWakes skips disabled channels (no claim, no injection)", () => {
    scheduleWake({
      channelId: "ch1",
      wakeAt: NOW - 1000,
      home: tmp,
      now: NOW - 2000,
    });
    const channels = loadChannelConfig(tmp).map((c) => ({
      ...c,
      enabled: false,
    }));
    expect(deliverDueWakes(pi, channels, tmp, NOW)).toBe(0);
    expect(sent).toHaveLength(0);
    expect(loadWakes(tmp)[0].status).toBe("pending");
  });

  test("/sleep list header counts only pending (claimed stays visible, not counted)", async () => {
    const p = scheduleWake({
      channelId: "ch1",
      channelName: "Test",
      wakeAt: Date.now() + 30 * 60000,
      note: "pending one",
      home: tmp,
    });
    const c = scheduleWake({
      channelId: "ch1",
      channelName: "Test",
      wakeAt: Date.now() + 60 * 60000,
      note: "claimed one",
      home: tmp,
    });
    markClaimed(c.id, Date.now(), tmp);
    await handleInbound(pi, inbound("/sleep list", "m1"), ctx);
    const content = replyContent();
    expect(content).toContain("**[wake] 1 pending wake (of 2 total)**");
    expect(content).toContain(p.id);
    expect(content).toContain(c.id);
  });

  test("inbound user message cancels PENDING wakes (kimaki parity); claimed ones survive", async () => {
    const p = scheduleWake({
      channelId: "ch1",
      wakeAt: Date.now() + 30 * 60000,
      home: tmp,
    });
    const c = scheduleWake({
      channelId: "ch1",
      wakeAt: Date.now() + 60 * 60000,
      home: tmp,
    });
    markClaimed(c.id, Date.now(), tmp);
    await handleInbound(pi, inbound("hey, are you awake?", "m1"), ctx);
    const ids = loadWakes(tmp).map((w) => w.id);
    expect(ids).not.toContain(p.id);
    expect(ids).toContain(c.id); // claimed = mid-delivery, not cancelled
  });

  test("/btw and commands do NOT cancel pending wakes", async () => {
    const a = scheduleWake({
      channelId: "ch1",
      wakeAt: Date.now() + 30 * 60000,
      home: tmp,
    });
    await handleInbound(pi, inbound("/btw what is 2+2", "m1"), ctx);
    expect(loadWakes(tmp).map((w) => w.id)).toContain(a.id);
    const b = scheduleWake({
      channelId: "ch1",
      wakeAt: Date.now() + 30 * 60000,
      home: tmp,
    });
    await handleInbound(pi, inbound("/help", "m2"), ctx);
    expect(loadWakes(tmp).map((w) => w.id)).toContain(b.id);
  });

  test("inbound message on channel A does not cancel wakes on channel B", async () => {
    const w = scheduleWake({
      channelId: "other-ch",
      wakeAt: Date.now() + 30 * 60000,
      home: tmp,
    });
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    expect(loadWakes(tmp).map((x) => x.id)).toEqual([w.id]);
  });

  test("sleep tool: minutes -> wake on disk + ack telling the model to end the reply", async () => {
    const r = await tools.sleep.execute(
      "1",
      { minutes: 30, note: "verify the build" },
      undefined,
      undefined,
      ctx,
    );
    expect(r.content[0].text).toContain("[ok] sleeping until");
    expect(r.content[0].text).toContain("End your reply now");
    const wakes = loadWakes(tmp);
    expect(wakes).toHaveLength(1);
    expect(wakes[0].channelId).toBe("ch1");
    expect(wakes[0].note).toBe("verify the build");
    expect(wakes[0].wakeAt).toBeGreaterThanOrEqual(Date.now() + 29 * 60000);
  });

  test("sleep tool: until ISO -> wake at that time", async () => {
    // Relative future date — a hardcoded ISO became a date bomb on
    // 2026-09-11 (past `until` is rejected, so the wake list stayed empty).
    const until = new Date(Date.now() + 30 * 60000).toISOString();
    await tools.sleep.execute("1", { until }, undefined, undefined, ctx);
    expect(loadWakes(tmp)[0].wakeAt).toBe(Date.parse(until));
  });

  test("sleep tool: bad params -> error, nothing scheduled", async () => {
    for (const params of [
      {},
      { minutes: 5, until: "2026-09-10T15:00:00Z" },
      { until: "yesterday" },
      { minutes: -1 },
      { until: "2036-01-01T00:00:00Z" },
    ]) {
      const r = await tools.sleep.execute(
        "1",
        params,
        undefined,
        undefined,
        ctx,
      );
      expect(r.content[0].text).toContain("[!]");
    }
    expect(loadWakes(tmp)).toHaveLength(0);
  });
});

describe("tasks (integration)", () => {
  let tmp = "";
  let realHome = "";
  let pi: any;
  let ctx: any;
  let sent: { m: any; o?: any }[] = [];
  let tools: Record<string, any> = {};
  let fetchCalls: { url: string; method: string; body?: any }[] = [];
  const realFetch = globalThis.fetch;

  const NOW = Date.parse("2026-09-10T12:00:00Z");

  const inbound = (body: string, id: string): ChannelMessage => ({
    channelId: "ch1",
    channelName: "Test",
    channelType: "discord",
    messageId: id,
    from: "u",
    fromId: "uid",
    body,
    timestamp: new Date().toISOString(),
    attachments: [],
    isRoom: false,
  });

  const replyContent = (): string => {
    const posts = fetchCalls.filter(
      (c) => c.method === "POST" && c.url.endsWith("/channels/ch1/messages"),
    );
    return JSON.parse(posts.at(-1)!.body).content;
  };

  beforeEach(() => {
    tmp = fs.mkdtempSync(path.join(os.tmpdir(), "piscord-tasks-"));
    realHome = process.env.HOME!;
    process.env.HOME = tmp; // isolate ~/.pi/agent/tasks from the real home
    fs.mkdirSync(path.join(tmp, ".pi"), { recursive: true });
    fs.writeFileSync(
      path.join(tmp, ".pi", "settings.json"),
      JSON.stringify({
        channels: [
          {
            id: "ch1",
            name: "Test",
            type: "discord",
            botToken: "tok1",
            ownerUserId: "uid",
            ack: true,
          },
        ],
      }),
    );
    sent = [];
    tools = {};
    fetchCalls = [];
    pi = {
      registerMessageRenderer: () => {},
      registerTool: (t: any) => {
        tools[t.name] = t;
      },
      on: () => {},
      sendMessage: (m: any, o?: any) => {
        sent.push({ m, o });
      },
    };
    registerTaskTool(pi, loadChannelConfig(tmp));
    ctx = {
      cwd: tmp,
      ui: { setStatus: () => {} },
      isIdle: () => true,
      hasPendingMessages: () => false,
      abort: () => {},
    };
    globalThis.fetch = (async (url: any, init?: any) => {
      fetchCalls.push({
        url: String(url),
        method: init?.method ?? "GET",
        body: init?.body,
      });
      return {
        ok: true,
        status: 200,
        json: async () => ({ id: "out1" }),
        text: async () => "",
      };
    }) as any;
  });

  afterEach(() => {
    clearDiscordStatesForTest(); // no auto-react suppression leaks across tests
    globalThis.fetch = realFetch;
    process.env.HOME = realHome;
    fs.rmSync(tmp, { recursive: true, force: true });
  });

  test("/tasks with no tasks says 'no scheduled tasks'", async () => {
    await handleInbound(pi, inbound("/tasks", "m1"), ctx);
    expect(replyContent()).toBe(fence("[tasks] no scheduled tasks"));
  });

  test("fence rule: machine replies fenced; summaries are markdown (2026-09-16 + 2026-10-18)", async () => {
    // /command replies ship in a code block (operator 2026-09-16) - still
    // true for machine one-liners, /help, and add/cancel results.
    const fencedCmds = [
      "/help",
      "/tasks add",
      "/tasks reschedule",
      "/tasks cancel",
      "/sleep cancel",
      "/model",
    ];
    for (let i = 0; i < fencedCmds.length; i++) {
      await handleInbound(pi, inbound(fencedCmds[i], `m${i}`), ctx);
      const c = replyContent();
      expect(c.startsWith("```"), `${fencedCmds[i]} -> ${c.slice(0, 50)}`).toBe(
        true,
      );
    }
    // Summary lists (Andryo 2026-10-18): normal markdown - no fence, no
    // box characters, no width budget. Empty-state one-liners stay fenced.
    const summaryCmds = ["/jobs", "/todos", "/tasks", "/sleep"];
    for (let i = 0; i < summaryCmds.length; i++) {
      await handleInbound(pi, inbound(summaryCmds[i], `s${i}`), ctx);
      const c = replyContent();
      if (c.startsWith("```")) {
        const body = c.replace(/^```\n/, "").replace(/\n```$/, "");
        expect(body).not.toContain("\n"); // empty/error one-liner
      } else {
        expect(c).not.toMatch(/[┌┐└┘├┤┣│─]/);
      }
    }
    // /context + /usage (PR #242 review F4): §2.3 summaries too. With a
    // session file present the success path ships unfenced markdown;
    // with none, the error path is a fenced one-liner.
    const sessions = path.join(tmp, ".pi", "agent", "sessions", "2026-09-10");
    fs.mkdirSync(sessions, { recursive: true });
    const sessFile = path.join(
      sessions,
      "2026-09-10T08-00-00-000Z_00000000-0000-0000-0000-000000000001.jsonl",
    );
    fs.writeFileSync(
      sessFile,
      [
        JSON.stringify({
          type: "session",
          version: 3,
          id: "sess",
          timestamp: "2026-09-10T08:00:00.000Z",
          cwd: "/cwd",
        }),
        JSON.stringify({
          type: "message",
          id: "cm1",
          parentId: "p-cm1",
          timestamp: "2026-09-10T08:00:01.000Z",
          message: {
            role: "user",
            content: [{ type: "text", text: "do the thing" }],
          },
        }),
        JSON.stringify({
          type: "message",
          id: "am1",
          parentId: "cm1",
          timestamp: "2026-09-10T08:00:02.000Z",
          message: {
            role: "assistant",
            content: [{ type: "text", text: "done" }],
          },
        }),
        "", // trailing blank: join gives the final newline
      ].join("\n"),
    );
    await handleInbound(pi, inbound("/context", "cx1"), ctx);
    let c = replyContent();
    expect(c.startsWith("```")).toBe(false); // success = unfenced markdown
    expect(c).not.toMatch(/[┌┐└┘├┤┣│─]/);
    await handleInbound(pi, inbound("/usage", "us1"), ctx);
    c = replyContent();
    expect(c.startsWith("```")).toBe(false);
    expect(c).not.toMatch(/[┌┐└┘├┤┣│─]/);
    // error path (no session file): fenced one-liner
    fs.rmSync(sessFile);
    await handleInbound(pi, inbound("/context", "cx2"), ctx);
    expect(replyContent()).toBe(fence("[!] no session file found"));
  });

  test("/tasks list shows tasks with id, channel, schedule, next fire, prompt", async () => {
    const one = scheduleTask({
      channelId: "ch1",
      channelName: "Test",
      prompt: "check the build",
      spec: {
        kind: "at",
        atMs: Date.now() + 2 * 3600000,
        nextFireAt: Date.now() + 2 * 3600000,
      },
      home: tmp,
    });
    const rec = scheduleTask({
      channelId: "ch1",
      prompt: "run the fleet check",
      spec: {
        kind: "cron",
        cron: "0 6 * * *",
        tz: "UTC",
        nextFireAt: Date.parse("2026-09-11T06:00:00Z"),
      },
      home: tmp,
      now: NOW + 1,
    });
    await handleInbound(pi, inbound("/tasks list", "m1"), ctx);
    const content = unwarped(replyContent());
    expect(content).toContain("**[tasks] 2 pending tasks (of 2 total)**");
    expect(content).toContain(one.id);
    expect(content).toContain("check the build");
    expect(content).toContain("in 2h");
    expect(content).toContain(rec.id);
    expect(content).toContain('cron "0 6 * * *" (UTC)');
    expect(content).toContain("2026-09-11T06:00:00.000Z");
  });

  test("/tasks cancel removes the task from disk", async () => {
    const t = scheduleTask({
      channelId: "ch1",
      prompt: "check the build",
      spec: {
        kind: "at",
        atMs: Date.now() + 30 * 60000,
        nextFireAt: Date.now() + 30 * 60000,
      },
      home: tmp,
    });
    await handleInbound(pi, inbound(`/tasks cancel ${t.id}`, "m1"), ctx);
    expect(replyContent()).toBe(fence(`[ok] cancelled task ${t.id}`));
    expect(loadTasks(tmp)).toHaveLength(0);
  });

  test("/tasks cancel: unknown id, missing id, bogus subcommand", async () => {
    await handleInbound(pi, inbound("/tasks cancel nope", "m1"), ctx);
    expect(replyContent()).toBe(fence("[!] no task with id nope"));
    await handleInbound(pi, inbound("/tasks cancel", "m2"), ctx);
    expect(replyContent()).toBe(fence("[!] usage: /tasks cancel <id>"));
    await handleInbound(pi, inbound("/tasks xyz", "m3"), ctx);
    expect(unwarped(replyContent())).toBe(
      fence("[!] usage: /tasks [list | add | reschedule | cancel]"),
    );
  });

  test("/tasks add: one-shot minutes -> scheduled in this channel", async () => {
    await handleInbound(
      pi,
      inbound('/tasks add "check the build" 30', "m1"),
      ctx,
    );
    expect(replyContent()).toContain("[ok] task");
    expect(unwarped(replyContent())).toContain("cancel with /tasks cancel");
    const tasks = loadTasks(tmp);
    expect(tasks).toHaveLength(1);
    expect(tasks[0]).toMatchObject({
      channelId: "ch1",
      channelName: "Test",
      prompt: "check the build",
      kind: "at",
    });
    expect(tasks[0].atMs).toBeGreaterThanOrEqual(Date.now() + 29 * 60000);
    expect(tasks[0].atMs).toBeLessThanOrEqual(Date.now() + 31 * 60000);
  });

  test("/tasks add: one-shot ISO time -> exact fire time", async () => {
    const iso = new Date(Date.now() + 3600000).toISOString();
    await handleInbound(
      pi,
      inbound(`/tasks add "iso check" ${iso}`, "m1"),
      ctx,
    );
    expect(replyContent()).toContain("[ok] task");
    const t = loadTasks(tmp)[0];
    expect(t).toMatchObject({
      channelId: "ch1",
      prompt: "iso check",
      kind: "at",
      atMs: Date.parse(iso),
    });
  });

  test("/tasks add: cron + tz -> recurring with computed first fire", async () => {
    await handleInbound(
      pi,
      inbound('/tasks add "run the fleet check" 0 6 * * * UTC', "m1"),
      ctx,
    );
    expect(unwarped(replyContent())).toContain('cron "0 6 * * *" (UTC)');
    const t = loadTasks(tmp)[0];
    expect(t).toMatchObject({
      channelId: "ch1",
      prompt: "run the fleet check",
      kind: "cron",
      cron: "0 6 * * *",
      tz: "UTC",
    });
    // next 06:00 UTC strictly in the future, within 24h (real clock)
    expect(t.nextFireAt).toBeGreaterThan(Date.now());
    expect(t.nextFireAt).toBeLessThanOrEqual(
      Date.now() + 24 * 3600000 + 120000,
    );
  });

  test("/tasks add: minutes suffix (30m) + quoted cron/ISO issue forms", async () => {
    // "30m" -> minutes (issue example form)
    await handleInbound(pi, inbound('/tasks add "fleet check" 30m', "m1"), ctx);
    expect(replyContent()).toContain("[ok] task");
    expect(loadTasks(tmp)[0]).toMatchObject({
      prompt: "fleet check",
      kind: "at",
    });
    // quoted 5-field cron (issue example form) -> system-tz recurring
    await handleInbound(
      pi,
      inbound('/tasks add "daily 06:00 fleet check" "0 6 * * *"', "m2"),
      ctx,
    );
    const cron = loadTasks(tmp)[1];
    expect(cron).toMatchObject({
      prompt: "daily 06:00 fleet check",
      kind: "cron",
      cron: "0 6 * * *",
    });
    expect(cron.tz).toBeUndefined();
    expect(unwarped(replyContent())).toContain('cron "0 6 * * *" (system tz)');
    // quoted ISO -> exact fire time
    const iso = new Date(Date.now() + 3600000).toISOString();
    await handleInbound(
      pi,
      inbound(`/tasks add "quoted iso" "${iso}"`, "m3"),
      ctx,
    );
    expect(loadTasks(tmp)[2]).toMatchObject({
      prompt: "quoted iso",
      kind: "at",
      atMs: Date.parse(iso),
    });
  });

  test("/tasks reschedule: swaps the spec, keeps id + prompt", async () => {
    const atMs = Date.now() + 30 * 60000;
    const t = scheduleTask({
      channelId: "ch1",
      channelName: "Test",
      prompt: "check the build",
      spec: { kind: "at", atMs, nextFireAt: atMs },
      home: tmp,
    });
    await handleInbound(
      pi,
      inbound(
        `/tasks reschedule ${t.id} 0 9 * * 1-5 Australia/Melbourne`,
        "m1",
      ),
      ctx,
    );
    expect(replyContent()).toContain("[ok] rescheduled");
    // old spec -> new spec, then the new next fire
    expect(unwarped(replyContent())).toContain(
      `at ${new Date(atMs).toISOString()} -> cron "0 9 * * 1-5" (Australia/Melbourne)`,
    );
    const after = loadTasks(tmp)[0];
    expect(after).toMatchObject({
      id: t.id,
      prompt: "check the build",
      channelId: "ch1",
      kind: "cron",
      cron: "0 9 * * 1-5",
      tz: "Australia/Melbourne",
      status: "pending",
    });
    expect(after.atMs).toBeUndefined();
    expect(after.nextFireAt).toBeGreaterThan(Date.now());
  });

  test("/tasks reschedule: recurring -> one-shot (reverse direction)", async () => {
    const t = scheduleTask({
      channelId: "ch1",
      prompt: "daily check",
      spec: {
        kind: "cron",
        cron: "0 6 * * *",
        nextFireAt: Date.now() + 3600000,
      },
      home: tmp,
    });
    await handleInbound(pi, inbound(`/tasks reschedule ${t.id} 45`, "m1"), ctx);
    expect(replyContent()).toContain("[ok] rescheduled");
    expect(unwarped(replyContent())).toContain(
      'cron "0 6 * * *" (system tz) -> at ',
    );
    const after = loadTasks(tmp)[0];
    expect(after).toMatchObject({
      id: t.id,
      prompt: "daily check",
      kind: "at",
      status: "pending",
    });
    expect(after.cron).toBeUndefined();
    expect(after.atMs).toBeGreaterThanOrEqual(Date.now() + 44 * 60000);
  });

  test("/tasks reschedule: unknown id or other channel -> one [!] line, nothing changes", async () => {
    const t = scheduleTask({
      channelId: "ch1",
      prompt: "check the build",
      spec: {
        kind: "at",
        atMs: Date.now() + 30 * 60000,
        nextFireAt: Date.now() + 30 * 60000,
      },
      home: tmp,
    });
    const other = scheduleTask({
      channelId: "ch2",
      prompt: "other channel task",
      spec: {
        kind: "at",
        atMs: Date.now() + 30 * 60000,
        nextFireAt: Date.now() + 30 * 60000,
      },
      home: tmp,
    });
    await handleInbound(pi, inbound("/tasks reschedule nope 30", "m1"), ctx);
    expect(replyContent()).toBe(fence("[!] no task with id nope"));
    // same id shape on another channel is not THIS session's task
    await handleInbound(
      pi,
      inbound(`/tasks reschedule ${other.id} 30`, "m2"),
      ctx,
    );
    expect(replyContent()).toBe(fence(`[!] no task with id ${other.id}`));
    // untouched
    expect(
      loadTasks(tmp).find((x) => x.id === t.id)!.nextFireAt,
    ).toBeGreaterThan(Date.now());
    expect(loadTasks(tmp)).toHaveLength(2);
  });

  test("/tasks add + reschedule: bad-arg paths -> one [!] line each, nothing scheduled", async () => {
    const t = scheduleTask({
      channelId: "ch1",
      prompt: "seed",
      spec: {
        kind: "at",
        atMs: Date.now() + 30 * 60000,
        nextFireAt: Date.now() + 30 * 60000,
      },
      home: tmp,
    });
    const addUsage = fence(
      '[!] usage: /tasks add "<prompt>" <minutes|ISO|cron [tz]>',
    );
    const resUsage = fence(
      "[!] usage: /tasks reschedule <id> <minutes|ISO|cron [tz]>",
    );
    // form errors -> usage line
    await handleInbound(pi, inbound("/tasks add", "m1"), ctx);
    expect(unwarped(replyContent())).toBe(addUsage);
    await handleInbound(
      pi,
      inbound("/tasks add check the build 30", "m2"), // unquoted prompt
      ctx,
    );
    expect(unwarped(replyContent())).toBe(addUsage);
    await handleInbound(pi, inbound('/tasks add "x"', "m3"), ctx); // no spec
    expect(unwarped(replyContent())).toBe(addUsage);
    await handleInbound(pi, inbound('/tasks add "x" 30 UTC', "m4"), ctx);
    expect(unwarped(replyContent())).toBe(addUsage); // 2 tokens: not any form
    await handleInbound(pi, inbound("/tasks reschedule", "m5"), ctx);
    expect(unwarped(replyContent())).toBe(resUsage);
    await handleInbound(pi, inbound(`/tasks reschedule ${t.id}`, "m6"), ctx);
    expect(unwarped(replyContent())).toBe(resUsage); // missing spec
    // content errors -> one [!] line (from parseTaskSpec / rescheduleTask)
    await handleInbound(pi, inbound('/tasks add "" 30', "m7"), ctx);
    expect(unwarped(replyContent())).toBe(fence("[!] prompt is required"));
    await handleInbound(pi, inbound('/tasks add "x" 0', "m8"), ctx);
    expect(unwarped(replyContent())).toBe(
      fence("[!] minutes must be greater than 0"),
    );
    await handleInbound(pi, inbound('/tasks add "x" 99999', "m9"), ctx);
    expect(unwarped(replyContent())).toBe(
      fence("[!] minutes too large (max 43200 = 30d)"),
    );
    await handleInbound(pi, inbound('/tasks add "x" yesterday', "m10"), ctx);
    expect(unwarped(replyContent())).toBe(
      fence(
        '[!] invalid at: "yesterday" (ISO time, e.g. 2026-09-10T15:00:00Z)',
      ),
    );
    await handleInbound(pi, inbound('/tasks add "x" 99 * * * *', "m11"), ctx);
    expect(unwarped(replyContent())).toBe(
      fence('[!] invalid cron "99 * * * *": minute out of range 0-59: 99'),
    );
    await handleInbound(
      pi,
      inbound('/tasks add "x" 0 6 * * * Not/AZone', "m12"),
      ctx,
    );
    expect(unwarped(replyContent())).toBe(
      fence(
        '[!] unknown timezone "Not/AZone" (IANA name, e.g. Australia/Melbourne)',
      ),
    );
    await handleInbound(
      pi,
      inbound(`/tasks reschedule ${t.id} 99 * * * *`, "m13"),
      ctx,
    );
    expect(unwarped(replyContent())).toBe(
      fence('[!] invalid cron "99 * * * *": minute out of range 0-59: 99'),
    );
    await handleInbound(
      pi,
      inbound(`/tasks reschedule ${t.id} not-a-time`, "m14"),
      ctx,
    );
    expect(unwarped(replyContent())).toBe(
      fence(
        '[!] invalid at: "not-a-time" (ISO time, e.g. 2026-09-10T15:00:00Z)',
      ),
    );
    // seed untouched, nothing scheduled on any path above
    expect(loadTasks(tmp).map((x) => x.id)).toEqual([t.id]);
  });

  test("/tasks list reflects add + reschedule", async () => {
    await handleInbound(
      pi,
      inbound('/tasks add "check the build" 120', "m1"),
      ctx,
    );
    const t = loadTasks(tmp)[0];
    const iso = new Date(Date.now() + 3600000).toISOString();
    await handleInbound(
      pi,
      inbound(`/tasks reschedule ${t.id} ${iso}`, "m2"),
      ctx,
    );
    await handleInbound(pi, inbound("/tasks list", "m3"), ctx);
    const content = replyContent();
    expect(content).toContain("**[tasks] 1 pending task (of 1 total)**");
    expect(content).toContain(t.id);
    expect(content).toContain("check the build");
    expect(content).toContain(iso);
    expect(content).toContain("in 1h");
  });

  test("due-on-startup delivery: injects a channel-inbound task, completes it, no double delivery", () => {
    scheduleTask({
      channelId: "ch1",
      channelName: "Test",
      prompt: "check the deploy",
      spec: {
        kind: "at",
        atMs: NOW - 1000,
        nextFireAt: NOW - 1000,
      },
      home: tmp,
      now: NOW - 2000,
    });
    const channels = loadChannelConfig(tmp);
    expect(deliverDueTasks(pi, channels, tmp, NOW)).toBe(1);
    const s = sent.at(-1)!;
    expect(s.o?.triggerTurn).toBe(true);
    expect(s.m.customType).toBe("channel-inbound");
    expect(s.m.content).toContain("[task] one-shot task due");
    expect(s.m.content).toContain("check the deploy");
    expect(s.m.details.title).toBe("discord/Test");
    // completed on disk (removed) — a healthy process never re-delivers it
    expect(loadTasks(tmp)).toHaveLength(0);
    expect(deliverDueTasks(pi, channels, tmp, NOW)).toBe(0);
    expect(sent).toHaveLength(1);
  });

  test("cron task delivery: survives, advances to the next slot, no immediate re-fire", () => {
    const t = scheduleTask({
      channelId: "ch1",
      channelName: "Test",
      prompt: "run the fleet check",
      spec: {
        kind: "cron",
        cron: "0 6 * * *",
        tz: "UTC",
        nextFireAt: NOW - 1000, // missed slot (bridge was down)
      },
      home: tmp,
      now: NOW - 2 * 86400000,
    });
    const channels = loadChannelConfig(tmp);
    expect(deliverDueTasks(pi, channels, tmp, NOW)).toBe(1);
    const s = sent.at(-1)!;
    expect(s.m.content).toContain(
      '[task] recurring task "0 6 * * *" (UTC) due',
    );
    expect(s.m.content).toContain("run the fleet check");
    // still scheduled — next slot strictly after NOW, not replayed
    const done = loadTasks(tmp).find((x) => x.id === t.id)!;
    expect(done.status).toBe("pending");
    expect(done.lastFiredAt).toBe(NOW - 1000);
    expect(done.nextFireAt).toBe(Date.parse("2026-09-11T06:00:00Z"));
    expect(deliverDueTasks(pi, channels, tmp, NOW)).toBe(0);
    expect(sent).toHaveLength(1);
  });

  test("stale claim after PROCESS DEATH re-delivers once after CLAIM_TTL_MS", () => {
    const t = scheduleTask({
      channelId: "ch1",
      prompt: "check the deploy",
      spec: {
        kind: "at",
        atMs: NOW - 1000,
        nextFireAt: NOW - 1000,
      },
      home: tmp,
      now: NOW - 2000,
    });
    // claim, then the process dies before completion (crash guard state)
    markTaskClaimed(t.id, NOW, tmp);
    expect(loadTasks(tmp)[0]).toMatchObject({
      id: t.id,
      status: "claimed",
      claimedAt: NOW,
    });
    const channels = loadChannelConfig(tmp);
    expect(deliverDueTasks(pi, channels, tmp, NOW + CLAIM_TTL_MS + 1)).toBe(1);
    expect(sent).toHaveLength(1);
    // that redelivery is also completed — the loop must end
    expect(loadTasks(tmp)).toHaveLength(0);
    expect(deliverDueTasks(pi, channels, tmp, NOW + 2 * CLAIM_TTL_MS + 2)).toBe(
      0,
    );
    expect(sent).toHaveLength(1);
  });

  test("deliverDueTasks skips disabled channels (no claim, no injection)", () => {
    scheduleTask({
      channelId: "ch1",
      prompt: "x",
      spec: {
        kind: "at",
        atMs: NOW - 1000,
        nextFireAt: NOW - 1000,
      },
      home: tmp,
      now: NOW - 2000,
    });
    const channels = loadChannelConfig(tmp).map((c) => ({
      ...c,
      enabled: false,
    }));
    expect(deliverDueTasks(pi, channels, tmp, NOW)).toBe(0);
    expect(sent).toHaveLength(0);
    expect(loadTasks(tmp)[0].status).toBe("pending");
  });

  test("task tool: minutes -> one-shot scheduled in the channel", async () => {
    await tools.task.execute(
      "1",
      { prompt: "check the build", minutes: 120 },
      undefined,
      undefined,
      ctx,
    );
    const tasks = loadTasks(tmp);
    expect(tasks).toHaveLength(1);
    expect(tasks[0]).toMatchObject({
      channelId: "ch1",
      channelName: "Test",
      prompt: "check the build",
      kind: "at",
    });
    expect(tasks[0].atMs).toBeGreaterThanOrEqual(Date.now() + 119 * 60000);
  });

  test("task tool: cron + tz -> recurring with computed first fire", async () => {
    const r = await tools.task.execute(
      "1",
      { prompt: "run the fleet check", cron: "0 6 * * *", tz: "UTC" },
      undefined,
      undefined,
      ctx,
    );
    expect(r.content[0].text).toContain("[ok] task");
    expect(r.content[0].text).toContain('cron "0 6 * * *" (UTC)');
    const t = loadTasks(tmp)[0];
    expect(t.kind).toBe("cron");
    // next 06:00 UTC is strictly in the future, within 24h (real clock)
    expect(t.nextFireAt).toBeGreaterThan(Date.now());
    expect(t.nextFireAt).toBeLessThanOrEqual(
      Date.now() + 24 * 3600000 + 120000,
    );
  });

  test("task tool: bad params -> error, nothing scheduled", async () => {
    for (const params of [
      {},
      { prompt: "x", minutes: 5, cron: "0 6 * * *" },
      { prompt: "x", cron: "99 * * * *" },
      { prompt: "x", at: "yesterday" },
      { prompt: "x", cron: "0 6 * * *", tz: "Not/AZone" },
    ]) {
      const r = await tools.task.execute(
        "1",
        params,
        undefined,
        undefined,
        ctx,
      );
      expect(r.content[0].text).toContain("[!]");
    }
    expect(loadTasks(tmp)).toHaveLength(0);
  });
});

// ─── Handoff mechanism B: size-gated restart (PR2) ────────────────────────

describe("handoff mechanism B (size-gated restart)", () => {
  let tmp = "";
  let oldHome = "";
  let storeDir = "";
  let sessDir = "";
  let liveFile = "";
  let pi: any;
  let ctx: any;
  let handlers: Record<string, (...a: any[]) => any> = {};
  let fetchCalls: { url: string; method: string; body?: any }[] = [];
  let shutdowns = 0;
  let seedMsgs: string[] = [];
  let restarter: string[] = [];
  const realFetch = globalThis.fetch;

  const CHANNELS = [
    {
      id: "ch1",
      name: "Test",
      type: "discord",
      botToken: "tok1",
      ownerUserId: "uid",
      default: true,
    },
  ];

  const inbound = (body: string, id: string): ChannelMessage => ({
    channelId: "ch1",
    channelName: "Test",
    channelType: "discord",
    messageId: id,
    from: "u",
    fromId: "uid",
    body,
    timestamp: new Date().toISOString(),
    attachments: [],
    isRoom: false,
  });

  const channelPosts = () =>
    fetchCalls
      .filter(
        (c) => c.url.includes("/channels/ch1/messages") && c.method === "POST",
      )
      .map(
        (c) =>
          (typeof c.body === "string" ? JSON.parse(c.body) : c.body).content,
      );

  const edits = () =>
    fetchCalls
      .filter((c) => c.method === "PATCH" && c.url.includes("/messages/"))
      .map(
        (c) =>
          (typeof c.body === "string" ? JSON.parse(c.body) : c.body).content,
      );

  // wait out a pending op shutdown (300ms arm + immediate isIdle) so the
  // session-file move happens while HOME still points at tmp
  const waitOpShutdown = () => new Promise((r) => setTimeout(r, 1100));

  const writeSettings = (handoff: Record<string, unknown>) => {
    fs.mkdirSync(path.join(tmp, ".pi"), { recursive: true });
    fs.writeFileSync(
      path.join(tmp, ".pi", "settings.json"),
      JSON.stringify({ channels: CHANNELS, handoff }),
    );
  };

  const markerPath = () => path.join(tmp, ".tmp", "op-marker.json");

  const writeMarker = (m: Record<string, unknown>) => {
    fs.mkdirSync(path.dirname(markerPath()), { recursive: true });
    fs.writeFileSync(markerPath(), JSON.stringify(m));
  };

  beforeEach(() => {
    tmp = fs.mkdtempSync(path.join(os.tmpdir(), "handoff-b-"));
    oldHome = process.env.HOME || "";
    process.env.HOME = path.join(tmp, "home");
    fs.mkdirSync(path.join(tmp, "home"), { recursive: true });
    storeDir = path.join(tmp, "home", "handovers");
    sessDir = path.join(tmp, "sessions");
    fs.mkdirSync(sessDir, { recursive: true });
    liveFile = path.join(sessDir, "live.jsonl");
    fs.writeFileSync(liveFile, "x".repeat(1024));
    shutdowns = 0;
    seedMsgs = [];
    restarter = [];
    fetchCalls = [];
    (handlers as any) = {};
    pi = {
      on: (n: string, fn: any) => {
        (handlers as any)[n] = fn;
      },
      sendMessage: () => {},
      sendUserMessage: (c: string) => {
        seedMsgs.push(c);
      },
      registerMessageRenderer: () => {},
      registerTool: () => {},
    };
    ctx = {
      cwd: tmp,
      ui: { setStatus: () => {} },
      isIdle: () => true,
      hasPendingMessages: () => false,
      abort: () => {},
      model: { id: "m", name: "M", provider: "p" },
      modelRegistry: {
        getAvailable: () => [],
      },
      sessionManager: {
        getSessionFile: () => liveFile,
        getSessionId: () => "sess-b",
      },
      getContextUsage: () => ({
        tokens: 1000,
        contextWindow: 262144,
        percent: 1,
      }),
      compact: () => {},
      shutdown: () => {
        shutdowns++;
      },
      on: () => {},
    };
    // op machinery needs a live cursor: seed the discord state for ch1
    seedChannelStateForTest("ch1", "ch1", path.join(tmp, ".tmp"));
    setChannelCursor("ch1", "1000");
    (globalThis as any).fetch = jest.fn(async (url: any, init?: any) => {
      fetchCalls.push({
        method: init?.method ?? "GET",
        url: String(url),
        body: init?.body,
      });
      return { ok: true, status: 200, json: async () => ({ id: "out1" }) };
    });
    setSystemdRestartHookForTest((u) => restarter.push(u));
    setProcessExitHookForTest(() => {});
    extension(pi as any);
  });
  afterEach(() => {
    setSystemdRestartHookForTest(null);
    setProcessExitHookForTest(null);
    (globalThis as any).fetch = realFetch;
    (handlers as any) = {};
    clearAllCompacting();
    stopAllOpTicks();
    setHandoffRestartArmed(false);
    process.env.HOME = oldHome;
    fs.rmSync(tmp, { recursive: true, force: true });
  });

  test("every compact restarts (issue #85 follow-up): small file, no cap check", async () => {
    // The file-size cap is gone: any handoff-qualifying compact restarts.
    // liveFile is 1KB from beforeEach — it still restarts.
    writeSettings({ enabled: true, storeDir });
    await handleInbound(pi, inbound("/compact", "m1"), ctx);
    handlers.session_compact?.({ type: "session_compact" }, ctx);
    await waitOpShutdown();
    expect(shutdowns).toBe(1);
    expect(restarter).toEqual(["pi.service"]);
    const marker = JSON.parse(fs.readFileSync(markerPath(), "utf8"));
    expect(marker.op).toBe("handoff");
    expect(marker.seeded).toBe(false);
    expect(fs.existsSync(liveFile)).toBe(false); // moved aside
  });

  test("restart op: placeholder, seeded:false marker, file move + stale archive, shutdown", async () => {
    // (was "over the cap" — the cap check is gone since c863c341: every
    // handoff-qualifying compact restarts; this test exercises the restart
    // chain, not a size gate.)
    writeSettings({ enabled: true, storeDir });
    fs.writeFileSync(liveFile, "x".repeat(1_572_864)); // 1.5 MB
    const stale = path.join(sessDir, "old.jsonl");
    fs.writeFileSync(stale, "old session");

    await handleInbound(pi, inbound("/compact", "m1"), ctx);
    handlers.session_compact?.({ type: "session_compact" }, ctx);
    await waitOpShutdown();

    // placeholder posted + marker left for the respawn to settle
    expect(channelPosts().some((t) => t.includes("[..] handing-off..."))).toBe(
      true,
    );
    expect(fs.existsSync(markerPath())).toBe(true);
    const marker = JSON.parse(fs.readFileSync(markerPath(), "utf8"));
    expect(marker.op).toBe("handoff");
    expect(marker.seeded).toBe(false);
    expect(marker.finalText).toBe(
      "context handoff -> new session (file was 1.5 MB)",
    );
    // restart chain: bounded shutdown + systemd restart
    expect(shutdowns).toBe(1);
    expect(restarter).toEqual(["pi.service"]);
    // F5: the explicit live file moved aside; F2: the OTHER .jsonl
    // archived so the respawn's 'pi -c' target is provably small
    const files = fs.readdirSync(sessDir);
    expect(files.some((f) => f.startsWith("live.jsonl.reset-"))).toBe(true);
    expect(files.some((f) => f.startsWith("old.jsonl.stale-"))).toBe(true);
    expect(files.filter((f) => f.endsWith(".jsonl"))).toEqual([]);
  });

  test("/stop during the handoff op: cancelled, marker cleared, cursor restored, file untouched", async () => {
    writeSettings({ enabled: true, storeDir });
    fs.writeFileSync(liveFile, "x".repeat(1_572_864));
    await handleInbound(pi, inbound("/compact", "m1"), ctx);
    handlers.session_compact?.({ type: "session_compact" }, ctx);
    await new Promise((r) => setTimeout(r, 50)); // B gate opened the op
    expect(opWindowLabel("ch1")).toBe("handing-off");
    await handleInbound(pi, inbound("/stop", "m2"), ctx);
    expect(isCompacting("ch1")).toBe(false);
    expect(fs.existsSync(markerPath())).toBe(false); // marker went with the op
    expect(getChannelCursor("ch1")).toBe("1000"); // rewound to op start
    await waitOpShutdown(); // the shutdown timer was dropped at /stop
    expect(shutdowns).toBe(0);
    expect(fs.existsSync(liveFile)).toBe(true); // file never moved
    expect(restarter).toEqual([]);
  });

  test("handoff disabled: large file, no restart op", async () => {
    writeSettings({ enabled: false, storeDir });
    fs.writeFileSync(liveFile, "x".repeat(2048));
    await handleInbound(pi, inbound("/compact", "m1"), ctx);
    handlers.session_compact?.({ type: "session_compact" }, ctx);
    await waitOpShutdown();
    expect(shutdowns).toBe(0);
    expect(restarter).toEqual([]);
    expect(fs.existsSync(liveFile)).toBe(true);
    expect(fs.existsSync(markerPath())).toBe(false);
  });

  test("every compact restarts (issue #85 follow-up): 2.5MB file, no cap check", async () => {
    // The file-size cap is gone: the restart fires on every handoff
    // qualifying compact regardless of file size.
    writeSettings({ enabled: true, storeDir });
    fs.writeFileSync(liveFile, "x".repeat(2_621_440)); // 2.5 MB
    await handleInbound(pi, inbound("/compact", "m1"), ctx);
    handlers.session_compact?.({ type: "session_compact" }, ctx);
    await waitOpShutdown();
    expect(shutdowns).toBe(1);
    expect(restarter).toEqual(["pi.service"]);
    const marker = JSON.parse(fs.readFileSync(markerPath(), "utf8"));
    expect(marker.op).toBe("handoff");
    expect(marker.finalText).toBe(
      "context handoff -> new session (file was 2.5 MB)",
    );
  });

  test("fresh window guard: a just-seeded session does not immediately re-restart", async () => {
    writeSettings({ enabled: true, storeDir });
    // Write a fresh handover doc (latest.md with an updated: timestamp)
    // so isHandoffFreshWindow returns true.
    const docFile = path.join(storeDir, "latest.md");
    fs.mkdirSync(storeDir, { recursive: true });
    fs.writeFileSync(
      docFile,
      `# Handover\nupdated: ${new Date().toISOString()}\n`,
    );
    await handleInbound(pi, inbound("/compact", "m1"), ctx);
    handlers.session_compact?.({ type: "session_compact" }, ctx);
    await waitOpShutdown();
    // The restart op was skipped (fresh window) — no shutdown.
    expect(shutdowns).toBe(0);
    expect(restarter).toEqual([]);
    expect(fs.existsSync(liveFile)).toBe(true); // file untouched
  });

  test("doc-written arm exempts the triggering restart from the fresh window (issue #85)", async () => {
    writeSettings({ enabled: true, storeDir });
    // session_before_compact just wrote a handover doc: it set BOTH the
    // latest.md stamp (fresh window) AND the restart arm.
    const docFile = path.join(storeDir, "latest.md");
    fs.mkdirSync(storeDir, { recursive: true });
    fs.writeFileSync(
      docFile,
      `# Handover\nupdated: ${new Date().toISOString()}\n`,
    );
    setHandoffRestartArmed(true); // what the doc write now does
    await handleInbound(pi, inbound("/compact", "m1"), ctx);
    handlers.session_compact?.({ type: "session_compact" }, ctx);
    await waitOpShutdown();
    // Restart fired DESPITE the fresh window (the arm exempts the triggering
    // compact); the session rotated -> live file moved aside.
    expect(shutdowns).toBe(1);
    expect(restarter).toEqual(["pi.service"]);
    const marker = JSON.parse(fs.readFileSync(markerPath(), "utf8"));
    expect(marker.op).toBe("handoff");
    expect(marker.seeded).toBe(false);
    expect(fs.existsSync(liveFile)).toBe(false);
  });

  test("settle-flushed /compact re-opens the window: B skips, restarts after that compact's settle", async () => {
    writeSettings({ enabled: true, storeDir });
    fs.writeFileSync(liveFile, "x".repeat(1_572_864));

    // auto-compact in flight: no bridge window (startCompact not involved),
    // isIdle false → /compact QUEUES behind it (pendingCompact)
    ctx.isIdle = () => false;
    await handleInbound(pi, inbound("/compact", "m1"), ctx);
    expect(isCompacting("ch1")).toBe(false); // queued, not started
    // the auto compaction finishes → session_compact settles + flushes
    ctx.isIdle = () => true;
    handlers.session_compact?.({ type: "session_compact" }, ctx);
    await new Promise((r) => setTimeout(r, 50));
    expect(opWindowLabel("ch1")).toBe("compacting"); // flushed C2's window
    expect(fs.existsSync(markerPath())).toBe(false); // B skipped it
    // C2 settles → B proceeds
    handlers.session_compact?.({ type: "session_compact" }, ctx);
    await waitOpShutdown();
    const marker = JSON.parse(fs.readFileSync(markerPath(), "utf8"));
    expect(marker.op).toBe("handoff");
    expect(shutdowns).toBe(1);
  });

  test("boot seed: handoff marker (seeded:false) → user-message seed + marker settled", async () => {
    writeSettings({ enabled: true, storeDir });
    writeHandover(
      [
        "# Handover - 2026-09-23 · session s · 100k tokens → handoff",
        "",
        "## 1 · Mission",
        "Ship the bridge with tests.",
        "",
        "## 2 · In-flight (NOW)",
        "Wiring the compact handler.",
        "",
        "## 10 · Last 3 user asks",
        "1. do the thing",
      ].join("\n"),
      { storeDir, now: new Date() },
    );
    writeMarker({
      op: "handoff",
      channelId: "ch1",
      at: Date.now(),
      msgId: "out1",
      finalText: "context handoff -> new session (file was 1.5 MB)",
      seeded: false,
    });
    // issue #134: the seed carries LIVE dispatch + board state (pinned here
    // - real ps/board are environment-dependent), not doc-scraped prose.
    setLiveKickoffStateHookForTest(() => ({
      dispatchText:
        "**jobs · 1 in flight**\n\n- 20261003-081922-478435 worker · 01:07:43",
      todoBoard: "**todos · 1 open**\n\n- ship it",
    }));

    try {
      await handlers.session_start?.(null, ctx);

      // the seed is a plain user message (never a channel-inbound: no
      // Discord echo, no polluting the next handover's last-asks)
      expect(seedMsgs).toHaveLength(1);
      const lines = seedMsgs[0].split("\n");
      expect(lines[1]).toBe("Mission: 1 open: ship it");
      expect(lines[2]).toBe(
        "In-flight: 20261003-081922-478435 worker · 01:07:43",
      );
      expect(lines[3]).toBe("Last ask: 1. do the thing");
      // issue #140: the hook carries no scheduledText → (none)
      expect(lines[4]).toBe("Scheduled: (none)");
      expect(lines[5]).toBe(ORCHESTRATOR_PRIME_LINE);
      expect(lines[6]).toBe(
        `Read ${storeDir}/latest.md before continuing. Answer the last pending user question if any.`,
      );
      // marker consumed: a second boot cannot re-seed
      expect(fs.existsSync(markerPath())).toBe(false);
      // placeholder replaced with the final line
      expect(
        edits().some((t) =>
          t.includes("context handoff -> new session (file was 1.5 MB)"),
        ),
      ).toBe(true);
    } finally {
      setLiveKickoffStateHookForTest(null);
    }
  });

  test("ordinary boot (no marker): no seed, even with a doc in the store", async () => {
    writeSettings({ enabled: true, storeDir });
    writeHandover("# doc\n## 1 · Mission\nShip.", {
      storeDir,
      now: new Date(),
    });
    await handlers.session_start?.(null, ctx);
    expect(seedMsgs).toHaveLength(0);
  });

  test("already-seeded marker: no re-seed, final line still settled", async () => {
    writeSettings({ enabled: true, storeDir });
    writeHandover("# doc\n## 1 · Mission\nShip.", {
      storeDir,
      now: new Date(),
    });
    writeMarker({
      op: "handoff",
      channelId: "ch1",
      at: Date.now(),
      msgId: "out1",
      finalText: "context handoff -> new session (file was 1.5 MB)",
      seeded: true,
    });
    await handlers.session_start?.(null, ctx);
    expect(seedMsgs).toHaveLength(0);
    expect(fs.existsSync(markerPath())).toBe(false);
    expect(
      edits().some((t) =>
        t.includes("context handoff -> new session (file was 1.5 MB)"),
      ),
    ).toBe(true);
  });
});

describe("handoff token gate: agent_settled re-check (issue #85)", () => {
  // RC1: the gate's first shot fires from agent_end via a 0ms timer, but
  // pi clears the run-active flag (isIdle → true) only in
  // _emitAgentSettled — AFTER the awaited agent_end handler resolves. On
  // any run whose handler awaits Discord I/O (live-text delete, re-wake)
  // the timer fires while isIdle() is still false → silent bail. The
  // agent_settled listener is the reliable shot: pi emits it exactly once
  // per completed run, after every continuation.
  let tmp = "";
  let oldHome = "";
  let storeDir = "";
  let sessDir = "";
  let liveFile = "";
  let pi: any;
  let ctx: any;
  let handlers: Record<string, (...a: any[]) => any> = {};
  let fetchCalls: { url: string; method: string; body?: any }[] = [];
  const realFetch = globalThis.fetch;

  const CHANNELS = [
    {
      id: "ch1",
      name: "Test",
      type: "discord",
      botToken: "tok1",
      ownerUserId: "uid",
      default: true,
    },
  ];

  const tick = (ms = 25) => new Promise((r) => setTimeout(r, ms));

  const writeSettings = (handoff: Record<string, unknown>) => {
    fs.mkdirSync(path.join(tmp, ".pi"), { recursive: true });
    fs.writeFileSync(
      path.join(tmp, ".pi", "settings.json"),
      JSON.stringify({ channels: CHANNELS, handoff }),
    );
  };

  const compactPosts = () =>
    fetchCalls
      .filter(
        (c) => c.url.includes("/channels/ch1/messages") && c.method === "POST",
      )
      .map(
        (c) =>
          (typeof c.body === "string" ? JSON.parse(c.body) : c.body).content,
      )
      .filter(
        (t: unknown) =>
          typeof t === "string" && t.includes("[..] compacting..."),
      );

  beforeEach(async () => {
    tmp = fs.mkdtempSync(path.join(os.tmpdir(), "handoff-a85-"));
    oldHome = process.env.HOME || "";
    process.env.HOME = path.join(tmp, "home");
    fs.mkdirSync(path.join(tmp, "home"), { recursive: true });
    storeDir = path.join(tmp, "home", "handovers");
    sessDir = path.join(tmp, "sessions");
    fs.mkdirSync(sessDir, { recursive: true });
    liveFile = path.join(sessDir, "live.jsonl");
    fs.writeFileSync(liveFile, "x".repeat(1024));
    fetchCalls = [];
    (handlers as any) = {};
    pi = {
      on: (n: string, fn: any) => {
        (handlers as any)[n] = fn;
      },
      sendMessage: () => {},
      sendUserMessage: () => {},
      registerMessageRenderer: () => {},
      registerTool: () => {},
    };
    ctx = {
      cwd: tmp,
      ui: { setStatus: () => {} },
      isIdle: () => true,
      hasPendingMessages: () => false,
      abort: () => {},
      model: { id: "m", name: "M", provider: "p" },
      modelRegistry: { getAvailable: () => [] },
      sessionManager: {
        getSessionFile: () => liveFile,
        getSessionId: () => "sess-a85",
      },
      getContextUsage: () => ({
        tokens: 222_822,
        contextWindow: 262_144,
        percent: 85,
      }),
      compact: () => {},
      shutdown: () => {},
      on: () => {},
    };
    (globalThis as any).fetch = jest.fn(async (url: any, init?: any) => {
      fetchCalls.push({
        method: init?.method ?? "GET",
        url: String(url),
        body: init?.body,
      });
      return { ok: true, status: 200, json: async () => ({ id: "out1" }) };
    });
    setProcessExitHookForTest(() => {});
    writeSettings({ enabled: true, threshold: 0.8, storeDir });
    seedChannelStateForTest("ch1", "ch1", path.join(tmp, ".tmp"));
    setChannelCursor("ch1", "1000");
    extension(pi as any);
    // Re-point lastActiveChannel at THIS describe's ch1 (module state,
    // leaked by earlier describes) and load channels for presence paths.
    await handlers.session_start?.(null, ctx);
  });
  afterEach(() => {
    setProcessExitHookForTest(null);
    (globalThis as any).fetch = realFetch;
    (handlers as any) = {};
    clearAllCompacting();
    stopAllOpTicks();
    process.env.HOME = oldHome;
    fs.rmSync(tmp, { recursive: true, force: true });
  });

  test("I/O-pending agent_end bails; agent_settled re-checks and fires", async () => {
    // A run whose agent_end handler awaits Discord I/O (live-text delete,
    // re-wake): pi has NOT cleared the run flag, so isIdle() is false
    // while the 0ms gate timer from agent_end fires.
    ctx.isIdle = () => false;
    await handlers.agent_end?.({ type: "agent_end", messages: [] }, ctx);
    await tick();
    expect(isCompacting("ch1")).toBe(false); // RC1: the agent_end shot bailed

    // pi settles: _isAgentRunActive cleared, agent_settled emitted.
    ctx.isIdle = () => true;
    await handlers.agent_settled?.({ type: "agent_settled" }, ctx);
    await tick();
    expect(isCompacting("ch1")).toBe(true); // the settled shot fired
    expect(compactPosts()).toHaveLength(1);
  });

  test("re-wake active at agent_settled: skip; the re-wake's own settled fires", async () => {
    // The re-wake continuation started from agent_end is still running
    // (a run is active → isIdle false → the gate must yield to that run).
    ctx.isIdle = () => false;
    await handlers.agent_settled?.({ type: "agent_settled" }, ctx);
    await tick();
    expect(isCompacting("ch1")).toBe(false);
    // The re-wake run settles → its own agent_settled re-checks.
    ctx.isIdle = () => true;
    await handlers.agent_settled?.({ type: "agent_settled" }, ctx);
    await tick();
    expect(isCompacting("ch1")).toBe(true);
    expect(compactPosts()).toHaveLength(1);
  });

  test("I/O-free agent_end fires first; agent_settled double-fire is safe", async () => {
    // The old lucky path: the handler settles I/O-free, so the agent_end
    // 0ms timer runs the gate with isIdle() true and starts the compact.
    ctx.isIdle = () => true;
    await handlers.agent_end?.({ type: "agent_end", messages: [] }, ctx);
    await tick();
    expect(isCompacting("ch1")).toBe(true);
    // agent_settled's second shot must bail on the isCompacting guard —
    // ONE compact window, ONE placeholder post.
    await handlers.agent_settled?.({ type: "agent_settled" }, ctx);
    await tick();
    expect(isCompacting("ch1")).toBe(true);
    expect(compactPosts()).toHaveLength(1);
  });

  test("under threshold at settled: no compact", async () => {
    ctx.getContextUsage = () => ({
      tokens: 131_072,
      contextWindow: 262_144,
      percent: 50,
    });
    ctx.isIdle = () => true;
    await handlers.agent_settled?.({ type: "agent_settled" }, ctx);
    await tick();
    expect(isCompacting("ch1")).toBe(false);
    expect(compactPosts()).toHaveLength(0);
  });

  test("handoff disabled at settled: no compact", async () => {
    writeSettings({ enabled: false, threshold: 0.8, storeDir });
    ctx.isIdle = () => true;
    await handlers.agent_settled?.({ type: "agent_settled" }, ctx);
    await tick();
    expect(isCompacting("ch1")).toBe(false);
    expect(compactPosts()).toHaveLength(0);
  });

  test("stale ctx at timer fire: gate skips, no unhandled rejection (2026-10-19 pi -p exit crash)", async () => {
    // pi -p: the session ends at run end, so the agent_settled gate timer
    // ALWAYS fires against a replaced (dead) session: the ctx.cwd getter
    // throws "stale". Pre-fix, that throw escaped as a REJECTED promise —
    // the try/catch around `void maybeAutoCompactByToken` only caught
    // sync throws — and the unhandled rejection killed `pi -p` at exit.
    Object.defineProperty(ctx, "cwd", {
      get() {
        throw new Error(
          "This extension ctx is stale after session replacement or reload. Do not use a captured pi or command ctx after ctx.newSession(), ctx.fork(), ctx.switchSession(), or ctx.reload().",
        );
      },
      configurable: true,
    });

    // 1. Direct call: the defensive guard makes the gate RESOLVE (not
    // reject) on a stale ctx — the replacement session's own settle
    // re-runs the gate.
    await expect(maybeAutoCompactByToken(pi, ctx)).resolves.toBeUndefined();
    expect(isCompacting("ch1")).toBe(false);

    // 2. The real crash path: the armed 0ms timer with a stale ctx must
    // not surface an unhandled rejection.
    const rejections: unknown[] = [];
    const onRejection = (r: unknown) => rejections.push(r);
    process.on("unhandledRejection", onRejection);
    try {
      autoCompactByToken(pi, ctx);
      await tick(50); // let the timer + rejection microtask run
    } finally {
      process.off("unhandledRejection", onRejection);
    }
    expect(rejections).toEqual([]);
    expect(isCompacting("ch1")).toBe(false);
  });
});

describe("restart-class ops (/reset /restart): block + tick + cursor replay", () => {
  let tmp = "";
  let oldHome = "";
  let pi: any;
  let ctx: any;
  let handlers: Record<string, (...a: any[]) => any> = {};
  let sent: { m: any; o?: any }[] = [];
  let fetchCalls: { url: string; method: string; body?: any }[] = [];
  let shutdowns = 0;
  let home = "";
  const realFetch = globalThis.fetch;

  const inbound = (body: string, id: string): ChannelMessage => ({
    channelId: "ch1",
    channelName: "Test",
    channelType: "discord",
    messageId: id,
    from: "u",
    fromId: "uid",
    body,
    timestamp: new Date().toISOString(),
    attachments: [],
    isRoom: false,
  });

  const tick = () => new Promise((r) => setTimeout(r, 0));

  const channelPosts = () =>
    fetchCalls
      .filter(
        (c) => c.url.includes("/channels/ch1/messages") && c.method === "POST",
      )
      .map(
        (c) =>
          (typeof c.body === "string" ? JSON.parse(c.body) : c.body).content,
      );

  const edits = () =>
    fetchCalls
      .filter((c) => c.method === "PATCH" && c.url.includes("/messages/"))
      .map(
        (c) =>
          (typeof c.body === "string" ? JSON.parse(c.body) : c.body).content,
      );

  // wait out a pending op shutdown (300ms arm + immediate isIdle) so the
  // session-file move happens while HOME still points at tmp
  const waitOpShutdown = () => new Promise((r) => setTimeout(r, 1100));

  beforeEach(() => {
    clearDiscordStatesForTest(); // no auto-react suppression leaks across tests
    resetRuntimeStateForTest(); // sessionStartTs/held/verbose: no leaks
    tmp = fs.mkdtempSync(path.join(os.tmpdir(), "op-test-"));
    oldHome = process.env.HOME || "";
    home = path.join(tmp, "home");
    process.env.HOME = home;
    fs.mkdirSync(path.join(tmp, ".pi"), { recursive: true });
    fs.writeFileSync(
      path.join(tmp, ".pi", "settings.json"),
      JSON.stringify({
        channels: [
          {
            id: "ch1",
            name: "Test",
            type: "discord",
            botToken: "tok1",
            ownerUserId: "uid",
            ack: true,
          },
        ],
      }),
    );
    handlers = {};
    sent = [];
    fetchCalls = [];
    shutdowns = 0;
    pi = {
      registerMessageRenderer: () => {},
      registerTool: () => {},
      on: (n: string, fn: any) => {
        handlers[n] = fn;
      },
      sendMessage: (m: any, o?: any) => {
        sent.push({ m, o });
      },
    };
    extension(pi);
    ctx = {
      cwd: tmp,
      ui: { setStatus: () => {} },
      isIdle: () => true,
      hasPendingMessages: () => false,
      abort: () => {},
      compact: () => {},
      modelRegistry: { getAvailable: () => [] },
      getContextUsage: () => undefined,
      model: { id: "cur", name: "Cur" },
      shutdown: () => {
        shutdowns++;
      },
    };
    globalThis.fetch = (async (url: any, init?: any) => {
      fetchCalls.push({
        url: String(url),
        method: init?.method ?? "GET",
        body: init?.body,
      });
      return {
        ok: true,
        status: 200,
        json: async () => ({ id: "out1" }),
        text: async () => "",
      };
    }) as any;
    // op machinery needs a live cursor: seed the discord state for ch1.
    seedChannelStateForTest("ch1", "ch1", path.join(tmp, ".tmp"));
    setChannelCursor("ch1", "1000");
    // keep the test from spawning a real `systemctl --user restart`
    setSystemdRestartHookForTest(() => {});
  });

  afterEach(async () => {
    clearDiscordStatesForTest(); // no auto-react suppression leaks across tests
    jest.useRealTimers();
    stopAllOpTicks();
    clearAllCompacting();
    clearAllInterrupts();
    resetRuntimeStateForTest(); // no hold/verbose leaks across tests (#84 L2)
    setInterruptCtx(null);
    setSystemdRestartHookForTest(null);
    setProcessExitHookForTest(null);
    for (const id of [...midTurnQueues.keys()]) clearQueuedInbound(id);
    queuedAcks.clear();
    pendingInterrupts.clear();
    handlers.agent_end?.({ messages: [] }, ctx);
    stopAllOpTicks();
    clearAllCompacting();
    clearDiscordStatesForTest();
    process.env.HOME = oldHome;
    globalThis.fetch = realFetch;
    fs.rmSync(tmp, { recursive: true, force: true });
  });

  test("idle /reset: posts ticking placeholder, blocks the channel, moves the session aside, rewinds the cursor", async () => {
    const sessDir = path.join(
      home,
      ".pi",
      "agent",
      "sessions",
      `-${String(tmp).replace(/\//g, "-")}-`,
    );
    fs.mkdirSync(sessDir, { recursive: true });
    const sess = path.join(sessDir, "s.jsonl");
    fs.writeFileSync(sess, "{}\n");

    await handleInbound(pi, inbound("/reset", "m1"), ctx);
    await tick();
    expect(channelPosts().some((t) => t.includes("[..] resetting..."))).toBe(
      true,
    );
    expect(isCompacting("ch1")).toBe(true);
    expect(opWindowLabel("ch1")).toBe("resetting");

    // an inbound lands during the op -> cursor advances past it
    setChannelCursor("ch1", "1200");
    await waitOpShutdown();
    expect(shutdowns).toBe(1);
    // session file moved aside -> respawn starts a fresh session
    expect(fs.existsSync(sess)).toBe(false);
    expect(fs.readdirSync(sessDir).some((f) => f.includes(".reset-"))).toBe(
      true,
    );
    // cursor rewound to the pre-op position, persisted for the respawn
    expect(getChannelCursor("ch1")).toBe("1000");
    expect(loadPersistedCursors(path.join(tmp, ".tmp")).ch1).toBe("1000");
  });

  test("idle /restart: same block + tick, but the session file is KEPT (resumed)", async () => {
    const sessDir = path.join(
      home,
      ".pi",
      "agent",
      "sessions",
      `-${String(tmp).replace(/\//g, "-")}-`,
    );
    fs.mkdirSync(sessDir, { recursive: true });
    const sess = path.join(sessDir, "s.jsonl");
    fs.writeFileSync(sess, "{}\n");

    await handleInbound(pi, inbound("/restart", "m1"), ctx);
    await tick();
    expect(channelPosts().some((t) => t.includes("[..] restarting..."))).toBe(
      true,
    );
    expect(opWindowLabel("ch1")).toBe("restarting");
    await waitOpShutdown();
    expect(shutdowns).toBe(1);
    expect(fs.existsSync(sess)).toBe(true); // not moved aside
  });

  test("/reset drains queued inbounds before shutdown (#84 L2): acks deleted, not orphaned", async () => {
    verboseOverride.set("ch1", 1); // verbose 1: the [queued] ack posts
    await handlers.session_start?.(null, ctx); // configRoot for ack REST
    // a run is in flight: a plain message queues + posts an ack
    ctx.isIdle = () => false;
    await handleInbound(pi, inbound("queued work", "mq1"), ctx);
    await tick(); // settle the fire-and-forget ack post
    const ackId = queuedAcks.get("mq1")?.ackId;
    expect(ackId).toBeDefined();
    expect(channelPosts().some((t) => t.includes("[queued] 1 in line"))).toBe(
      true,
    );

    // #84 L2: /reset must drain the queue while the process is still alive,
    // so the ack is DELETED — a respawn never references it, and a shutdown
    // map-clear would orphan the message in the channel forever.
    await handleInbound(pi, inbound("/reset", "m1"), ctx);
    await tick(); // settle the fire-and-forget delete
    expect(midTurnQueues.get("ch1")).toBeUndefined();
    expect(queuedAcks.get("mq1")).toBeUndefined();
    const del = fetchCalls.find(
      (c) =>
        c.method === "DELETE" &&
        c.url.endsWith(`/channels/ch1/messages/${ackId}`),
    );
    expect(del).toBeDefined();
  });

  test("/reset keeps a HELD channel's buffer (#84 L2, A4 parity): no drain", async () => {
    verboseOverride.set("ch1", 1); // verbose 1: the [queued] ack posts
    await handlers.session_start?.(null, ctx); // configRoot for ack REST
    // hold the channel, then buffer a message (held queues even while idle)
    await handleInbound(pi, inbound("/hold on", "mh1"), ctx);
    await tick();
    expect(isHeld(loadChannelConfig(ctx.cwd)[0]!)).toBe(true);
    await handleInbound(pi, inbound("buffered work", "mq1"), ctx);
    await tick();
    const ackId = queuedAcks.get("mq1")?.ackId;
    expect(ackId).toBeDefined();

    // #84 L2 (A4): a HELD channel's queue is the operator's buffer — /reset
    // keeps it. No drain, the ack is NOT deleted.
    await handleInbound(pi, inbound("/reset", "m1"), ctx);
    await tick();
    expect(midTurnQueues.get("ch1")?.[0]?.msg.messageId).toBe("mq1");
    expect(queuedAcks.get("mq1")?.ackId).toBe(ackId);
    const del = fetchCalls.find(
      (c) =>
        c.method === "DELETE" &&
        c.url.endsWith(`/channels/ch1/messages/${ackId}`),
    );
    expect(del).toBeUndefined();
  });

  test("/reset placeholder ticks in place every 5s (shared op tick)", async () => {
    jest.useFakeTimers();
    await handleInbound(pi, inbound("/reset", "m1"), ctx);
    // settle the fire-and-forget placeholder post (microtasks, no timers)
    await Promise.resolve();
    await Promise.resolve();
    await Promise.resolve();
    expect(channelPosts().some((t) => t.includes("[..] resetting..."))).toBe(
      true,
    );

    // the bounded op shutdown lands at +300ms (isIdle is immediate here)
    jest.advanceTimersByTime(300);
    // flush the async shutdown chain (race on the placeholder + rewinds)
    for (let i = 0; i < 20; i++) await Promise.resolve();
    expect(shutdowns).toBe(1);

    // window stays open until the respawn clears it -> ticks keep going
    // (one-line op status = prose, bare ticks per v4 §2.3)
    jest.advanceTimersByTime(4699); // t=4999
    expect(edits().length).toBe(0);
    jest.advanceTimersByTime(1); // t=5000
    expect(edits()).toEqual(["[..] resetting… 5s"]);
    jest.advanceTimersByTime(5000); // t=10000
    expect(edits()).toEqual(["[..] resetting… 5s", "[..] resetting… 10s"]);

    // respawn clears the window -> ticks stop
    clearAllCompacting();
    jest.advanceTimersByTime(60000);
    expect(edits().length).toBe(2);
  });

  test("inbound during the /reset window: queued with an ack, no interrupt armed", async () => {
    verboseOverride.set("ch1", 1); // verbose 1: the [queued] ack posts
    await handleInbound(pi, inbound("/reset", "m1"), ctx);
    await tick();
    expect(isCompacting("ch1")).toBe(true);

    await handleInbound(pi, inbound("hello", "m2"), ctx);
    await tick();
    expect(channelPosts().some((t) => t.includes("[queued] 1 in line"))).toBe(
      true,
    );
    expect(midTurnQueues.get("ch1")?.[0]?.msg.messageId).toBe("m2");
    expect(pendingInterrupts.get("ch1")).toBeUndefined();
    await waitOpShutdown();
  });

  test("respawn: session_start settles the placeholder in place + cursor replays the op window", async () => {
    await handleInbound(pi, inbound("/reset", "m1"), ctx);
    await tick();
    setChannelCursor("ch1", "1200"); // an op-window inbound was delivered
    await waitOpShutdown();
    expect(shutdowns).toBe(1);

    // fresh process boots: old in-memory window/ticks are gone
    clearAllCompacting();
    stopAllOpTicks();
    const editsBefore = edits().length;
    await handlers.session_start?.(null, ctx);
    await tick();

    // the placeholder is REPLACED in place with the bare final line, not
    // re-posted (status is prose — unfenced placeholder, unfenced settle;
    // same form on both sides per v4 §2.3)
    const finalText = "[new] new session (context cleared)";
    expect(
      edits()
        .slice(editsBefore)
        .some((t) => t === finalText),
    ).toBe(true);
    expect(channelPosts().some((t) => t === finalText)).toBe(false);
    // marker consumed
    expect(fs.existsSync(path.join(tmp, ".tmp", "op-marker.json"))).toBe(false);

    // the new process replays the op window: first poll ranges after the
    // pre-op cursor (1000), not after the advanced 1200
    await pollDiscord("ch1");
    const pollUrl = fetchCalls.find((c) => c.url.includes("after="))?.url;
    expect(pollUrl).toContain("after=1000");
  });

  test("respawn settle without a msgId posts a bare final line", async () => {
    const p = path.join(tmp, ".tmp", "op-marker.json");
    fs.mkdirSync(path.dirname(p), { recursive: true });
    const finalText = "[new] new session (context cleared)";
    fs.writeFileSync(
      p,
      JSON.stringify({
        op: "reset",
        channelId: "ch1",
        at: Date.now(),
        finalText,
      }),
    );
    await handlers.session_start?.(null, ctx);
    await tick();
    // bare fresh post — same prose form as the bare placeholder, never fenced
    expect(channelPosts().some((t) => t === finalText)).toBe(true);
    expect(channelPosts().some((t) => t === fence(finalText))).toBe(false);
    expect(edits().some((t) => t === finalText || t === fence(finalText))).toBe(
      false,
    );
    expect(fs.existsSync(p)).toBe(false); // consumed
  });

  test("stale op marker (>10m) is dropped, not shown", async () => {
    const p = path.join(tmp, ".tmp", "op-marker.json");
    fs.mkdirSync(path.dirname(p), { recursive: true });
    fs.writeFileSync(
      p,
      JSON.stringify({
        op: "reset",
        channelId: "ch1",
        at: Date.now() - 11 * 60 * 1000,
        msgId: "x",
        finalText: "[new] stale",
      }),
    );
    await handlers.session_start?.(null, ctx);
    await tick();
    expect(channelPosts().some((t) => t === "[new] stale")).toBe(false);
    expect(edits().some((t) => t === "[new] stale")).toBe(false);
    expect(fs.existsSync(p)).toBe(false); // consumed either way
  });

  test("/undo 0 and /undo abc: one [!] usage line, no action, no op window", async () => {
    const sessDir = path.join(
      home,
      ".pi",
      "agent",
      "sessions",
      `-${String(tmp).replace(/\//g, "-")}-`,
    );
    const sess = path.join(sessDir, "s.jsonl");
    fs.mkdirSync(sessDir, { recursive: true });
    const mk = (id: string, parentId: string | null, body: string) => ({
      type: "custom_message",
      id,
      parentId,
      customType: "channel-inbound",
      content: body,
      details: { body },
    });
    const asst = (id: string, parentId: string) => ({
      type: "message",
      id,
      parentId,
      message: { role: "assistant", content: [{ type: "text", text: "ok" }] },
    });
    fs.writeFileSync(
      sess,
      `${[
        { type: "session", version: 3, id: "s1", timestamp: "t", cwd: tmp },
        mk("T1", null, "q1"),
        asst("A1", "T1"),
      ]
        .map((l) => JSON.stringify(l))
        .join("\n")}\n`,
    );
    const before = fs.readFileSync(sess, "utf8");

    await handleInbound(pi, inbound("/undo 0", "m1"), ctx);
    await tick();
    await handleInbound(pi, inbound("/undo abc", "m2"), ctx);
    await tick();
    expect(
      channelPosts().filter((t) =>
        t.includes("[!] usage: /undo [N] (N is 1 or more)"),
      ),
    ).toHaveLength(2);
    expect(isCompacting("ch1")).toBe(false); // no op window opened
    expect(fs.readFileSync(sess, "utf8")).toBe(before); // session untouched
    expect(shutdowns).toBe(0);
  });

  test("/undo 99 (N > chain length): one [!] line, no restart", async () => {
    const sessDir = path.join(
      home,
      ".pi",
      "agent",
      "sessions",
      `-${String(tmp).replace(/\//g, "-")}-`,
    );
    const sess = path.join(sessDir, "s.jsonl");
    fs.mkdirSync(sessDir, { recursive: true });
    const mk = (id: string, parentId: string | null, body: string) => ({
      type: "custom_message",
      id,
      parentId,
      customType: "channel-inbound",
      content: body,
      details: { body },
    });
    const asst = (id: string, parentId: string) => ({
      type: "message",
      id,
      parentId,
      message: { role: "assistant", content: [{ type: "text", text: "ok" }] },
    });
    fs.writeFileSync(
      sess,
      `${[
        { type: "session", version: 3, id: "s1", timestamp: "t", cwd: tmp },
        mk("T1", null, "q1"),
        asst("A1", "T1"),
      ]
        .map((l) => JSON.stringify(l))
        .join("\n")}\n`,
    );
    const before = fs.readFileSync(sess, "utf8");

    await handleInbound(pi, inbound("/undo 99", "m1"), ctx);
    await tick();
    expect(
      channelPosts().some((t) =>
        t.includes("nothing to undo: only 1 turn back"),
      ),
    ).toBe(true);
    expect(isCompacting("ch1")).toBe(false);
    expect(fs.readFileSync(sess, "utf8")).toBe(before);
    expect(shutdowns).toBe(0);
  });

  test("/undo 2: ONE restart-class op reverts both turns (issue #46)", async () => {
    const sessDir = path.join(
      home,
      ".pi",
      "agent",
      "sessions",
      `-${String(tmp).replace(/\//g, "-")}-`,
    );
    const sess = path.join(sessDir, "s.jsonl");
    fs.mkdirSync(sessDir, { recursive: true });
    const mk = (id: string, parentId: string | null, body: string) => ({
      type: "custom_message",
      id,
      parentId,
      customType: "channel-inbound",
      content: body,
      details: { body },
    });
    const asst = (id: string, parentId: string) => ({
      type: "message",
      id,
      parentId,
      message: { role: "assistant", content: [{ type: "text", text: "ok" }] },
    });
    const lines = [
      { type: "session", version: 3, id: "s1", timestamp: "t", cwd: tmp },
      mk("T1", null, "q1"),
      asst("A1", "T1"),
      mk("T2", "A1", "q2"),
      asst("A2", "T2"),
      mk("T3", "A2", "q3"),
      asst("A3", "T3"),
    ];
    fs.writeFileSync(
      sess,
      `${lines.map((l) => JSON.stringify(l)).join("\n")}\n`,
    );

    await handleInbound(pi, inbound("/undo 2", "m1"), ctx);
    await tick();
    // the restart-class op is armed (block + tick), same as /reset
    expect(channelPosts().some((t) => t.includes("[..] undoing..."))).toBe(
      true,
    );
    expect(isCompacting("ch1")).toBe(true);
    expect(opWindowLabel("ch1")).toBe("undoing");
    // BOTH turns are cut in ONE pass: session is at pre-2nd-turn state
    const ids = fs
      .readFileSync(sess, "utf8")
      .trim()
      .split("\n")
      .map((l) => JSON.parse(l).id);
    expect(ids).toEqual(["s1", "T1", "A1", "T2"]);

    await waitOpShutdown();
    expect(shutdowns).toBe(1); // ONE restart for two turns
    // the op marker carries the final ack the respawn settles
    const marker = JSON.parse(
      fs.readFileSync(path.join(tmp, ".tmp", "op-marker.json"), "utf8"),
    );
    expect(marker.op).toBe("undo");
    expect(marker.finalText).toContain(
      "undone: 2 turns + conversation (re-running q2)",
    );
  });

  test("/stop during an op CANCELS it: no shutdown, no systemd restart, session file kept", async () => {
    const sessDir = path.join(
      home,
      ".pi",
      "agent",
      "sessions",
      `-${String(tmp).replace(/\//g, "-")}-`,
    );
    fs.mkdirSync(sessDir, { recursive: true });
    const sess = path.join(sessDir, "s.jsonl");
    fs.writeFileSync(sess, "{}\n");
    let restartRequests = 0;
    setSystemdRestartHookForTest(() => {
      restartRequests++;
    });

    await handleInbound(pi, inbound("/reset", "m1"), ctx);
    await tick();
    setChannelCursor("ch1", "1200"); // an op-window inbound was delivered

    await handleInbound(pi, inbound("/stop", "m3"), ctx);
    await tick();
    expect(isCompacting("ch1")).toBe(false);
    expect(getChannelCursor("ch1")).toBe("1000"); // cursor restored
    expect(
      channelPosts().some((t) => t.includes("[-] stopped (restart cancelled)")),
    ).toBe(true);
    // the marker goes with the cancelled op — no stale settle on next boot
    expect(fs.existsSync(path.join(tmp, ".tmp", "op-marker.json"))).toBe(false);

    // The original op timer (armed at 300ms) must NOT fire the chain.
    await waitOpShutdown();
    expect(shutdowns).toBe(0); // no ctx.shutdown
    expect(restartRequests).toBe(0); // no systemd restart request
    expect(fs.existsSync(sess)).toBe(true); // session file NOT moved aside
    expect(fs.readdirSync(sessDir).some((f) => f.includes(".reset-"))).toBe(
      false,
    );
  });

  test("session_shutdown re-rewinds the op cursor: a gap inbound after the rewind cannot advance it", async () => {
    await handleInbound(pi, inbound("/reset", "m1"), ctx);
    await tick();
    await waitOpShutdown(); // chain ran: rewound to 1000 + persisted
    expect(getChannelCursor("ch1")).toBe("1000");

    // an inbound lands in the gap: after the op's rewind, before the
    // shutdown's disconnects
    setChannelCursor("ch1", "1200");
    expect(getChannelCursor("ch1")).toBe("1200");

    await handlers.session_shutdown?.();
    // re-rewound (in-memory + persisted) — the respawn replays 1000..1200
    expect(getChannelCursor("ch1")).toBe("1000");
    expect(loadPersistedCursors(path.join(tmp, ".tmp")).ch1).toBe("1000");
  });

  test("#84b: session_shutdown drains queued inbounds (acks deleted); held channel keeps its buffer", async () => {
    // Two channels in settings so configRoot resolves both for the REST
    // drain — rewrite BEFORE session_start loads the channel list.
    fs.writeFileSync(
      path.join(tmp, ".pi", "settings.json"),
      JSON.stringify({
        channels: [
          {
            id: "ch1",
            name: "Test",
            type: "discord",
            botToken: "tok1",
            ownerUserId: "uid",
            ack: true,
          },
          {
            id: "ch2",
            name: "Other",
            type: "discord",
            botToken: "tok2",
            ownerUserId: "uid",
            ack: true,
          },
        ],
      }),
    );
    await handlers.session_start?.(null, ctx); // configRoot for channel REST

    // ch1 (non-held): two queued inbounds + their acks — the orphan path
    const m2 = inbound("hello", "m2");
    queueMidTurnInbound(
      "ch1",
      m2,
      "ctx\n\nhello",
      "discord/Test",
      "hello",
      false,
    );
    queuedAcks.set("m2", { ackId: "ack1", fromId: "uid", pos: 1 });
    const m2b = inbound("again", "m2b");
    queueMidTurnInbound(
      "ch1",
      m2b,
      "ctx\n\nagain",
      "discord/Test",
      "again",
      false,
    );
    queuedAcks.set("m2b", { ackId: "ack1b", fromId: "uid", pos: 2 });

    // ch2 (held): the operator's buffer — must NOT be drained (A4 parity,
    // /stop + /reset #84 L2)
    const m3: ChannelMessage = {
      ...inbound("keep", "m3"),
      channelId: "ch2",
      channelName: "Other",
    };
    queueMidTurnInbound(
      "ch2",
      m3,
      "ctx\n\nkeep",
      "discord/Other",
      "keep",
      false,
    );
    queuedAcks.set("m3", { ackId: "ack2", fromId: "uid", pos: 1 });
    heldChannels.add("ch2");

    await handlers.session_shutdown?.(); // awaits its REST deletes

    // DELETE only: the drain's renumber also PATCHes the surviving acks,
    // so a DELETE|PATCH check would pass even if a delete never fired.
    const deleted = (ackId: string) =>
      fetchCalls.some(
        (c) => c.method === "DELETE" && c.url.includes(`/messages/${ackId}`),
      );
    expect(deleted("ack1")).toBe(true); // non-held: ack deleted, no orphan
    expect(deleted("ack1b")).toBe(true); // every queued ack in the line
    expect(deleted("ack2")).toBe(false); // held: buffer kept, ack untouched
    expect(midTurnQueues.get("ch1")).toBeUndefined(); // drained
    expect(queuedAcks.has("m2")).toBe(false);
    expect(queuedAcks.has("m2b")).toBe(false);
  });

  test("#84: shutdown while a run is in flight morphs the working frame to a terminal state (no frozen 'working' box)", async () => {
    verboseOverride.set("ch1", 2);
    await handlers.session_start?.(null, ctx); // configRoot for channel REST
    await handleInbound(pi, inbound("work", "m1"), ctx);
    ctx.isIdle = () => false; // the run is in flight
    await handlers.turn_start(null, ctx); // posts the working frame (out1)
    await handlers.tool_call(
      { toolName: "bash", input: { command: "ls" } },
      ctx,
    );
    expect(edits().some((t) => t.includes("working · 1 call"))).toBe(true);

    await handlers.session_shutdown?.(); // process dies while the run lives

    // terminal morph in place (agent_end never fires on a dying process)
    expect(edits().some((t) => t.includes("┌ stopped · 1 call"))).toBe(true);
    const deleted = (id: string) =>
      fetchCalls.some(
        (c) => c.method === "DELETE" && c.url.includes(`/messages/${id}`),
      );
    expect(deleted("out1")).toBe(false); // calls > 0: morph, not delete
  });

  test("#84: shutdown on a 0-call verbose-2 run deletes the working frame (same rule as agent_end)", async () => {
    verboseOverride.set("ch1", 2);
    await handlers.session_start?.(null, ctx);
    await handleInbound(pi, inbound("work", "m1"), ctx);
    ctx.isIdle = () => false;
    await handlers.turn_start(null, ctx); // posts "working · 0 calls · 0s"
    expect(channelPosts().some((t) => t.includes("┌ working · 0 calls"))).toBe(
      true,
    );

    await handlers.session_shutdown?.();

    // agent_end deletes 0-call frames (a leftover box is noise) — shutdown must
    const deleted = (id: string) =>
      fetchCalls.some(
        (c) => c.method === "DELETE" && c.url.includes(`/messages/${id}`),
      );
    expect(deleted("out1")).toBe(true);
  });

  test("#84: shutdown after a clean run end leaves the terminal 'done' frame untouched", async () => {
    verboseOverride.set("ch1", 2);
    await handlers.session_start?.(null, ctx);
    await handleInbound(pi, inbound("work", "m1"), ctx);
    ctx.isIdle = () => false;
    await handlers.turn_start(null, ctx);
    await handlers.tool_call(
      { toolName: "bash", input: { command: "ls" } },
      ctx,
    );
    const finMsg = {
      role: "assistant",
      content: [{ type: "text", text: "done answer" }],
    };
    await handlers.agent_end({ messages: [finMsg] }, ctx); // morphs to done
    expect(edits().filter((t) => t.includes("┌ done · 1 call")).length).toBe(1);

    await handlers.session_shutdown?.(); // runOpen is false: no second morph

    expect(edits().some((t) => t.includes("stopped"))).toBe(false);
    expect(edits().filter((t) => t.includes("┌ done · 1 call")).length).toBe(1);
    const deleted = (id: string) =>
      fetchCalls.some(
        (c) => c.method === "DELETE" && c.url.includes(`/messages/${id}`),
      );
    expect(deleted("out1")).toBe(false);
  });

  test("#84: shutdown consumes the in-flight interrupt's ack line (entry spliced out of the queue)", async () => {
    jest.useFakeTimers();
    await handlers.session_start?.(null, ctx); // configRoot for channel REST
    ctx.isIdle = () => false; // a run is in flight
    const m2 = inbound("hello", "m2");
    queueMidTurnInbound(
      "ch1",
      m2,
      "ctx\n\nhello",
      "discord/Test",
      "hello",
      false,
    );
    queuedAcks.set("m2", { ackId: "ack1", fromId: "uid", pos: 1 });

    const p = runMidRunInterrupt(pi, ctx, "ch1", "m2");
    jest.advanceTimersByTime(1000); // abort fired, entry spliced, settle running

    await handlers.session_shutdown?.();

    // the "[..] interrupting… Ns" line IS the queued ack — it must go,
    // even though the drain cannot see the spliced entry
    const deleted = (id: string) =>
      fetchCalls.some(
        (c) => c.method === "DELETE" && c.url.includes(`/messages/${id}`),
      );
    expect(deleted("ack1")).toBe(true);

    // let the interrupt settle after the shutdown (no throw, no re-arm)
    ctx.isIdle = () => true;
    jest.advanceTimersByTime(50);
    await p;
  });

  test("#84: shutdown deletes the SPEC B live-text ephemeral (agent_end's delete never runs)", async () => {
    verboseOverride.set("ch1", 1); // level 1: a reads-only run posts NO frame
    await handlers.session_start?.(null, ctx);
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    ctx.isIdle = () => false;
    await handlers.turn_start(null, ctx);
    // non-final step message (text + pending tool call) -> live text
    await handlers.message_end(
      {
        message: {
          role: "assistant",
          content: [
            { type: "text", text: "let me check" },
            { type: "toolCall", toolName: "read", arguments: {} },
          ],
        },
      },
      ctx,
    );
    // the first (non-essential) tool call posts the live-text message
    await handlers.tool_call(
      { toolName: "read", input: { path: "a.txt" } },
      ctx,
    );
    const livePosted = channelPosts().some((t) => t === "let me check");
    expect(livePosted).toBe(true);
    // no working frame exists for this run
    expect(channelPosts().some((t) => t.includes("┌ working"))).toBe(false);

    await handlers.session_shutdown?.();

    const deleted = (id: string) =>
      fetchCalls.some(
        (c) => c.method === "DELETE" && c.url.includes(`/messages/${id}`),
      );
    expect(deleted("out1")).toBe(true);
  });

  test("#84: shutdown settles an open compact window's ticking line (no marker to settle it)", async () => {
    await handlers.session_start?.(null, ctx);
    await handleInbound(pi, inbound("/compact", "m1"), ctx);
    await tick(); // placeholder post landed, tick armed (out1)
    expect(channelPosts().some((t) => t.includes("[..] compacting..."))).toBe(
      true,
    );

    await handlers.session_shutdown?.(); // process dies mid-compact

    const settled = fetchCalls.some(
      (c) =>
        c.method === "PATCH" &&
        c.url.includes("/messages/out1") &&
        String(c.body).includes("compact interrupted"),
    );
    expect(settled).toBe(true);
  });

  test("second /reset while an op window is open is rejected; /compact sees the active op; /status shows the op label", async () => {
    await handleInbound(pi, inbound("/reset", "m1"), ctx);
    await tick();
    await handleInbound(pi, inbound("/reset", "m4"), ctx);
    await tick();
    expect(
      channelPosts().filter((t) => t.includes("already restarting")).length,
    ).toBe(1);
    // F5: /compact while resetting names the ACTIVE op, not itself
    await handleInbound(pi, inbound("/compact", "m4b"), ctx);
    await tick();
    expect(
      channelPosts().filter((t) => t.includes("already restarting")).length,
    ).toBe(2);

    await handleInbound(pi, inbound("/status", "m5"), ctx);
    await tick();
    expect(channelPosts().some((t) => t.includes("resetting"))).toBe(true);
    await waitOpShutdown();
  });

  test("mid-run interrupt ticks the [queued] ack in place", async () => {
    jest.useFakeTimers();
    await handlers.session_start?.(null, ctx); // configRoot for channel REST
    ctx.isIdle = () => false;
    const m2 = inbound("hello", "m2");
    queueMidTurnInbound("ch1", m2, "ctx\n\nhello", "discord/Test", "hello");
    queuedAcks.set("m2", { ackId: "ack1", fromId: "uid", pos: 1 });

    const ackEdits = () =>
      fetchCalls
        .filter((c) => c.method === "PATCH" && c.url.includes("/messages/ack1"))
        .map(
          (c) =>
            (typeof c.body === "string" ? JSON.parse(c.body) : c.body).content,
        );

    let done = false;
    const p = runMidRunInterrupt(pi, ctx, "ch1", "m2").then(() => {
      done = true;
    });
    // abort fired, settle-wait running, tick armed on the queued ack
    // (one-line op status = prose, bare tick per v4 §2.3)
    jest.advanceTimersByTime(5000);
    expect(ackEdits()).toEqual(["[..] interrupting… 5s"]);

    ctx.isIdle = () => true;
    jest.advanceTimersByTime(50);
    await p;
    expect(done).toBe(true);
    // the queued text went through to pi
    expect(sent.some((s) => s.m.customType === "channel-inbound")).toBe(true);
    // tick stopped in finally -> no further edits
    const n = ackEdits().length;
    jest.advanceTimersByTime(10000);
    expect(ackEdits().length).toBe(n);
  });

  test("#28: /restart asks systemd for the env-configured unit, not hardcoded pi.service", async () => {
    const got: string[] = [];
    setSystemdRestartHookForTest((u) => {
      got.push(u);
    });
    process.env.PI_SERVICE = "banky-pi.service";
    try {
      await handleInbound(pi, inbound("/restart", "m1"), ctx);
      await tick();
      await waitOpShutdown();
    } finally {
      delete process.env.PI_SERVICE;
    }
    expect(got[0]).toBe("banky-pi.service");
  });

  test("#28: /restart asks systemd for the settings-configured unit (systemdUnit)", async () => {
    // beforeEach wrote tmp/.pi/settings.json with only channels — add the unit
    const s = path.join(tmp, ".pi", "settings.json");
    const cfg = JSON.parse(fs.readFileSync(s, "utf-8"));
    cfg.systemdUnit = "banky-pi.service";
    fs.writeFileSync(s, JSON.stringify(cfg));
    const got: string[] = [];
    setSystemdRestartHookForTest((u) => {
      got.push(u);
    });
    await handleInbound(pi, inbound("/restart", "m1"), ctx);
    await tick();
    await waitOpShutdown();
    expect(got[0]).toBe("banky-pi.service");
  });

  test("#28 partial: no respawn after ~15s -> watchdog closes the window, drains the queue, posts the RESOLVED unit", async () => {
    verboseOverride.set("ch1", 1); // verbose 1: the [queued] ack posts
    jest.useFakeTimers();
    const got: string[] = [];
    // restart hook that never settles: the unit never respawns
    setSystemdRestartHookForTest((u) => {
      got.push(u);
    });
    // F7 (PR2): capture the delayed self-exit instead of killing the
    // test runner (installed BEFORE the watchdog fires)
    const exits: number[] = [];
    setProcessExitHookForTest((c) => exits.push(c));
    const flush = async (n: number) => {
      for (let i = 0; i < n; i++) await Promise.resolve();
    };

    await handleInbound(pi, inbound("/restart", "m1"), ctx);
    await flush(10);
    expect(channelPosts().some((t) => t.includes("[..] restarting..."))).toBe(
      true,
    );

    // an inbound lands during the op -> queued behind the window
    await handleInbound(pi, inbound("hello", "m2"), ctx);
    await flush(10);
    expect(channelPosts().some((t) => t.includes("[queued] 1 in line"))).toBe(
      true,
    );

    // op shutdown chain at +300ms: restart requested, watchdog armed
    jest.advanceTimersByTime(300);
    await flush(30);
    expect(shutdowns).toBe(1);
    expect(got).toEqual(["pi.service"]); // resolved name

    // 14.9s later: the failure is not yet declared
    jest.advanceTimersByTime(14_999);
    expect(isCompacting("ch1")).toBe(true);
    expect(channelPosts().some((t) => t.includes("restart failed"))).toBe(
      false,
    );

    // ~15s: watchdog fires — process still alive, same window entry open
    jest.advanceTimersByTime(2);
    await flush(10);
    // The watchdog SYNCHRONOUSLY closed the window, deleted the op marker,
    // and posted the RESOLVED unit (the fetch mock records the post when
    // invoked). The re-waked inbound is in flight but parked on REAL
    // async hops (fs I/O): under fake timers its completion only arrives
    // if it happens to ride a 0ms fake timer, which is load/cold-cache
    // sensitive and flaked (issue #63: fresh-HOME runs fail
    // `expect(drained).toBeDefined()` ~1 in 4). So settle every
    // fake-timer assertion here first, then switch to REAL timers and let
    // the re-wake's fs I/O complete on the real event loop — the same
    // pattern the compaction fallback-timer test above uses.
    expect(isCompacting("ch1")).toBe(false); // op window closed
    expect(
      channelPosts().some((t) =>
        t.includes("restart failed - check unit pi.service"),
      ),
    ).toBe(true); // RESOLVED unit name in the channel
    // no stale marker left to settle some future boot
    expect(fs.existsSync(path.join(tmp, ".tmp", "op-marker.json"))).toBe(false);
    // F7 (PR2): the failed restart KILLS the process (delayed 500ms,
    // after the post lands) so systemd Restart=always actually respawns
    // 'pi -c' — a live process leaves the unit "active" forever.
    // The 500ms nudge trips only the exit: the next armed op tick is 5s
    // out.
    expect(exits).toEqual([]);
    jest.advanceTimersByTime(500);
    await flush(10);
    expect(exits).toEqual([1]);
    // Real timers: bounded poll of real event-loop turns until the
    // parked readFile completes and the message reaches pi.
    jest.useRealTimers();
    for (let i = 0; i < 200; i++) {
      if (
        sent.some(
          (s) =>
            s.m.customType === "channel-inbound" &&
            s.m.details?.body?.includes("hello"),
        )
      )
        break;
      await tick();
    }
    // queued inbound drained through pi (replay, not re-queue)
    const drained = sent.find(
      (s) =>
        s.m.customType === "channel-inbound" &&
        s.m.details?.body?.includes("hello"),
    );
    expect(drained).toBeDefined();
    expect(midTurnQueues.get("ch1")?.length ?? 0).toBe(0);
  });
});

describe("#28: systemd unit resolution (restart command)", () => {
  test("buildRestartCommand embeds the resolved unit, not a hardcoded one", () => {
    expect(buildRestartCommand("pi.service")).toBe(
      "sleep 3; systemctl --user restart pi.service",
    );
    expect(buildRestartCommand("banky-pi.service")).toBe(
      "sleep 3; systemctl --user restart banky-pi.service",
    );
  });

  test("resolveSystemdUnit defaults to pi.service", () => {
    const old = process.env.PI_SERVICE;
    delete process.env.PI_SERVICE;
    try {
      expect(resolveSystemdUnit("/nonexistent-cwd-x")).toBe("pi.service");
    } finally {
      if (old !== undefined) process.env.PI_SERVICE = old;
    }
  });

  test("env PI_SERVICE beats settings.json systemdUnit", () => {
    const tmpdir = fs.mkdtempSync(path.join(os.tmpdir(), "unit-test-"));
    fs.mkdirSync(path.join(tmpdir, ".pi"), { recursive: true });
    fs.writeFileSync(
      path.join(tmpdir, ".pi", "settings.json"),
      JSON.stringify({ systemdUnit: "from-settings.service" }),
    );
    process.env.PI_SERVICE = "from-env.service";
    try {
      expect(resolveSystemdUnit(tmpdir)).toBe("from-env.service");
    } finally {
      delete process.env.PI_SERVICE;
      fs.rmSync(tmpdir, { recursive: true, force: true });
    }
  });

  test("settings.json systemdUnit is honoured when env is unset", () => {
    const tmpdir = fs.mkdtempSync(path.join(os.tmpdir(), "unit-test-"));
    fs.mkdirSync(path.join(tmpdir, ".pi"), { recursive: true });
    fs.writeFileSync(
      path.join(tmpdir, ".pi", "settings.json"),
      JSON.stringify({ systemdUnit: "from-settings.service" }),
    );
    const old = process.env.PI_SERVICE;
    delete process.env.PI_SERVICE;
    try {
      expect(resolveSystemdUnit(tmpdir)).toBe("from-settings.service");
    } finally {
      if (old !== undefined) process.env.PI_SERVICE = old;
      fs.rmSync(tmpdir, { recursive: true, force: true });
    }
  });
});

describe("/diff (issue #7)", () => {
  let tmp: string;
  let realHome: string;
  let realFetch: typeof fetch;
  let pi: any;
  let ctx: any;
  let fetchCalls: { url: string; method: string; body?: any }[];

  const inbound = (body: string, id: string): ChannelMessage => ({
    channelId: "ch1",
    channelName: "Test",
    channelType: "discord",
    messageId: id,
    from: "u",
    fromId: "uid",
    body,
    timestamp: new Date().toISOString(),
    attachments: [],
    isRoom: false,
  });

  const replyContent = (): string => {
    const posts = fetchCalls.filter(
      (c) => c.method === "POST" && c.url.endsWith("/channels/ch1/messages"),
    );
    return JSON.parse(posts.at(-1)!.body).content;
  };

  beforeEach(async () => {
    tmp = fs.mkdtempSync(path.join(os.tmpdir(), "piscord-diff-"));
    realHome = process.env.HOME!;
    process.env.HOME = tmp; // isolate webdrop config + .pi from the real home
    fs.mkdirSync(path.join(tmp, ".pi"), { recursive: true });
    fs.writeFileSync(
      path.join(tmp, ".pi", "settings.json"),
      JSON.stringify({
        channels: [
          { id: "ch1", name: "Test", type: "discord", botToken: "tok1" },
        ],
      }),
    );
    fs.mkdirSync(path.join(tmp, ".config", "webdrop"), { recursive: true });
    fs.writeFileSync(
      path.join(tmp, ".config", "webdrop", "config.toml"),
      'server = "https://drop.test"\ntoken = "cfg-token"\n',
    );
    // real git repo with one uncommitted change
    const env = {
      ...process.env,
      GIT_AUTHOR_NAME: "t",
      GIT_AUTHOR_EMAIL: "t@t",
      GIT_COMMITTER_NAME: "t",
      GIT_COMMITTER_EMAIL: "t@t",
    };
    const { spawnSync } = await import("node:child_process");
    expect(spawnSync("git", ["init", "-q"], { cwd: tmp, env }).status).toBe(0);
    fs.writeFileSync(path.join(tmp, "a.txt"), "one\ntwo\n");
    spawnSync("git", ["add", "a.txt"], { cwd: tmp, env });
    expect(
      spawnSync("git", ["commit", "-q", "-m", "base"], { cwd: tmp, env })
        .status,
    ).toBe(0);
    fs.writeFileSync(path.join(tmp, "a.txt"), "one\nTWO\n");

    fetchCalls = [];
    pi = {
      registerMessageRenderer: () => {},
      registerTool: () => {},
      on: () => {},
      sendMessage: () => {},
    };
    ctx = {
      cwd: tmp,
      ui: { setStatus: () => {} },
      isIdle: () => true,
      hasPendingMessages: () => false,
      abort: () => {},
    };
    realFetch = globalThis.fetch;
    globalThis.fetch = (async (url: any, init?: any) => {
      const u = String(url);
      fetchCalls.push({
        url: u,
        method: init?.method ?? "GET",
        body: init?.body,
      });
      if (u.startsWith("https://drop.test/")) {
        return {
          ok: true,
          status: 201,
          json: async () => ({ url: "https://drop.test/feedd00d.html" }),
        };
      }
      return { ok: true, status: 200, json: async () => ({ id: "out1" }) };
    }) as any;
  });

  afterEach(() => {
    clearDiscordStatesForTest(); // no auto-react suppression leaks across tests
    clearDiscordStatesForTest();
    globalThis.fetch = realFetch;
    process.env.HOME = realHome;
    fs.rmSync(tmp, { recursive: true, force: true });
  });

  test("/diff publishes the working tree diff and replies with url + stats", async () => {
    await handleInbound(pi, inbound("/diff", "dm1"), ctx);
    // #87: the viewer URL ships bare after the fence (clickable), the
    // status line stays fenced
    expect(unwarped(replyContent())).toBe(
      `${fence("[ok] working tree · 1 file +1 -1 · ttl 7d")}\nhttps://drop.test/feedd00d.html`,
    );
    const up = fetchCalls.find((c) =>
      c.url.startsWith("https://drop.test/api/"),
    );
    expect(up).toBeTruthy();
    // uploaded payload is the self-contained viewer page
    const body = String(up!.body ?? "");
    expect(body).toContain("<!DOCTYPE html>");
    expect(body).toContain("working tree");
    expect(body).toContain("#0d1117");
    expect(body).toContain("TWO");
    expect(body).toContain('"del"');
  });

  test("/diff with fenced paste publishes without touching git", async () => {
    await handleInbound(
      pi,
      inbound(
        "/diff ```diff\n--- a/x\n+++ b/x\n@@ -1 +1 @@\n-a\n+b\n```",
        "dm2",
      ),
      ctx,
    );
    // #87: bare URL after the fence, same split as the worktree path
    expect(replyContent()).toBe(
      `${fence("[ok] pasted diff · 1 file +1 -1 · ttl 7d")}\nhttps://drop.test/feedd00d.html`,
    );
  });

  test("/diff with unresolvable arg replies usage", async () => {
    await handleInbound(pi, inbound("/diff hello\nworld", "dm3"), ctx);
    expect(unwarped(replyContent())).toBe(
      fence(
        "[!] usage: /diff [git-range | file | diff-paste] (default: working tree)",
      ),
    );
  });

  test("/diff without webdrop config reports the gap", async () => {
    fs.rmSync(path.join(tmp, ".config"), { recursive: true, force: true });
    await handleInbound(pi, inbound("/diff", "dm4"), ctx);
    expect(unwarped(replyContent())).toBe(
      fence(
        "[!] webdrop not configured (need WEBDROP_SERVER + WEBDROP_TOKEN or ~/.config/webdrop/config.toml)",
      ),
    );
  });
});

describe("v3 column budget (mockup3): every rendered frame line fits 40 cols", () => {
  const longAction =
    "bash cargo build --release --features everything,extra,long-flags -p some-crate";
  const longPath =
    "/home/monky/.pi-bg-wt/jarate/20260913-091303-15761/packages/bridge/channel/index.ts";

  // one constant per language: the TS fit budgets derive from the shared
  // 40-col law (frame.ts), never a local re-hardcode
  test("fit budgets derive from FRAME_COL_MAX (the 40-col law)", () => {
    expect(FRAME_COL_MAX).toBe(40);
    expect(TOOL_LINE_MAX).toBe(FRAME_COL_MAX);
    expect(TOOL_TEXT_MAX).toBe(FRAME_COL_MAX - "│ ├ ".length);
    expect(TOOL_TEXT_MAX).toBe(36);
  });

  test("runFrame(working) fits the budget at any call count or elapsed time", () => {
    const calls = Array.from(
      { length: 999 },
      (_, i) => `bash step-${i} --flag`,
    );
    for (const count of [0, 1, 9, 99, 999]) {
      for (const secs of [0, 5, 96, 9999]) {
        const frame = runFrame(
          "working",
          calls.slice(0, count),
          count,
          secs,
        ).split("\n");
        // header uses the k/m compact form (fmtTokensLC): raw 9999 secs
        // would be `9999s` (5 cols), the compact form is `10ks` (4 cols)
        expect(frame[0]).toBe(
          `┌ working · ${fmtTokensLC(count)} call${count === 1 ? "" : "s"} · ${fmtTokensLC(secs)}s`,
        );
        expect(frame.at(-1)).toBe("└");
        for (const line of frame) {
          expect(line.length).toBeLessThanOrEqual(TOOL_LINE_MAX);
        }
      }
    }
  });

  test("runFrame header: 6-digit count/secs compact, never > 40 cols (PR #64 review P3)", () => {
    // the review probe: `┌ working · 123456 calls · 999999s` = 34 cols
    for (const count of [1000, 9999, 123456, 999999]) {
      for (const secs of [1000, 9999, 123456, 999999]) {
        const header = runFrame("working", [], count, secs).split("\n")[0];
        expect(header.length).toBeLessThanOrEqual(TOOL_LINE_MAX);
      }
    }
    expect(runFrame("working", [], 123456, 999999).split("\n")[0]).toBe(
      "┌ working · 123k calls · 1000ks",
    );
    expect(runFrame("failed", [], 999999, 999999).split("\n")[0]).toBe(
      "┤ failed · 1000k calls · 1000ks",
    );
    expect(runFrame("done", [], 1000, 999).split("\n")[0]).toBe(
      "┌ done · 1k calls · 999s",
    );
  });

  test("toolActionText is frame-safe (<=36) and keeps verbs + filename tails", () => {
    const cases: Array<[string, Record<string, unknown>]> = [
      ["bash", { command: "bun run build 2>&1 | tail -4 && echo done" }],
      ["read", { path: longPath }],
      ["edit", { path: longPath }],
      ["write", { path: longPath }],
      ["web_search", { query: "discord embed column budget mobile" }],
      ["some_custom_tool", { a: "b".repeat(80) }],
    ];
    for (const [name, input] of cases) {
      const action = toolActionText(name, input);
      expect(action.length).toBeLessThanOrEqual(TOOL_TEXT_MAX);
      // a done-frame sub-step always fits the mobile budget
      expect(`│ ├ ${action}`.length).toBeLessThanOrEqual(TOOL_LINE_MAX);
    }
    // verb survives clipping; path clips the head so the filename survives
    expect(toolActionText("edit", { path: longPath })).toBe(
      "edit …ckages/bridge/channel/index.ts",
    );
    expect(
      toolActionText("bash", {
        command: "cargo test --features a,b,c --package some-long-crate-name",
      }),
    ).toBe("bash cargo test --features a,b,c --…");
  });

  test("runFrame(done): header + capped sub-steps + overflow line, all <= 40 cols", () => {
    const calls = Array.from({ length: 14 }, (_, i) => `bash step-${i} --flag`);
    const frame = runFrame("done", calls, 14, 96).split("\n");
    expect(frame[0]).toBe("┌ done · 14 calls · 96s");
    expect(frame[1]).toBe("├ … +6 earlier calls");
    expect(frame.length).toBe(2 + RUN_FRAME_MAX_STEPS + 1);
    expect(frame.at(-1)).toBe("└");
    // last 8 calls, in order, last sub-step on └
    expect(frame[2]).toBe("│ ├ bash step-6 --flag");
    expect(frame.at(-2)).toBe("│ └ bash step-13 --flag");
    for (const line of frame) {
      expect(line.length).toBeLessThanOrEqual(TOOL_LINE_MAX);
    }
  });

  test("runFrame(failed): failed runs swap the header to the ┤ failed glyph", () => {
    const frame = runFrame("failed", ["read x.ts"], 1, 5).split("\n");
    expect(frame[0]).toBe("┤ failed · 1 call · 5s");
    expect(frame.at(-1)).toBe("└");
    for (const line of frame) {
      expect(line.length).toBeLessThanOrEqual(TOOL_LINE_MAX);
    }
  });

  test("runFrame: working/done/failed share the body; only the header flips", () => {
    const calls = ["edit a.txt", "bash git push"];
    const w = runFrame("working", calls, 2, 7).split("\n");
    const d = runFrame("done", calls, 2, 96).split("\n");
    const f = runFrame("failed", calls, 2, 96).split("\n");
    expect(w[0]).toBe("┌ working · 2 calls · 7s");
    expect(d[0]).toBe("┌ done · 2 calls · 96s");
    expect(f[0]).toBe("┤ failed · 2 calls · 96s");
    // live-frame unification: sub-steps + closing bar are identical across
    // states — the done/failed morph changes the header line only
    expect(w.slice(1)).toEqual(d.slice(1));
    expect(w.slice(1)).toEqual(f.slice(1));
    expect(w[1]).toBe("│ ├ edit a.txt");
    expect(w[2]).toBe("│ └ bash git push");
  });

  test("runFrame(working): 0 calls renders header + closing bar only", () => {
    const frame = runFrame("working", [], 0, 10).split("\n");
    expect(frame).toEqual(["┌ working · 0 calls · 10s", "└"]);
  });

  test("runFrame(done): very long actions clip at the line budget", () => {
    const frame = runFrame("done", [longAction, "bash ok"], 2, 5).split("\n");
    for (const line of frame) {
      expect(line.length).toBeLessThanOrEqual(TOOL_LINE_MAX);
    }
    expect(frame.at(-2)).toBe("│ └ bash ok");
  });

  test("fit: a cut between a backslash and its escaped char shifts back one", () => {
    // cut lands after a lone escape backslash (odd run) -> shift back,
    // the dangling backslash drops, budget stays <= max
    expect(fit(`${"a".repeat(14)}\\bc`, 16)).toBe(`${"a".repeat(14)}…`);
    // even trailing run = complete escaped pair -> no shift
    expect(fit(`${"a".repeat(13)}\\\\"b`, 16)).toBe(`${"a".repeat(13)}\\\\…`);
    // no backslash at the cut -> unchanged behavior
    expect(fit("abcdef", 4)).toBe("abc…");
    // short strings pass through
    expect(fit("ab", 4)).toBe("ab");
  });

  test("toolActionText: clipped escaped args never end in a dangling backslash", () => {
    // 3-char key + 9 JSON quotes: the 36-col cut lands inside a
    // 2-char escape unit (the old clip left a dangling `\` before …)
    const action = toolActionText("t", { abc: `"`.repeat(9) });
    expect(action.length).toBeLessThanOrEqual(36);
    expect(action.endsWith("…")).toBe(true);
    // backslash run right before the ellipsis must be even (paired)
    const run = action.match(/(\\*)…$/)![1].length;
    expect(run % 2).toBe(0);
  });
});

// ─── wave 2c: #12 worktree, #13 ctx watch, #40 run usage, #44 jobs ──

describe("wave 2c bridge commands", () => {
  let tmp = "";
  let pi: any;
  let ctx: any;
  let handlers: Record<string, (...a: any[]) => any> = {};
  let sent: { m: any; o?: any }[] = [];
  let fetchCalls: { url: string; method: string; body?: any }[] = [];
  const realFetch = globalThis.fetch;
  const oldWtDir = process.env.PI_BG_WT_DIR;
  const oldGitEnv: Record<string, string | undefined> = {};

  const OWNER = "1000000000000000001";
  const base = (body: string, id: string, fromId: string): ChannelMessage => ({
    channelId: "ch1",
    channelName: "Test",
    channelType: "discord",
    messageId: id,
    from: fromId,
    fromId,
    body,
    timestamp: new Date().toISOString(),
    attachments: [],
    isRoom: false,
  });
  const inbound = (body: string, id: string) => base(body, id, OWNER);
  const otherInbound = (body: string, id: string) => base(body, id, "other");
  const posts = () =>
    fetchCalls
      .filter(
        (c) => c.method === "POST" && c.url.endsWith("/channels/ch1/messages"),
      )
      .map((c) => String(JSON.parse(c.body).content));
  const patches = () =>
    fetchCalls.filter((c) => c.method === "PATCH").map((c) => String(c.body));

  const setup = () => {
    handlers = {};
    sent = [];
    fetchCalls = [];
    midTurnQueues.clear();
    pendingAttachments.clear();
    verboseOverride.clear();
    lastRunUsage.value = null;
    setRuntimeStateDir(null);
    pi = {
      registerMessageRenderer: () => {},
      registerTool: () => {},
      on: (n: string, fn: any) => {
        handlers[n] = fn;
      },
      sendMessage: (m: any, o?: any) => {
        sent.push({ m, o });
      },
    };
    extension(pi);
    ctx = {
      cwd: tmp,
      ui: { setStatus: () => {} },
      isIdle: () => true,
      hasPendingMessages: () => false,
      abort: () => {},
    };
    fs.writeFileSync(
      path.join(tmp, ".pi", "settings.json"),
      JSON.stringify({
        channels: [
          {
            id: "ch1",
            name: "Test",
            type: "discord",
            botToken: "tok1",
            ack: true,
            ownerUserId: OWNER,
            forwardToolCalls: false,
          },
        ],
      }),
    );
  };

  const git = (cwd: string, ...args: string[]) =>
    execFileSync("git", args, {
      cwd,
      env: process.env,
      encoding: "utf8",
    }).trim();

  const initRepo = (dir: string) => {
    git(dir, "init", "-b", "main");
    fs.writeFileSync(path.join(dir, "base.txt"), "base\n");
    git(dir, "add", "base.txt");
    git(dir, "commit", "-m", "base commit");
  };

  beforeEach(() => {
    tmp = fs.mkdtempSync(path.join(os.tmpdir(), "jarate-2c-"));
    fs.mkdirSync(path.join(tmp, ".pi"), { recursive: true });
    setup();
    globalThis.fetch = (async (url: any, init?: any) => {
      fetchCalls.push({
        url: String(url),
        method: init?.method ?? "GET",
        body: init?.body,
      });
      return {
        ok: true,
        status: 200,
        json: async () => ({ id: "out1" }),
        text: async () => "",
      };
    }) as any;
    oldGitEnv.GIT_AUTHOR_NAME = process.env.GIT_AUTHOR_NAME;
    oldGitEnv.GIT_AUTHOR_EMAIL = process.env.GIT_AUTHOR_EMAIL;
    oldGitEnv.GIT_COMMITTER_NAME = process.env.GIT_COMMITTER_NAME;
    oldGitEnv.GIT_COMMITTER_EMAIL = process.env.GIT_COMMITTER_EMAIL;
    process.env.GIT_AUTHOR_NAME = "t";
    process.env.GIT_AUTHOR_EMAIL = "t@t";
    process.env.GIT_COMMITTER_NAME = "t";
    process.env.GIT_COMMITTER_EMAIL = "t@t";
    process.env.PI_BG_WT_DIR = path.join(tmp, "wt");
  });

  afterEach(async () => {
    clearDiscordStatesForTest(); // no auto-react suppression leaks across tests
    jest.useRealTimers();
    midTurnQueues.clear();
    pendingAttachments.clear();
    clearAllInterrupts();
    setInterruptCtx(null);
    setRuntimeStateDir(null);
    await handlers.agent_end?.({ messages: [] }, ctx);
    globalThis.fetch = realFetch;
    process.env.GIT_AUTHOR_NAME = oldGitEnv.GIT_AUTHOR_NAME;
    process.env.GIT_AUTHOR_EMAIL = oldGitEnv.GIT_AUTHOR_EMAIL;
    process.env.GIT_COMMITTER_NAME = oldGitEnv.GIT_COMMITTER_NAME;
    process.env.GIT_COMMITTER_EMAIL = oldGitEnv.GIT_COMMITTER_EMAIL;
    process.env.PI_BG_WT_DIR = oldWtDir;
    fs.rmSync(tmp, { recursive: true, force: true });
  });

  test("matchCommand: new 2c commands parse", () => {
    expect(matchCommand("/new-worktree")?.name).toBe("new-worktree");
    expect(matchCommand("/new-worktree main")?.arg).toBe("main");
    expect(matchCommand("/merge-worktree")?.name).toBe("merge-worktree");
    expect(matchCommand("/merge-worktree --squash")?.arg).toBe("--squash");
    expect(matchCommand("/usage last")?.arg).toBe("last");
    expect(matchCommand("/jobs kill 20260914-091714-3097")?.arg).toBe(
      "kill 20260914-091714-3097",
    );
    expect(matchCommand("/jobs tail 20260914-091714-3097 --n 5")?.arg).toBe(
      "tail 20260914-091714-3097 --n 5",
    );
    expect(matchCommand("/jobs")).toEqual({ name: "jobs", arg: undefined }); // bare /jobs: view, no arg
  });

  test("runUsageLine: pricing matches pi-token-cost.py (#40)", () => {
    expect(
      runUsageLine({
        turns: 1,
        input: 215_000,
        output: 1_800,
        cacheRead: 2_600,
        cacheWrite: 0,
      }),
    ).toBe("│ ~219.4k tok · ~$0.096");
    expect(
      runUsageLine({
        turns: 0,
        input: 0,
        output: 0,
        cacheRead: 0,
        cacheWrite: 0,
      }),
    ).toBeNull();
  });

  test("runFrame: trailing line sits before the closing bar, <= 40 cols", () => {
    const frame = runFrame(
      "done",
      ["bash bun test"],
      1,
      0,
      "│ ~219.4k tok · ~$0.096",
    );
    const lines = frame.split("\n");
    expect(lines[0]).toBe("┌ done · 1 call · 0s");
    expect(lines[1]).toBe("│ └ bash bun test");
    expect(lines[2]).toBe("│ ~219.4k tok · ~$0.096");
    expect(lines[3]).toBe("└");
    for (const l of lines) expect([...l].length).toBeLessThanOrEqual(40);
  });

  test("agent_end done frame carries the run usage line (#40)", async () => {
    verboseOverride.set("ch1", 1);
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    await handlers.turn_start(null, ctx);
    await handlers.tool_call(
      { toolName: "bash", input: { command: "bun test" } },
      ctx,
    );
    const fin = {
      role: "assistant",
      content: [{ type: "text", text: "done" }],
      usage: { input: 215_000, output: 1_800, cacheRead: 2_600, cacheWrite: 0 },
    } as any;
    await handlers.agent_end({ messages: [fin] }, ctx);
    const patch = patches().find((p) => p.includes("┌ done"));
    expect(patch).toBeDefined();
    const lines = String(JSON.parse(patch!).content).split("\n");
    // fenced frame: ``` / lines / ``` with the trailing usage line
    // right before the closing bar
    expect(lines.at(-2)).toBe("└");
    expect(lines.at(-3)).toBe("│ ~219.4k tok · ~$0.096");
    for (const l of lines.slice(1, -1))
      expect([...l].length).toBeLessThanOrEqual(32);
  });

  test("/usage last: empty before any run, then the last run's line (#40)", async () => {
    await handleInbound(pi, inbound("/usage last", "m1"), ctx);
    expect(posts().some((t) => t.includes("no completed run yet"))).toBe(true);
    await handleInbound(pi, inbound("hello", "m2"), ctx);
    await handlers.turn_start(null, ctx);
    await handlers.agent_end(
      {
        messages: [
          {
            role: "assistant",
            content: [{ type: "text", text: "hi" }],
            usage: { input: 1_000, output: 100, cacheRead: 0, cacheWrite: 0 },
          },
        ],
      },
      ctx,
    );
    await handleInbound(pi, inbound("/usage last", "m3"), ctx);
    const last = posts().find((t) => t.includes("usage · last run"));
    expect(last).toBeDefined();
    expect(last).toContain("- in: 1K");
    expect(last).toContain("- out: 100");
    expect(last).toContain("- est: $0.00");
    // markdown list, unfenced (Andryo 2026-10-18): summaries are normal
    // Discord markdown, no code fence, no width budget
    expect(last!.startsWith("```")).toBe(false);
  });

  test("/jobs: history-only view (drain declared, #279)", async () => {
    const home = path.join(tmp, "home");
    const art = path.join(home, ".pi-bg-art");
    fs.mkdirSync(art, { recursive: true });
    // fresh mtime: the fixture entry is the NEWEST and renders first
    fs.writeFileSync(
      path.join(art, "pi-bg-20260914-091714-3097-out.md"),
      "result\n",
    );
    const oldHome = process.env.HOME;
    const oldTmpDir = process.env.PI_BG_TMPDIR;
    process.env.HOME = home;
    process.env.PI_BG_TMPDIR = art; // jobTmpDir() reads the env var live
    try {
      // history is informational: open to any channel member
      await handleInbound(pi, otherInbound("/jobs", "m1"), ctx);
      const post = posts().find((t) => t.includes("20260914-091714-3097"));
      expect(post).toBeDefined();
      expect(post).toContain("- done ");
      // markdown list, unfenced (Andryo 2026-10-18)
      expect(post!.startsWith("```")).toBe(false);
      // json = machine output (fenced)
      await handleInbound(pi, inbound("/jobs json", "m2"), ctx);
      const jsonPost = posts()
        .filter((t) => t.startsWith("```"))
        .find((t) => t.includes('"history"'));
      expect(jsonPost).toBeDefined();
      // kill/tail died with the completion side: no wrapper output, the
      // arg is just ignored and the view renders
      await handleInbound(
        pi,
        inbound("/jobs kill 20260914-091714-3097", "m3"),
        ctx,
      );
      expect(posts().some((t) => t.includes("[ok] killed"))).toBe(false);
    } finally {
      process.env.HOME = oldHome;
      if (oldTmpDir === undefined) delete process.env.PI_BG_TMPDIR;
      else process.env.PI_BG_TMPDIR = oldTmpDir;
    }
  });

  test("/new-worktree + /merge-worktree: owner-only full cycle (#12)", async () => {
    initRepo(tmp);
    // non-owner: refused, never handed to pi as plain text
    await handleInbound(pi, otherInbound("/new-worktree", "m1"), ctx);
    expect(sent).toHaveLength(0);
    expect(loadWorktreeStateFile()).toBeNull();
    // owner: creates the worktree
    await handleInbound(pi, inbound("/new-worktree", "m2"), ctx);
    const ok = posts().find((t) => unwarped(t).includes("[ok] worktree "));
    expect(ok).toBeDefined();
    expect(ok!.startsWith("```")).toBe(true);
    expect(unwarped(ok!)).toContain("branch pi-bg/");
    expect(unwarped(ok!).replace(/ /g, "")).toContain(path.join(tmp, "wt"));
    const st = loadWorktreeStateFile();
    expect(st).not.toBeNull();
    expect(st!.branch).toMatch(/^pi-bg\/\d{8}-\d{6}-\d{4}$/);
    expect(st!.path).toBe(path.join(tmp, "wt", path.basename(tmp), st!.id));
    // a second /new-worktree while one is active: refused
    await handleInbound(pi, inbound("/new-worktree", "m3"), ctx);
    expect(
      posts().some((t) => unwarped(t).includes("[!] worktree already active")),
    ).toBe(true);
    // work on the worktree, then merge
    fs.writeFileSync(path.join(st!.path, "feature.txt"), "x\n");
    git(st!.path, "add", "feature.txt");
    git(st!.path, "commit", "-m", "feat");
    await handleInbound(pi, inbound("/merge-worktree", "m4"), ctx);
    const merged = posts().find((t) => unwarped(t).includes("[ok] merged "));
    expect(merged).toBeDefined();
    expect(unwarped(merged!)).toContain("into main (merge)");
    expect(fs.existsSync(path.join(tmp, "feature.txt"))).toBe(true);
    expect(fs.existsSync(st!.path)).toBe(false);
    expect(git(tmp, "branch", "--list", st!.branch)).toBe("");
    expect(loadWorktreeStateFile()).toBeNull();
  });

  test("/new-worktree: non-git repo is a [!] line; /merge-worktree with no state", async () => {
    // no git repo in tmp
    await handleInbound(pi, inbound("/new-worktree", "m1"), ctx);
    expect(
      posts().some((t) => unwarped(t).includes("[!] not a git repo")),
    ).toBe(true);
    await handleInbound(pi, inbound("/merge-worktree", "m2"), ctx);
    expect(
      posts().some((t) => unwarped(t).includes("[!] no active worktree")),
    ).toBe(true);
  });

  function loadWorktreeStateFile() {
    const p = path.join(tmp, ".tmp", "worktree.json");
    if (!fs.existsSync(p)) return null;
    try {
      return JSON.parse(fs.readFileSync(p, "utf8"));
    } catch {
      return null;
    }
  }

  describe("owner config: ownerUserIds list + no-owner detection", () => {
    test("ownerUserIds admits any listed user; legacy ownerUserId still works", () => {
      expect(isOwnerUser({ ownerUserIds: ["a", "b"] }, "b")).toBe(true);
      expect(isOwnerUser({ ownerUserIds: ["a"] }, "c")).toBe(false);
      // legacy single field keeps working (existing configs unaffected)
      expect(isOwnerUser({ ownerUserId: "uid" }, "uid")).toBe(true);
      expect(isOwnerUser({ ownerUserId: "uid" }, "other")).toBe(false);
      // both fields together: either matches
      expect(
        isOwnerUser({ ownerUserId: "uid", ownerUserIds: ["a"] }, "a"),
      ).toBe(true);
      // no owner configured (or no sender) admits nobody
      expect(isOwnerUser({}, "anyone")).toBe(false);
      expect(isOwnerUser({ ownerUserId: "uid" }, undefined)).toBe(false);
    });

    test("hasOwnerConfigured distinguishes absent from empty", () => {
      expect(hasOwnerConfigured({})).toBe(false);
      expect(hasOwnerConfigured({ ownerUserIds: [] })).toBe(false);
      expect(hasOwnerConfigured({ ownerUserIds: ["a"] })).toBe(true);
      expect(hasOwnerConfigured({ ownerUserId: "uid" })).toBe(true);
    });
  });
});

// ─────────────────────────────────────────────────────────────────────────
// #180: queued inbounds survive a process restart.
//
// The re-wake queue is in-memory and session_shutdown drains it on EVERY
// death, while the Discord cursor already advanced past the queued inbound
// at receipt — so a respawn never re-fetches it (2026-10-06 incident:
// pi-bg callback msg 1556883632919150653 queued 04:19:44, process
// restarted 04:19:52, callback never consumed).
//
//   option 2 (primary): the queued entry is mirrored into a per-channel
//     state file at queue time, pruned on commit/drop; session_shutdown
//     keeps draining memory (fast path) but keeps the file (survival
//     path); a real process start (reason "startup") drains the file back
//     into the queue and the normal agent_end re-wake delivers it.
//   option 1 (backstop): the same startup does one bounded history scan
//     (before=<cursor>) re-queueing undelivered machine-wake webhook
//     posts (webhook_id - the [bg: content prefix was never the gate).
//
// These tests model REAL process boundaries: fresh pi + fresh handlers,
// clearDiscordStatesForTest between "processes", persisted state files
// (cursor + rewake) are the only thing that crosses the boundary.
// ─────────────────────────────────────────────────────────────────────────
describe("restart-queue survival (#180): incident-shape e2e", () => {
  let tmp = "";
  let oldHome = "";
  const realFetch = globalThis.fetch;
  let script: {
    polls: any[][];
    scan: any[];
    calls: { url: string; method: string }[];
  };

  const rewakeDir = () => path.join(tmp, ".tmp");

  const inbound = (body: string, id: string): ChannelMessage => ({
    channelId: "ch1",
    channelName: "Test",
    channelType: "discord",
    messageId: id,
    from: "Beepy",
    fromId: "uid",
    body,
    timestamp: new Date().toISOString(),
    attachments: [],
    isRoom: false,
  });

  /** Raw REST machine-wake post (the 2026-10-21 de-prefix shape: empty
   *  content + one embed whose author starts `pi-bg`). */
  const bgRaw = (id: string) => ({
    id,
    webhook_id: "7000",
    content: "",
    embeds: [
      {
        author: { name: `pi-bg worker \u00b7 ${id}` },
        title: "worker \u00b7 OK",
        description: `task ${id} done`,
      },
    ],
    timestamp: new Date().toISOString(),
    author: { id: "7000", bot: true, username: "beepy" },
  });
  /** Raw REST restart-wake post (the bridge's own wake, 2026-10-21
   *  shape: empty content + the Author: pi-bg marker). */
  const wakeRaw = (id: string) => ({
    id,
    webhook_id: "7000",
    content: "",
    embeds: [
      {
        author: { name: "pi-bg restart-wake \u00b7 planned" },
        title: "restart-wake \u00b7 planned",
        description:
          "pi restarted as planned (clean stop) - back online. No in-flight pi-bg work.",
        footer: { text: "restart-wake" },
      },
    ],
    timestamp: new Date().toISOString(),
    author: { id: "7000", bot: true, username: "beepy" },
  });
  /** The bridge-built body for a raw machine-wake post (the
   *  serializeEmbeds shape - what the in-process handler sees). */
  const bgBody = (id: string) =>
    `<embed>\nAuthor: pi-bg worker \u00b7 ${id}\nTitle: worker \u00b7 OK\ntask ${id} done\n</embed>`;
  /** The edited machine-wake body (F2: an edit lands on the same id). */
  const bgBodyEdited =
    "<embed>\nAuthor: pi-bg worker \u00b7 2000\nTitle: worker \u00b7 OK\ntask 2000 done EDITED\n</embed>";

  /** One fake pi "process": fresh handler table + fresh send capture. */
  const mkProcess = () => {
    const handlers: Record<string, (...a: any[]) => any> = {};
    const sent: { m: any; o?: any }[] = [];
    const pi: any = {
      registerMessageRenderer: () => {},
      registerTool: () => {},
      on: (n: string, fn: any) => {
        handlers[n] = fn;
      },
      sendMessage: (m: any, o?: any) => {
        sent.push({ m, o });
      },
    };
    extension(pi);
    return { pi, handlers, sent };
  };

  const mkCtx = (idle: boolean): any => ({
    cwd: tmp,
    ui: { setStatus: () => {} },
    isIdle: () => idle,
    hasPendingMessages: () => false,
    abort: () => {},
    compact: () => {},
    modelRegistry: { getAvailable: () => [] },
    getContextUsage: () => undefined,
    model: { id: "cur", name: "Cur" },
    shutdown: () => {},
  });

  /** Flush microtasks + drive polls until pred() or timeout. */
  const waitFor = async (pred: () => boolean, ms = 2000) => {
    const t0 = Date.now();
    while (!pred()) {
      if (Date.now() - t0 > ms) throw new Error("waitFor: timeout");
      await new Promise((r) => setTimeout(r, 10));
      await pollDiscord("ch1");
    }
  };

  const customSends = (sent: { m: any }[]) =>
    sent.filter((s) => s.m?.customType === CHANNEL_MSG_TYPE);

  beforeEach(() => {
    tmp = fs.mkdtempSync(path.join(os.tmpdir(), "issue180-"));
    oldHome = process.env.HOME || "";
    process.env.HOME = path.join(tmp, "home");
    fs.mkdirSync(path.join(tmp, ".pi"), { recursive: true });
    fs.writeFileSync(
      path.join(tmp, ".pi", "settings.json"),
      JSON.stringify({
        channels: [
          {
            id: "ch1",
            name: "Test",
            type: "discord",
            enabled: true,
            channel: "111",
            botToken: "tok1",
            ownerUserId: "uid",
            ack: true,
          },
        ],
      }),
    );
    script = { polls: [[], [], []], scan: [], calls: [] };
    globalThis.fetch = (async (url: any, init?: any) => {
      const u = String(url);
      const method = init?.method ?? "GET";
      script.calls.push({ url: u, method });
      const json = (v: any) => ({
        ok: true,
        status: 200,
        json: async () => v,
        text: async () => JSON.stringify(v),
      });
      const notFound = () => ({
        ok: false,
        status: 204,
        json: async () => ({}),
        text: async () => "",
      });
      if (u.endsWith("/users/@me")) return json({ id: "9000" });
      if (method === "POST" && u.includes("/messages"))
        return json({ id: "w1" }); // wake + ack posts: fixed id
      if (u.includes("reactions")) return notFound();
      if (method === "DELETE") return notFound();
      if (u.includes("before=")) return json(script.scan); // #180 scan
      if (u.includes("after=")) return json(script.polls.shift() ?? []); // polls (FIFO)
      return json([]); // seed ?limit=1, guilds, dms, ...
    }) as any;
    setSystemdRestartHookForTest(() => {});
    setRuntimeStateDir(null);
  });

  afterEach(() => {
    clearDiscordStatesForTest();
    stopAllOpTicks();
    clearAllCompacting();
    clearAllInterrupts();
    resetRuntimeStateForTest();
    setInterruptCtx(null);
    setSystemdRestartHookForTest(null);
    for (const id of [...midTurnQueues.keys()])
      clearQueuedInbound(id, undefined, { keepFile: true });
    midTurnQueues.clear();
    queuedAcks.clear();
    pendingInterrupts.clear();
    heldChannels.clear();
    setRuntimeStateDir(null);
    process.env.HOME = oldHome;
    globalThis.fetch = realFetch;
    fs.rmSync(tmp, { recursive: true, force: true });
  });

  test("incident: callback queued mid-run, clean restart -> delivered exactly once", async () => {
    // ── Process 1: the callback lands while a run is live → queued ──
    const p1 = mkProcess();
    const ctx1 = mkCtx(false); // a run is in flight
    await p1.handlers.session_start?.(null, ctx1);
    await waitFor(() => p1.handlers.agent_end !== undefined);
    setChannelCursor("ch1", "1000");
    await handleInbound(p1.pi, inbound(bgBody("2000"), "2000"), ctx1, false);
    // delivery advances the cursor PAST the queued inbound (the incident)
    setChannelCursor("ch1", "2000");
    expect(midTurnQueues.get("ch1")?.length).toBe(1);
    // option 2: the entry is mirrored into the state file at queue time
    expect(
      loadRewakeQueue(rewakeDir(), "ch1").pending.map((p) => p.msg.messageId),
    ).toEqual(["2000"]);

    // the process dies (clean stop)
    await p1.handlers.session_shutdown?.();
    // fast path: memory drained…
    expect(midTurnQueues.get("ch1")).toBeUndefined();
    // survival path: the file is intact
    expect(
      loadRewakeQueue(rewakeDir(), "ch1").pending.map((p) => p.msg.messageId),
    ).toEqual(["2000"]);
    // (live state is dropped by the disconnects — assert the persisted file)
    expect(loadPersistedCursors(rewakeDir())["111"]).toBe("2000");

    // ── Process 2: respawn (reason "startup") ──
    clearDiscordStatesForTest();
    const p2 = mkProcess();
    const ctx2 = mkCtx(true); // idle
    script.polls = [[wakeRaw("w1")], [wakeRaw("w1")], [], []];
    script.scan = [];
    await p2.handlers.session_start?.({ reason: "startup" }, ctx2);
    // survival drain re-queued the callback before anything else ran
    expect(midTurnQueues.get("ch1")?.length).toBe(1);
    // the wake post comes in via the poll → direct send (idle)
    await waitFor(() =>
      customSends(p2.sent).some((s) =>
        String(s.m.details?.body ?? "").includes("Author: pi-bg restart-wake"),
      ),
    );
    // the wake run ends → re-wake delivers the survived callback
    await p2.handlers.agent_end?.({ type: "agent_end", messages: [] }, ctx2);
    const delivered = customSends(p2.sent).filter((s) =>
      String(s.m.details?.body ?? "").includes("Author: pi-bg worker · 2000"),
    );
    expect(delivered).toHaveLength(1); // exactly once
    // commit: pending pruned, id recorded for the scan dedupe
    const f2 = loadRewakeQueue(rewakeDir(), "ch1");
    expect(f2.pending).toEqual([]);
    expect(f2.delivered).toContain("2000");

    // ── Process 3: restart AGAIN (crash after delivery) ──
    clearDiscordStatesForTest();
    const p3 = mkProcess();
    const ctx3 = mkCtx(true);
    // the original callback post is STILL in history below the cursor —
    // the scan must NOT re-queue it (delivered set dedupe)
    script.polls = [[], [], []];
    script.scan = [bgRaw("2000")];
    await p3.handlers.session_start?.({ reason: "startup" }, ctx3);
    await new Promise((r) => setTimeout(r, 150));
    await pollDiscord("ch1");
    expect(customSends(p3.sent)).toHaveLength(0); // no wake (lock), no re-run
    expect(
      loadRewakeQueue(rewakeDir(), "ch1").pending.map((p) => p.msg.messageId),
    ).toEqual([]);
  });

  test("empty restart: no queued inbounds -> no rewake state file, no scan fetch", async () => {
    const p1 = mkProcess();
    const ctx1 = mkCtx(false);
    await p1.handlers.session_start?.(null, ctx1);
    await waitFor(() => p1.handlers.agent_end !== undefined);
    await p1.handlers.session_shutdown?.();
    const rewakeFile = path.join(rewakeDir(), "rewake-ch1.json");
    expect(fs.existsSync(rewakeFile)).toBe(false); // nothing was ever queued

    const p2 = mkProcess();
    const ctx2 = mkCtx(true);
    await p2.handlers.session_start?.({ reason: "startup" }, ctx2);
    await new Promise((r) => setTimeout(r, 150));
    await pollDiscord("ch1");
    expect(fs.existsSync(rewakeFile)).toBe(false); // drain+scan wrote nothing
    // no cursor was ever persisted → the scan issues no REST call at all
    expect(script.calls.some((c) => c.url.includes("before="))).toBe(false);
    expect(customSends(p2.sent)).toHaveLength(0);
  });

  test("option 1 backstop: cursor advanced, queue file lost → history scan re-queues", async () => {
    const p1 = mkProcess();
    const ctx1 = mkCtx(false);
    await p1.handlers.session_start?.(null, ctx1);
    await waitFor(() => p1.handlers.agent_end !== undefined);
    setChannelCursor("ch1", "1000");
    await handleInbound(p1.pi, inbound(bgBody("2000"), "2000"), ctx1, false);
    setChannelCursor("ch1", "2000");
    // a later (human) receipt advances the cursor past the callback —
    // the scan window (before=<cursor>) now contains it; human posts
    // are never scan candidates, so only the machine wake is re-queued
    setChannelCursor("ch1", "2001");
    fs.rmSync(path.join(rewakeDir(), "rewake-ch1.json"), { force: true });
    await p1.handlers.session_shutdown?.();
    expect(midTurnQueues.get("ch1")).toBeUndefined();

    const p2 = mkProcess();
    const ctx2 = mkCtx(true);
    // the post is in history below the cursor — the scan finds it
    script.polls = [[wakeRaw("w1")], [wakeRaw("w1")], [], []];
    script.scan = [bgRaw("2000")];
    await p2.handlers.session_start?.({ reason: "startup" }, ctx2);
    await waitFor(() =>
      customSends(p2.sent).some((s) =>
        String(s.m.details?.body ?? "").includes("Author: pi-bg restart-wake"),
      ),
    );
    await p2.handlers.agent_end?.({ type: "agent_end", messages: [] }, ctx2);
    expect(
      customSends(p2.sent).filter((s) =>
        String(s.m.details?.body ?? "").includes("Author: pi-bg worker · 2000"),
      ),
    ).toHaveLength(1); // delivered via the scan-re-queued entry
    const f2 = loadRewakeQueue(rewakeDir(), "ch1");
    expect(f2.pending).toEqual([]);
    expect(f2.delivered).toContain("2000");
  });

  test("migration arm: legacy [bg: content webhook post survives a restart (one release)", async () => {
    // In-flight channel history + dead-letter re-posts still carry the
    // pre-2026-10-21 shape (content "[bg:…", no embed). The scan gate
    // is webhook_id (isBgWebhook) and classification keeps the legacy
    // prefix arm one release — a legacy post must re-queue exactly like
    // the de-prefix shape.
    const p1 = mkProcess();
    const ctx1 = mkCtx(false);
    await p1.handlers.session_start?.(null, ctx1);
    await waitFor(() => p1.handlers.agent_end !== undefined);
    setChannelCursor("ch1", "1000");
    setChannelCursor("ch1", "3002"); // a later receipt advances past it
    await p1.handlers.session_shutdown?.();

    const p2 = mkProcess();
    const ctx2 = mkCtx(true);
    const legacyRaw = {
      id: "3001",
      webhook_id: "7000",
      content: "[bg:worker:OK] 3001",
      timestamp: new Date().toISOString(),
      author: { id: "7000", bot: true, username: "beepy" },
    };
    script.polls = [[], [], []];
    script.scan = [legacyRaw];
    await p2.handlers.session_start?.({ reason: "startup" }, ctx2);
    await new Promise((r) => setTimeout(r, 150));
    await pollDiscord("ch1");
    expect(
      loadRewakeQueue(rewakeDir(), "ch1").pending.map((p) => p.msg.messageId),
    ).toEqual(["3001"]); // re-queued, not dropped as a stray bot post
  });

  test("in-process /new//reload (reason != startup) clears the file, not just memory", async () => {
    const p1 = mkProcess();
    const ctx1 = mkCtx(false);
    await p1.handlers.session_start?.(null, ctx1);
    await waitFor(() => p1.handlers.agent_end !== undefined);
    setChannelCursor("ch1", "1000");
    await handleInbound(p1.pi, inbound(bgBody("2000"), "2000"), ctx1, false);
    await p1.handlers.session_shutdown?.(); // memory drained, file kept
    expect(
      loadRewakeQueue(rewakeDir(), "ch1").pending.map((p) => p.msg.messageId),
    ).toEqual(["2000"]);

    // in-process session restart (the /new and /reload path)
    clearDiscordStatesForTest();
    const p2 = mkProcess();
    const ctx2 = mkCtx(true);
    await p2.handlers.session_start?.({ reason: "reload" }, ctx2);
    await new Promise((r) => setTimeout(r, 50));
    // the /new-dropped queue must not resurrect on the next real restart
    expect(loadRewakeQueue(rewakeDir(), "ch1").pending).toEqual([]);
    expect(midTurnQueues.get("ch1")).toBeUndefined();
  });

  test("held channel: the buffer survives the restart (drained back into the held queue)", async () => {
    const p1 = mkProcess();
    const ctx1 = mkCtx(false);
    await p1.handlers.session_start?.(null, ctx1);
    await waitFor(() => p1.handlers.agent_end !== undefined);
    setChannelCursor("ch1", "1000");
    setHeld("ch1", true);
    await handleInbound(p1.pi, inbound(bgBody("2000"), "2000"), ctx1, false);
    setChannelCursor("ch1", "2000");
    await p1.handlers.session_shutdown?.();
    expect(midTurnQueues.get("ch1")).toBeUndefined(); // memory wiped
    // held channels skip the shutdown drain loop — file was never pruned
    expect(
      loadRewakeQueue(rewakeDir(), "ch1").pending.map((p) => p.msg.messageId),
    ).toEqual(["2000"]);

    clearDiscordStatesForTest();
    const p2 = mkProcess();
    const ctx2 = mkCtx(true);
    script.polls = [[], [], []];
    script.scan = [];
    await p2.handlers.session_start?.({ reason: "startup" }, ctx2);
    // the hold flag is persisted (channel-state.json) → re-held at start,
    // and the survived entry is back in the (held) channel's queue
    expect(isHeld({ id: "ch1", name: "Test", type: "discord" } as any)).toBe(
      true,
    );
    expect(midTurnQueues.get("ch1")?.length).toBe(1);
    expect(midTurnQueues.get("ch1")?.[0].msg.messageId).toBe("2000");
  });

  test("F1: op-window inbound after the drain + rewound cursor -> replay and survival drain deliver ONCE", async () => {
    // ── Process 1: restart-class op. The inbound lands AFTER the op
    // drained the queue but BEFORE process death (mirrored to the file,
    // cursor advances past it); the op rewinds the cursor to W.
    const p1 = mkProcess();
    const ctx1 = mkCtx(false); // a run is in flight
    await p1.handlers.session_start?.(null, ctx1);
    await waitFor(() => p1.handlers.agent_end !== undefined);
    setChannelCursor("ch1", "1000"); // W: pre-op cursor (rewind point)
    await handleInbound(p1.pi, inbound(bgBody("2000"), "2000"), ctx1, false);
    // receipt advances the cursor past the queued inbound
    setChannelCursor("ch1", "2000");
    expect(midTurnQueues.get("ch1")?.length).toBe(1);
    expect(
      loadRewakeQueue(rewakeDir(), "ch1").pending.map((p) => p.msg.messageId),
    ).toEqual(["2000"]);
    // the op rewinds the cursor to W before death (persisted)
    setChannelCursor("ch1", "1000");
    await p1.handlers.session_shutdown?.();
    // fast path: memory drained; survival path: file + rewound cursor
    expect(midTurnQueues.get("ch1")).toBeUndefined();
    expect(
      loadRewakeQueue(rewakeDir(), "ch1").pending.map((p) => p.msg.messageId),
    ).toEqual(["2000"]);
    expect(loadPersistedCursors(rewakeDir())["111"]).toBe("1000");

    // ── Process 2: respawn — the double-delivery window. The survival
    // drain re-queues 2000 from the file; the first poll (after=W)
    // replays the op window and delivers it directly. Its commit must
    // prune the drained IN-MEMORY copy too — not just the file copy.
    clearDiscordStatesForTest();
    const p2 = mkProcess();
    const ctx2 = mkCtx(true); // idle
    script.polls = [[bgRaw("2000")], [], []]; // first poll = the replay
    script.scan = [];
    await p2.handlers.session_start?.({ reason: "startup" }, ctx2);
    expect(midTurnQueues.get("ch1")?.length).toBe(1); // the drained copy
    await waitFor(() =>
      customSends(p2.sent).some((s) =>
        String(s.m.details?.body ?? "").includes("Author: pi-bg worker · 2000"),
      ),
    );
    // the replay run ends -> the re-wake must NOT pop the drained copy
    await p2.handlers.agent_end?.({ type: "agent_end", messages: [] }, ctx2);
    const delivered = customSends(p2.sent).filter((s) =>
      String(s.m.details?.body ?? "").includes("Author: pi-bg worker · 2000"),
    );
    expect(delivered).toHaveLength(1); // was 2 at 6753cec9 (replay + re-wake)
    expect(midTurnQueues.get("ch1")).toBeUndefined();
    const f2 = loadRewakeQueue(rewakeDir(), "ch1");
    expect(f2.pending).toEqual([]);
    expect(f2.delivered).toContain("2000");
  });

  test("F1 secondary: replay commits the id while the scan fetch is in flight -> exactly once (scan live-dedupes)", async () => {
    // Same op-window shape, plus the (fake) scan window contains the id:
    // a startup replay delivery that commits the id mid-scan-fetch must
    // not be re-queued by the scan (dedupe re-checked live at push time,
    // not only from the pre-fetch snapshot).
    const p1 = mkProcess();
    const ctx1 = mkCtx(false);
    await p1.handlers.session_start?.(null, ctx1);
    await waitFor(() => p1.handlers.agent_end !== undefined);
    setChannelCursor("ch1", "1000");
    await handleInbound(p1.pi, inbound(bgBody("2000"), "2000"), ctx1, false);
    setChannelCursor("ch1", "2000");
    setChannelCursor("ch1", "1000"); // op rewind, persisted
    await p1.handlers.session_shutdown?.();
    expect(
      loadRewakeQueue(rewakeDir(), "ch1").pending.map((p) => p.msg.messageId),
    ).toEqual(["2000"]);

    clearDiscordStatesForTest();
    const p2 = mkProcess();
    const ctx2 = mkCtx(true);
    script.polls = [[bgRaw("2000")], [], []]; // the replay delivers + commits
    script.scan = [bgRaw("2000")]; // the scan window also sees the id
    await p2.handlers.session_start?.({ reason: "startup" }, ctx2);
    expect(midTurnQueues.get("ch1")?.length).toBe(1); // the drained copy
    await waitFor(() =>
      customSends(p2.sent).some((s) =>
        String(s.m.details?.body ?? "").includes("Author: pi-bg worker · 2000"),
      ),
    );
    // the scan fetch (in flight during the replay commit) has landed
    await new Promise((r) => setTimeout(r, 150));
    // the scan must not have re-queued the committed id
    expect(midTurnQueues.get("ch1")).toBeUndefined();
    expect(
      loadRewakeQueue(rewakeDir(), "ch1").pending.map((p) => p.msg.messageId),
    ).toEqual([]);
    await p2.handlers.agent_end?.({ type: "agent_end", messages: [] }, ctx2);
    expect(
      customSends(p2.sent).filter((s) =>
        String(s.m.details?.body ?? "").includes("Author: pi-bg worker · 2000"),
      ),
    ).toHaveLength(1); // exactly once
  });

  test("F2: edit of a queued inbound rewrites the FILE copy — restart drains the edited msg", async () => {
    const p1 = mkProcess();
    const ctx1 = mkCtx(false); // a run is in flight
    await p1.handlers.session_start?.(null, ctx1);
    await waitFor(() => p1.handlers.agent_end !== undefined);
    setChannelCursor("ch1", "1000");
    await handleInbound(p1.pi, inbound(bgBody("2000"), "2000"), ctx1, false);
    setChannelCursor("ch1", "2000");
    expect(midTurnQueues.get("ch1")?.length).toBe(1);
    // the owner edits the queued message (MESSAGE_UPDATE route)
    expect(
      await updateQueuedInbound(ctx1, "ch1", "2000", bgBodyEdited, [], "uid"),
    ).toBe(true);
    // memory re-rendered AND the file copy rewritten (F2)
    expect(midTurnQueues.get("ch1")?.[0].msg.body).toBe(bgBodyEdited);
    expect(loadRewakeQueue(rewakeDir(), "ch1").pending[0].msg.body).toBe(
      bgBodyEdited,
    );
    await p1.handlers.session_shutdown?.();
    // the file kept the EDITED msg across the restart boundary
    expect(loadRewakeQueue(rewakeDir(), "ch1").pending[0].msg.body).toBe(
      bgBodyEdited,
    );

    clearDiscordStatesForTest();
    const p2 = mkProcess();
    const ctx2 = mkCtx(true);
    script.polls = [[], [], []];
    script.scan = [];
    await p2.handlers.session_start?.({ reason: "startup" }, ctx2);
    // the survival drain re-queues the EDITED body, not the stale one
    expect(midTurnQueues.get("ch1")?.[0].msg.body).toBe(bgBodyEdited);
  });

  test("crash with a live [queued] line: ack id survives in the file, restored + deleted exactly once", async () => {
    verboseOverride.set("ch1", 1); // verbose 1: the [queued] ack posts
    // ── Process 1: a HUMAN inbound queued mid-run; its [queued] ack
    // POST resolves (fake id "w1") and its id is mirrored into the
    // file. (#231 P2: machine-wake inbounds queue silently — no ack
    // line — so
    // the line-survival contract is exercised on the human entry; the
    // the machine-wake entry joins in the ack-less shape below.)
    const p1 = mkProcess();
    const ctx1 = mkCtx(false);
    await p1.handlers.session_start?.(null, ctx1);
    await waitFor(() => p1.handlers.agent_end !== undefined);
    setChannelCursor("ch1", "1000");
    await handleInbound(p1.pi, inbound("fix the thing", "2000"), ctx1, false);
    setChannelCursor("ch1", "2000");
    await waitFor(
      () =>
        queuedAcks.get("2000")?.ackId === "w1" &&
        loadRewakeQueue(rewakeDir(), "ch1").pending[0]?.ackId === "w1",
    );
    // an ACK-LESS machine-wake entry (the #231 P2 shape, and any pre-fix
    // writer: no ackId key on disk) joins the file — it must still
    // load and drain
    rewakeAddPending(rewakeDir(), "ch1", {
      msg: inbound(bgBody("3000"), "3000"),
      queuedAt: Date.now(),
    });
    const raw = JSON.parse(
      fs.readFileSync(path.join(rewakeDir(), "rewake-ch1.json"), "utf8"),
    ) as { pending: Array<Record<string, unknown>> };
    expect(raw.pending[0].ackId).toBe("w1");
    expect(raw.pending[1].ackId).toBeUndefined(); // no line on disk

    // ── CRASH: no session_shutdown. Memory (incl. the ack map) dies
    // with the process, the ack line stays in Discord, the file
    // survives — the only thing crossing the boundary
    clearDiscordStatesForTest();
    const p2 = mkProcess();
    const ctx2 = mkCtx(true);
    queuedAcks.clear(); // fresh process: the map is empty
    midTurnQueues.clear(); // module state a real respawn never carries
    script.polls = [[wakeRaw("w1")], [wakeRaw("w1")], [], []];
    script.scan = [];
    await p2.handlers.session_start?.({ reason: "startup" }, ctx2);
    // the survival drain re-queued BOTH entries (ack-less loads)…
    expect(midTurnQueues.get("ch1")?.length).toBe(2);
    // …and restored ONLY the entry whose ack survived, at its line
    // position — the machine-wake entry has no (nonexistent) line
    expect(queuedAcks.get("2000")?.ackId).toBe("w1");
    expect(queuedAcks.get("2000")?.pos).toBe(1);
    expect(queuedAcks.has("3000")).toBe(false);

    // the wake run ends -> the re-wake pop delivers the survived
    // inbound and consumes the restored ack
    await waitFor(() =>
      customSends(p2.sent).some((s) =>
        String(s.m.details?.body ?? "").includes("Author: pi-bg restart-wake"),
      ),
    );
    await p2.handlers.agent_end?.({ type: "agent_end", messages: [] }, ctx2);
    const delivered = customSends(p2.sent).filter((s) =>
      String(s.m.details?.body ?? "").includes("fix the thing"),
    );
    expect(delivered).toHaveLength(1);
    // the kept [queued] line is deleted EXACTLY ONCE: the crash left
    // it live (no shutdown fast path), the restored id is consumed —
    // no orphan, no double delete
    expect(
      script.calls.filter(
        (c) => c.method === "DELETE" && c.url.endsWith("/messages/w1"),
      ),
    ).toHaveLength(1);
    expect(queuedAcks.get("2000")).toBeUndefined();
    // the machine-wake entry is still queued (no line to delete) and the
    // delivered set now holds the committed id
    const f2 = loadRewakeQueue(rewakeDir(), "ch1");
    expect(f2.pending.map((p) => p.msg.messageId)).toEqual(["3000"]);
    expect(f2.delivered).toContain("2000");
  });
});

// ── #84: stale placeholder settlement (all exit paths) ──────────────────
//
// A placeholder (working frame, SPEC B live text, [queued] ack, in-flight
// interrupt, compact line) must reach a terminal state on EVERY exit path:
// interrupt, run end (any channel), channel switch, agent_end throw,
// shutdown, and process death (crash record settled at next startup).

describe("#84: placeholder settlement (all exit paths)", () => {
  let tmp = "";
  let pi: any;
  let ctx: any;
  let handlers: Record<string, (...a: any[]) => any> = {};
  let sent: { m: any; o?: any }[] = [];
  let fetchCalls: { url: string; method: string; body?: any }[] = [];
  let msgN = 0;
  const realFetch = globalThis.fetch;

  const CH1 = {
    id: "ch1",
    name: "Test",
    type: "discord",
    botToken: "tok1",
    ownerUserId: "uid",
    ack: true,
  };
  const CH2 = {
    id: "ch2",
    name: "Other",
    type: "discord",
    botToken: "tok2",
    ownerUserId: "uid",
    ack: true,
  };

  const inbound = (
    body: string,
    id: string,
    channelId = "ch1",
    channelName = "Test",
  ): ChannelMessage => ({
    channelId,
    channelName,
    channelType: "discord",
    messageId: id,
    from: "u",
    fromId: "uid",
    body,
    timestamp: new Date().toISOString(),
    attachments: [],
    isRoom: false,
  });

  const flush = async (n = 12) => {
    for (let i = 0; i < n; i++) await Promise.resolve();
  };

  const content = (c: (typeof fetchCalls)[number]) => {
    const b = typeof c.body === "string" ? JSON.parse(c.body) : (c.body ?? {});
    return b.content ?? "";
  };
  const posts = (ch = "ch1") =>
    fetchCalls
      .filter(
        (c) =>
          c.method === "POST" && c.url.includes(`/channels/${ch}/messages`),
      )
      .map(content);
  const editsTo = (id: string) =>
    fetchCalls
      .filter((c) => c.method === "PATCH" && c.url.includes(`/messages/${id}`))
      .map(content);
  const deleted = (id: string) =>
    fetchCalls.some(
      (c) =>
        c.method === "DELETE" &&
        c.url.includes(`/messages/${id}`) &&
        !c.url.includes("/reactions/"),
    );
  const file = () => path.join(tmp, ".tmp", "live-placeholders.json");

  beforeEach(() => {
    tmp = fs.mkdtempSync(path.join(os.tmpdir(), "p84-test-"));
    fs.mkdirSync(path.join(tmp, ".pi"), { recursive: true });
    fs.writeFileSync(
      path.join(tmp, ".pi", "settings.json"),
      JSON.stringify({ channels: [CH1] }),
    );
    handlers = {};
    sent = [];
    fetchCalls = [];
    msgN = 0;
    midTurnQueues.clear();
    queuedAcks.clear();
    verboseOverride.clear();
    pendingAttachments.clear();
    pi = {
      registerMessageRenderer: () => {},
      registerTool: () => {},
      on: (n: string, fn: any) => {
        handlers[n] = fn;
      },
      sendMessage: (m: any, o?: any) => {
        sent.push({ m, o });
      },
    };
    extension(pi);
    ctx = {
      cwd: tmp,
      ui: { setStatus: () => {} },
      isIdle: () => true,
      hasPendingMessages: () => false,
      abort: () => {},
      compact: () => {},
      modelRegistry: { getAvailable: () => [] },
      getContextUsage: () => undefined,
      model: { id: "cur", name: "Cur" },
      shutdown: () => {},
    };
    globalThis.fetch = (async (url: any, init?: any) => {
      fetchCalls.push({
        url: String(url),
        method: init?.method ?? "GET",
        body: init?.body,
      });
      let id = "out1";
      if (
        init?.method === "POST" &&
        /\/channels\/ch[12]\/messages$/.test(String(url))
      )
        id = `out${++msgN}`;
      return {
        ok: true,
        status: 200,
        json: async () => ({ id }),
        text: async () => "",
      };
    }) as any;
  });

  afterEach(async () => {
    clearDiscordStatesForTest();
    jest.useRealTimers();
    stopAllOpTicks();
    stopAllCompactTicks();
    clearAllCompacting();
    midTurnQueues.clear();
    queuedAcks.clear();
    clearAllInterrupts();
    setInterruptCtx(null);
    setRuntimeStateDir(null);
    resetRuntimeStateForTest();
    try {
      await handlers.agent_end?.({ messages: [] }, ctx);
    } catch {
      /* cleanup only */
    }
    globalThis.fetch = realFetch;
    fs.rmSync(tmp, { recursive: true, force: true });
  });

  // A second extension instance in the SAME process: module state survives
  // the "death", the closure state is fresh — exactly what a restart is.
  const secondInstance = () => {
    const pi2: any = {
      registerMessageRenderer: () => {},
      registerTool: () => {},
      on: (n: string, fn: any) => {
        handlers2[n] = fn;
      },
      sendMessage: (m: any, o?: any) => {
        sent2.push({ m, o });
      },
    };
    const handlers2: Record<string, (...a: any[]) => any> = {};
    const sent2: { m: any; o?: any }[] = [];
    extension(pi2);
    return { pi2, handlers2, sent2 };
  };

  test("interrupt mid-turn: the working frame reaches its terminal state (no frozen ticking count)", async () => {
    jest.useFakeTimers();
    verboseOverride.set("ch1", 2);
    await handlers.session_start?.(null, ctx); // configRoot for channel REST
    await handleInbound(pi, inbound("work", "m1"), ctx);
    ctx.isIdle = () => false; // a run is in flight
    await handlers.turn_start(null, ctx); // working frame (out1)
    await handlers.tool_call(
      { toolName: "bash", input: { command: "ls" } },
      ctx,
    );
    expect(editsTo("out1").some((t) => t.includes("working · 1 call"))).toBe(
      true,
    );

    // a second inbound lands mid-run -> queued + acked (out2)
    await handleInbound(pi, inbound("hello", "m2"), ctx);
    await flush();
    expect(posts().some((t) => t.includes("[queued] 1 in line"))).toBe(true);

    const p = runMidRunInterrupt(pi, ctx, "ch1", "m2");
    jest.advanceTimersByTime(5000); // interrupt tick edit on the ack
    expect(editsTo("out2").some((t) => t.includes("interrupting"))).toBe(true);

    // the aborted run ends while the interrupt is in flight
    const finMsg = {
      role: "assistant",
      content: [{ type: "text", text: "partial" }],
    };
    await handlers.agent_end({ messages: [finMsg] }, ctx);

    ctx.isIdle = () => true;
    jest.advanceTimersByTime(50);
    await flush();
    await p;

    // 1. the working frame was settled in place — a FINAL frame, not a
    //    frozen count that keeps ticking or never resolves
    expect(editsTo("out1").some((t) => t.includes("┌ done · 1 call"))).toBe(
      true,
    );
    // 2. the interrupt tick settled and the ack line was consumed
    expect(editsTo("out2").some((t) => t.includes("interrupted"))).toBe(true);
    expect(deleted("out2")).toBe(true);
    // 3. the spliced entry went through to pi as a fresh run (threaded)
    const rew = sent.find(
      (s) =>
        s.m.customType === "channel-inbound" &&
        s.m.details?.body?.includes("hello"),
    );
    expect(rew).toBeDefined();
    expect(rew!.m.details.messageId).toBe("m2");
    // 4. nothing ticks after the settle
    const n1 = editsTo("out1").length;
    const n2 = editsTo("out2").length;
    jest.advanceTimersByTime(30_000);
    await flush();
    expect(editsTo("out1").length).toBe(n1);
    expect(editsTo("out2").length).toBe(n2);
  });

  test("normal run end settles the frame and leaves no crash record", async () => {
    verboseOverride.set("ch1", 2);
    await handlers.session_start?.(null, ctx);
    await handleInbound(pi, inbound("work", "m1"), ctx);
    ctx.isIdle = () => false;
    await handlers.turn_start(null, ctx); // out1
    await handlers.tool_call(
      { toolName: "bash", input: { command: "ls" } },
      ctx,
    );
    // a live frame leaves a crash record behind (for the death case)
    expect(fs.existsSync(file())).toBe(true);
    expect(readLivePlaceholders()?.frame?.msgId).toBe("out1");

    const finMsg = {
      role: "assistant",
      content: [{ type: "text", text: "the answer" }],
    };
    await handlers.agent_end({ messages: [finMsg] }, ctx);
    await flush();

    expect(editsTo("out1").some((t) => t.includes("┌ done · 1 call"))).toBe(
      true,
    );
    expect(deleted("out1")).toBe(false); // calls > 0: morph, not delete
    expect(fs.existsSync(file())).toBe(false); // settled: no crash record
  });

  test("run end after lastActiveChannel moved settles the frame + live text on the RUN'S channel", async () => {
    fs.writeFileSync(
      path.join(tmp, ".pi", "settings.json"),
      JSON.stringify({ channels: [CH1, CH2] }),
    );
    verboseOverride.set("ch1", 1); // level 1: frame on essentials only
    verboseOverride.set("ch2", 1);
    await handlers.session_start?.(null, ctx);
    await handleInbound(pi, inbound("work", "m1"), ctx);
    ctx.isIdle = () => false;
    await handlers.turn_start(null, ctx);
    // a redirect writes -> essential -> a level-1 frame posts (out1 on ch1)
    await handlers.tool_call(
      { toolName: "bash", input: { command: "echo probe > /tmp/p" } },
      ctx,
    );
    expect(posts().some((t) => t.includes("┌ working"))).toBe(true);
    await handlers.message_end(
      {
        message: {
          role: "assistant",
          content: [
            { type: "text", text: "checking things" },
            { type: "toolCall", toolName: "read", arguments: {} },
          ],
        },
      },
      ctx,
    );
    await handlers.tool_call(
      { toolName: "read", input: { path: "a.txt" } },
      ctx,
    ); // live text out2 on ch1
    expect(posts().some((t) => t.includes("checking things"))).toBe(true);

    // a second channel's inbound flips lastActiveChannel mid-run
    await handleInbound(pi, inbound("other", "m2", "ch2", "Other"), ctx);
    await flush();

    const finMsg = {
      role: "assistant",
      content: [{ type: "text", text: "the answer" }],
    };
    await handlers.agent_end({ messages: [finMsg] }, ctx);
    await flush();

    // the frame was settled on ch1 (the run's channel), not ch2
    expect(editsTo("out1").some((t) => t.includes("┌ done"))).toBe(true);
    // the live text was deleted on ch1, not ch2
    const ltDelete = fetchCalls.find(
      (c) =>
        c.method === "DELETE" && c.url.includes("/channels/ch1/messages/out2"),
    );
    expect(ltDelete).toBeDefined();
    expect(fs.existsSync(file())).toBe(false);
  });

  test("channel switch at tool_call settles the old channel's frame in place", async () => {
    fs.writeFileSync(
      path.join(tmp, ".pi", "settings.json"),
      JSON.stringify({ channels: [CH1, CH2] }),
    );
    verboseOverride.set("ch1", 2);
    verboseOverride.set("ch2", 2);
    await handlers.session_start?.(null, ctx);
    await handleInbound(pi, inbound("work", "m1"), ctx);
    ctx.isIdle = () => false;
    await handlers.turn_start(null, ctx); // frame out1 on ch1
    await handlers.tool_call(
      { toolName: "bash", input: { command: "ls" } },
      ctx,
    );

    // ch2's inbound flips lastActiveChannel mid-run
    await handleInbound(pi, inbound("work2", "m2", "ch2", "Other"), ctx);
    await flush(); // ack out2 on ch2

    // the next tool call arrives for ch2: the display moves channels
    await handlers.tool_call(
      { toolName: "bash", input: { command: "pwd" } },
      ctx,
    );
    // the OLD channel's frame is settled in place (stopped), not frozen
    expect(editsTo("out1").some((t) => t.includes("┌ stopped · 1 call"))).toBe(
      true,
    );
    // the new channel posts its own frame (out3)
    expect(posts("ch2").some((t) => t.includes("┌ working"))).toBe(true);

    const finMsg = {
      role: "assistant",
      content: [{ type: "text", text: "the answer" }],
    };
    await handlers.agent_end({ messages: [finMsg] }, ctx);
    await flush();
    expect(editsTo("out3").some((t) => t.includes("┌ done"))).toBe(true);
  });

  test("agent_end that throws before the close block still settles the frame (finally net)", async () => {
    verboseOverride.set("ch1", 2);
    await handleInbound(pi, inbound("work", "m1"), ctx);
    ctx.isIdle = () => false;
    await handlers.turn_start(null, ctx); // 0-call frame out1
    expect(posts().some((t) => t.includes("┌ working · 0 calls"))).toBe(true);

    // messages={} makes sumRunUsage/failurePostText throw mid-handler —
    // the close block is skipped; the finally net must still settle.
    await expect(
      handlers.agent_end({ messages: {} } as any, ctx),
    ).rejects.toThrow();
    await flush();

    expect(deleted("out1")).toBe(true); // 0 calls: erase, no ghost box
  });

  test("process death with a live frame: the next startup morphs it to stopped", async () => {
    verboseOverride.set("ch1", 2);
    await handlers.session_start?.(null, ctx);
    await handleInbound(pi, inbound("work", "m1"), ctx);
    ctx.isIdle = () => false;
    await handlers.turn_start(null, ctx); // out1
    await handlers.tool_call(
      { toolName: "bash", input: { command: "ls" } },
      ctx,
    );
    const rec = readLivePlaceholders();
    expect(rec?.frame).toMatchObject({
      channelId: "ch1",
      msgId: "out1",
      calls: 1,
    });
    expect(rec?.frame?.body).toMatch(/^┌ working/);

    const { handlers2 } = secondInstance();
    simulateProcessDeathForTest(); // crash: no shutdown, no agent_end
    await handlers2.session_start?.({ reason: "startup" }, ctx);
    await flush();

    expect(editsTo("out1").some((t) => t.includes("┌ stopped · 1 call"))).toBe(
      true,
    );
    expect(deleted("out1")).toBe(false); // calls > 0: morph, not delete
    expect(fs.existsSync(file())).toBe(false); // record consumed
  });

  test("process death with a 0-call frame: the next startup deletes it", async () => {
    verboseOverride.set("ch1", 2);
    await handlers.session_start?.(null, ctx);
    await handleInbound(pi, inbound("work", "m1"), ctx);
    ctx.isIdle = () => false;
    await handlers.turn_start(null, ctx); // "working · 0 calls" out1
    expect(readLivePlaceholders()?.frame?.calls).toBe(0);

    const { handlers2 } = secondInstance();
    simulateProcessDeathForTest();
    await handlers2.session_start?.({ reason: "startup" }, ctx);
    await flush();

    expect(deleted("out1")).toBe(true);
    expect(editsTo("out1")).toEqual([]);
    expect(fs.existsSync(file())).toBe(false);
  });

  test("process death with live text: the next startup deletes it", async () => {
    verboseOverride.set("ch1", 1); // reads-only run: no frame, live text only
    await handlers.session_start?.(null, ctx);
    await handleInbound(pi, inbound("hello", "m1"), ctx);
    ctx.isIdle = () => false;
    await handlers.turn_start(null, ctx);
    await handlers.message_end(
      {
        message: {
          role: "assistant",
          content: [
            { type: "text", text: "let me check" },
            { type: "toolCall", toolName: "read", arguments: {} },
          ],
        },
      },
      ctx,
    );
    await handlers.tool_call(
      { toolName: "read", input: { path: "a.txt" } },
      ctx,
    );
    const rec = readLivePlaceholders();
    expect(rec?.liveText).toMatchObject({ channelId: "ch1", msgId: "out1" });
    expect(rec?.frame).toBeNull();

    const { handlers2 } = secondInstance();
    simulateProcessDeathForTest();
    await handlers2.session_start?.({ reason: "startup" }, ctx);
    await flush();

    expect(deleted("out1")).toBe(true);
    expect(fs.existsSync(file())).toBe(false);
  });

  test("process death mid-interrupt: the spliced entry is redelivered and its ack deleted", async () => {
    jest.useFakeTimers();
    await handlers.session_start?.(null, ctx); // configRoot for channel REST
    ctx.isIdle = () => false;
    const m2 = inbound("hello", "m2");
    queueMidTurnInbound("ch1", m2, "ctx\n\nhello", "discord/Test", "hello");
    queuedAcks.set("m2", { ackId: "ack1", fromId: "uid", pos: 1 });

    const p = runMidRunInterrupt(pi, ctx, "ch1", "m2");
    jest.advanceTimersByTime(100); // tick pending, settle-wait polling
    const rec = readLivePlaceholders();
    expect(rec?.interrupts).toHaveLength(1);
    expect(rec?.interrupts[0]).toMatchObject({
      channelId: "ch1",
      msgId: "m2",
      ackId: "ack1",
      display: "hello",
    });

    const { handlers2, sent2 } = secondInstance();
    simulateProcessDeathForTest();
    await handlers2.session_start?.({ reason: "startup" }, ctx);
    await flush();

    // the entry was spliced out of the queue before the crash — nobody
    // else would deliver it, so the startup redelivers it as a fresh run
    const redelivered = sent2.find(
      (s) =>
        s.m.customType === "channel-inbound" && s.m.details?.body === "hello",
    );
    expect(redelivered).toBeDefined();
    expect(redelivered!.m.details.messageId).toBe("m2");
    expect(deleted("ack1")).toBe(true); // ack line not orphaned
    expect(fs.existsSync(file())).toBe(false);

    // let the old instance's dangling interrupt settle (test hygiene)
    ctx.isIdle = () => true;
    jest.advanceTimersByTime(50);
    await flush();
    await p;
  });

  test("process death with an orphaned queued ack: the startup deletes the ack line", async () => {
    await handlers.session_start?.(null, ctx);
    ctx.isIdle = () => false;
    const m2 = inbound("hello", "m2");
    queueMidTurnInbound(
      "ch1",
      m2,
      "ctx\n\nhello",
      "discord/Test",
      "hello",
      false, // no interrupt armed
    );
    queuedAcks.set("m2", { ackId: "ack1", fromId: "uid", pos: 1 });
    persistLivePlaceholders();
    expect(readLivePlaceholders()?.queueAcks).toEqual([
      { channelId: "ch1", inboundId: "m2", ackId: "ack1", pos: 1 },
    ]);

    const { handlers2, sent2 } = secondInstance();
    simulateProcessDeathForTest(); // the queue ENTRY is gone with the process
    // #186 reality: queueMidTurnInbound mirrors the entry into the rewake
    // file, and the startup drain restores it — in which case the drain
    // OWNS the ack (settled at delivery). Drop the mirror to test the
    // orphaned-ack settle path (the line is settled at startup instead).
    fs.rmSync(path.join(tmp, ".tmp", "rewake-ch1.json"), { force: true });
    await handlers2.session_start?.({ reason: "startup" }, ctx);
    await flush();

    expect(deleted("ack1")).toBe(true); // the [queued] line is not orphaned
    // the entry itself is #180's scope (queued-inbound persistence) —
    // only the placeholder line is settled here
    expect(sent2.some((s) => s.m.customType === "channel-inbound")).toBe(false);
    expect(fs.existsSync(file())).toBe(false);
  });

  test("process death mid-compact: the startup settles the compact line", async () => {
    await handlers.session_start?.(null, ctx);
    await handleInbound(pi, inbound("/compact", "m1"), ctx);
    await flush();
    expect(posts().some((t) => t.includes("[..] compacting"))).toBe(true);
    expect(readLivePlaceholders()?.compacts).toEqual([
      { channelId: "ch1", msgId: "out1" },
    ]);

    const { handlers2 } = secondInstance();
    simulateProcessDeathForTest();
    await handlers2.session_start?.({ reason: "startup" }, ctx);
    await flush();

    expect(editsTo("out1").some((t) => t.includes("compact interrupted"))).toBe(
      true,
    );
    expect(fs.existsSync(file())).toBe(false);
  });

  test("in-process restart (reason != startup) does not settle; a real start does", async () => {
    verboseOverride.set("ch1", 2);
    await handlers.session_start?.(null, ctx);
    await handleInbound(pi, inbound("work", "m1"), ctx);
    ctx.isIdle = () => false;
    await handlers.turn_start(null, ctx);
    await handlers.tool_call(
      { toolName: "bash", input: { command: "ls" } },
      ctx,
    );
    expect(fs.existsSync(file())).toBe(true);

    const { handlers2 } = secondInstance();
    simulateProcessDeathForTest();
    const nBefore = fetchCalls.length;
    await handlers2.session_start?.(null, ctx); // in-process /new-style re-fire
    await flush();
    // untouched: no settle REST since the re-fire
    expect(
      fetchCalls
        .slice(nBefore)
        .some(
          (c) =>
            (c.method === "PATCH" || c.method === "DELETE") &&
            c.url.includes("/messages/out1"),
        ),
    ).toBe(false);
    expect(readLivePlaceholders()?.frame?.msgId).toBe("out1"); // record kept

    const nStart = fetchCalls.length;
    await handlers2.session_start?.({ reason: "startup" }, ctx);
    await flush();
    expect(
      fetchCalls
        .slice(nStart)
        .some(
          (c) =>
            c.method === "PATCH" &&
            c.url.includes("/messages/out1") &&
            String(c.body).includes("stopped"),
        ),
    ).toBe(true);
    expect(fs.existsSync(file())).toBe(false);
  });

  test("shutdown unlinks the crash record (a clean exit leaves nothing to settle)", async () => {
    verboseOverride.set("ch1", 2);
    await handlers.session_start?.(null, ctx);
    await handleInbound(pi, inbound("work", "m1"), ctx);
    ctx.isIdle = () => false;
    await handlers.turn_start(null, ctx);
    await handlers.tool_call(
      { toolName: "bash", input: { command: "ls" } },
      ctx,
    );
    expect(fs.existsSync(file())).toBe(true);

    await handlers.session_shutdown?.();
    await flush();

    expect(editsTo("out1").some((t) => t.includes("┌ stopped · 1 call"))).toBe(
      true,
    );
    expect(fs.existsSync(file())).toBe(false);
  });
});

// ─── Live marker (issue #191 M2: agent liveness) ─────────────────────────
// The bridge touches <LIVE_MARKER_DIR>/<uid> (0644) in a sticky 1777 dir
// once per poll cycle + at session start. The liveness paging on marker
// staleness now runs on the hall-monitor control plane (hm#59; the
// watchdog's fleet liveness sweep left with #280/3a). The class it
// exists for: a pi.service death with no in-flight tickets produced
// zero ticket-class events (2026-10-04 monky OOM incident, 33 min
// dark). /var/tmp (not /tmp): the pre-boot marker survives a reboot
// so a reboot classifies as BOOT-GAP instead of a fresh-boot alert.
// The touch is best-effort: a failure must never break the poll loop.
describe("live marker (#191 M2)", () => {
  const uid = process.getuid?.() ?? 0;

  test("LIVE_MARKER_DIR defaults to /var/tmp/jarate-live (the shared default root)", () => {
    expect(LIVE_MARKER_DIR).toBe("/var/tmp/jarate-live");
  });

  test("touchLiveMarker creates the sticky 1777 dir + 0644 <uid> file and returns the path", () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), "jarate-live-"));
    try {
      const before = Date.now();
      const f = touchLiveMarker(dir);
      expect(f).toBe(path.join(dir, String(uid)));
      expect(fs.statSync(dir).mode & 0o7777).toBe(0o1777);
      expect(fs.statSync(f as string).mode & 0o777).toBe(0o644);
      expect(
        Number(fs.readFileSync(f as string, "utf8")),
      ).toBeGreaterThanOrEqual(before);
    } finally {
      fs.rmSync(dir, { recursive: true, force: true });
    }
  });

  test("touchLiveMarker is idempotent: re-touch refreshes the same file, no churn", () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), "jarate-live-"));
    try {
      const f1 = touchLiveMarker(dir);
      const f2 = touchLiveMarker(dir);
      expect(f2).toBe(f1);
      expect(fs.readdirSync(dir)).toEqual([String(uid)]);
      expect(fs.statSync(dir).mode & 0o7777).toBe(0o1777);
    } finally {
      fs.rmSync(dir, { recursive: true, force: true });
    }
  });

  test("touchLiveMarker is best-effort: a non-creatable path returns null (never throws)", () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), "jarate-live-"));
    try {
      const blocker = path.join(dir, "blocker");
      fs.writeFileSync(blocker, "x"); // a file where the dir must go
      expect(touchLiveMarker(path.join(blocker, "sub"))).toBeNull();
    } finally {
      fs.rmSync(dir, { recursive: true, force: true });
    }
  });
});

describe("fleet dispatch run gate (hall-monitor #35 gut, 2026-10-20)", () => {
  let tmp = "";
  let pi: any;
  let ctx: any;
  let handlers: Record<string, (...a: any[]) => any> = {};
  let sent: { m: any; o?: any }[] = [];
  let fetchCalls: { url: string; method: string }[] = [];

  beforeEach(() => {
    tmp = fs.mkdtempSync(path.join(os.tmpdir(), "piscord-fleet-"));
    fs.mkdirSync(path.join(tmp, ".pi"), { recursive: true });
    fs.writeFileSync(
      path.join(tmp, ".pi", "settings.json"),
      JSON.stringify({
        channels: [
          {
            id: "ch1",
            name: "Test",
            type: "discord",
            botToken: "tok1",
            ownerUserId: "uid",
            ack: true,
          },
        ],
      }),
    );
    handlers = {};
    sent = [];
    midTurnQueues.clear();
    pendingAttachments.clear();
    verboseOverride.clear();
    resetRuntimeStateForTest();
    fetchCalls = [];
    pi = {
      registerMessageRenderer: () => {},
      registerTool: () => {},
      on: (n: string, fn: any) => {
        handlers[n] = fn;
      },
      sendMessage: (m: any, o?: any) => {
        sent.push({ m, o });
      },
    };
    extension(pi);
    ctx = {
      cwd: tmp,
      ui: { setStatus: () => {} },
      isIdle: () => true,
      hasPendingMessages: () => false,
      abort: () => {},
    };
    // URL-aware mock: channel "ch1" resolves to Discord id 111 via the DM
    // list; a persisted cursor seeds the #180 scan window. (The generic
    // {id:"out1"} shape is not iterable, so guild/DM traversal would fail.)
    globalThis.fetch = (async (url: any, init?: any) => {
      const u = String(url);
      fetchCalls.push({ url: u, method: init?.method ?? "GET" });
      let body: any = { id: "out1" };
      if (u.includes("/users/@me/guilds")) body = [];
      else if (u.includes("/users/@me/channels"))
        body = [{ name: "ch1", id: "111" }];
      else if (u.endsWith("/users/@me")) body = { id: "999" };
      else if (u.includes("/messages")) body = [];
      return {
        ok: true,
        status: 200,
        json: async () => body,
        text: async () => "",
      };
    }) as any;
    // persisted cursor (the previous process's last message): with it the
    // #180 startup scan has a window to fetch
    fs.mkdirSync(path.join(tmp, ".tmp"), { recursive: true });
    fs.writeFileSync(
      path.join(tmp, ".tmp", "channel-state.json"),
      JSON.stringify({ channels: {}, cursors: { "111": "123456" } }),
    );
  });

  afterEach(() => {
    clearDiscordStatesForTest();
    resetRuntimeStateForTest();
    delete process.env.PI_SESSION_ID;
  });

  test("isFleetRun: the wrapper's fleetwork- session id only", () => {
    expect(isFleetRun()).toBe(false); // unset (interactive shells)
    // pi sets PI_SESSION_ID to its own UUID for interactive sessions -
    // only the run wrapper's fleetwork-<ticket> pin gates the channel
    process.env.PI_SESSION_ID = "01a0ccd0-0e87-75ec-bfa0-7d382f5274";
    expect(isFleetRun()).toBe(false);
    process.env.PI_SESSION_ID = "fleetwork-35";
    expect(isFleetRun()).toBe(true);
  });

  test("fleet run: session_start gates ALL channel startup (no connect, no scan, no wake)", async () => {
    process.env.PI_SESSION_ID = "fleetwork-35";
    await handlers.session_start?.({ reason: "startup" }, ctx);
    // the pilot failure shape: dispatch runs 3/5/6 posted restart-wake
    // cards onto the interactive channel on start. Now: zero Discord
    // REST (no connect /users/@me, no #180 scan messages?before=),
    // zero outbound (no wake post).
    expect(fetchCalls).toHaveLength(0);
    expect(sent).toHaveLength(0);
  });

  test("interactive run: startup connect + #180 scan proceed unchanged", async () => {
    process.env.PI_SESSION_ID = "01a0ccd0-0e87-75ec-bfa0-7d382f5274";
    await handlers.session_start?.({ reason: "startup" }, ctx);
    // the #180 scan is fire-and-forget; give it loop turns to fetch
    for (
      let i = 0;
      i < 40 && !fetchCalls.some((c) => c.url.includes("before="));
      i++
    )
      await new Promise((r) => setTimeout(r, 10));
    // connect REST (bot identity) + the bounded startup history scan
    // (before=<persisted cursor>)
    expect(fetchCalls.some((c) => c.url.includes("/users/@me"))).toBe(true);
    expect(fetchCalls.some((c) => c.url.includes("before=123456"))).toBe(true);
  });
});
