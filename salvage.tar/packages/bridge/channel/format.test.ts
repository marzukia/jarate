import { describe, expect, test } from "bun:test";
import {
  collapseFenceTrailingBlankLines,
  convertInlineForDiscord,
  escapeBackticksInCodeBlocks,
  escapeDiscordFormatting,
  fmtTokensLC,
  formatMarkdownTables,
  hoistFencedUrls,
  limitHeadingDepth,
  mdToDiscord,
  serializeEmbeds,
  styleGuard,
  unnestCodeBlocksFromLists,
} from "./format";
import type { DiscordEmbed } from "./types";

// ─── limitHeadingDepth ─────────────────────────────────────────────────────

describe("limitHeadingDepth", () => {
  test("deeper than h3 becomes h3", () => {
    expect(limitHeadingDepth("#### deep")).toBe("### deep\n");
    expect(limitHeadingDepth("###### six")).toBe("### six\n");
  });
  test("h1-h3 untouched", () => {
    expect(limitHeadingDepth("# one")).toBe("# one");
    expect(limitHeadingDepth("## two")).toBe("## two");
    expect(limitHeadingDepth("### three")).toBe("### three");
  });
  test("headings inside code blocks untouched", () => {
    const input = "```\n#### not a heading\n```";
    expect(limitHeadingDepth(input)).toBe(input);
  });
});

// ─── unnestCodeBlocksFromLists ─────────────────────────────────────────────

describe("unnestCodeBlocksFromLists", () => {
  test("single item with code block", () => {
    const input = `- Item 1
  \`\`\`js
  const x = 1
  \`\`\``;
    expect(unnestCodeBlocksFromLists(input)).toBe(
      "- Item 1\n\n```js\nconst x = 1\n```",
    );
  });

  test("code in middle item only", () => {
    const input = `- Item 1
- Item 2
  \`\`\`js
  const x = 1
  \`\`\`
- Item 3`;
    expect(unnestCodeBlocksFromLists(input)).toBe(
      "- Item 1\n- Item 2\n\n```js\nconst x = 1\n```\n- Item 3",
    );
  });

  test("ordered list preserves numbering", () => {
    const input = `1. First item
   \`\`\`js
   const a = 1
   \`\`\`
2. Second item
3. Third item`;
    expect(unnestCodeBlocksFromLists(input)).toBe(
      "1. First item\n\n```js\nconst a = 1\n```\n2. Second item\n3. Third item",
    );
  });

  test("list without code blocks unchanged", () => {
    const input = `- Item 1
- Item 2
- Item 3`;
    expect(unnestCodeBlocksFromLists(input)).toBe(input);
  });

  test("text before and after code in same item", () => {
    const input = `- Start text
  \`\`\`js
  const x = 1
  \`\`\`
  End text`;
    expect(unnestCodeBlocksFromLists(input)).toBe(
      "- Start text\n\n```js\nconst x = 1\n```\n- End text",
    );
  });

  test("code block at root level unchanged", () => {
    const input = "```js\nconst x = 1\n```";
    expect(unnestCodeBlocksFromLists(input)).toBe(input);
  });

  test("content outside lists preserved", () => {
    const input = `# Heading

Some paragraph text.

- List item
  \`\`\`js
  const x = 1
  \`\`\`

More text after.`;
    const result = unnestCodeBlocksFromLists(input);
    expect(result).toContain("# Heading");
    expect(result).toContain("Some paragraph text.");
    expect(result).toContain("- List item");
    expect(result).toContain("```js\nconst x = 1\n```");
    expect(result).toContain("More text after.");
  });
});

// ─── formatMarkdownTables ──────────────────────────────────────────────────

describe("formatMarkdownTables", () => {
  test("table becomes key-value lines", () => {
    const input = `| Name | Age |
| ---- | --- |
| Bob  | 40  |
| Ann  | 30  |`;
    expect(formatMarkdownTables(input)).toBe(
      "**Name** Bob\n**Age** 40\n**Name** Ann\n**Age** 30",
    );
  });

  test("non-table content untouched", () => {
    expect(formatMarkdownTables("hello\n\nworld")).toBe("hello\n\nworld");
  });
});

// ─── escapes ───────────────────────────────────────────────────────────────

describe("escapeBackticksInCodeBlocks", () => {
  test("backticks inside code are escaped", () => {
    expect(escapeBackticksInCodeBlocks("```\nconst a = `x`\n```")).toBe(
      "```\nconst a = \\`x\\`\n```\n",
    );
  });
  test("backticks outside code untouched", () => {
    expect(escapeBackticksInCodeBlocks("use `x` here")).toBe("use `x` here");
  });
});

describe("escapeDiscordFormatting", () => {
  test("triple backticks escaped", () => {
    expect(escapeDiscordFormatting("a ``` b")).toBe("a \\`\\`\\` b");
  });
  test("plain text untouched", () => {
    expect(escapeDiscordFormatting("hello")).toBe("hello");
  });
});

// ─── serializeEmbeds ───────────────────────────────────────────────────────

describe("serializeEmbeds", () => {
  test("empty list", () => {
    expect(serializeEmbeds([])).toBe("");
  });

  test("full embed", () => {
    const embeds: DiscordEmbed[] = [
      {
        title: "T",
        description: "D",
        url: "https://x.test",
        author: { name: "A" },
        footer: { text: "F" },
        fields: [{ name: "f1", value: "v1" }],
      },
    ];
    expect(serializeEmbeds(embeds)).toBe(
      "<embed>\nAuthor: A\nTitle: T\nURL: https://x.test\nD\nf1: v1\nFooter: F\n</embed>",
    );
  });

  test("multiple embeds joined with blank line", () => {
    const embeds: DiscordEmbed[] = [{ title: "1" }, { title: "2" }];
    expect(serializeEmbeds(embeds)).toBe(
      "<embed>\nTitle: 1\n</embed>\n\n<embed>\nTitle: 2\n</embed>",
    );
  });
});

// ─── convertInlineForDiscord ───────────────────────────────────────────────

describe("convertInlineForDiscord", () => {
  test("headings become bold", () => {
    expect(convertInlineForDiscord("## Title")).toBe("**Title**");
  });
  test("links become text (<url>)", () => {
    expect(convertInlineForDiscord("see [docs](https://x.test) now")).toBe(
      "see docs (<https://x.test>) now",
    );
  });
  test("image refs untouched", () => {
    expect(convertInlineForDiscord("![alt](https://x.test/i.png)")).toBe(
      "![alt](https://x.test/i.png)",
    );
  });
  test("links inside code spans untouched", () => {
    expect(convertInlineForDiscord("code `[a](b)` here")).toBe(
      "code `[a](b)` here",
    );
  });
  test("code block content untouched", () => {
    const input = "```\n# not a heading\n[a](b)\n```";
    expect(convertInlineForDiscord(input)).toBe(input);
  });
  test("backticked bare URL becomes clickable <url>", () => {
    expect(convertInlineForDiscord("see `https://github.com/x/y` now")).toBe(
      "see <https://github.com/x/y> now",
    );
  });
  test("backticked http (no s) URL becomes clickable", () => {
    expect(convertInlineForDiscord("`http://100.64.0.1:1313/x/`")).toBe(
      "<http://100.64.0.1:1313/x/>",
    );
  });
  test("code span with non-URL content is left alone", () => {
    expect(convertInlineForDiscord("run `pip install x` here")).toBe(
      "run `pip install x` here",
    );
  });
  test("code span that is a URL plus trailing text is left alone", () => {
    // not a pure-URL span, so it stays a code span
    expect(convertInlineForDiscord("`https://x.test and more`")).toBe(
      "`https://x.test and more`",
    );
  });
  test("bare (unbackticked) URL stays a Discord autolink as-is", () => {
    expect(convertInlineForDiscord("see https://x.test now")).toBe(
      "see https://x.test now",
    );
  });
  test("URL inside a code block is NOT unwrapped", () => {
    const input = "```\n`https://x.test`\n```";
    expect(convertInlineForDiscord(input)).toBe(input);
  });
});

// ─── mdToDiscord pipeline ──────────────────────────────────────────────────

describe("mdToDiscord", () => {
  test("combined pipeline", () => {
    const input = [
      "#### Deep heading",
      "",
      "Some [link](https://x.test) text.",
      "",
      "| K | V |",
      "| - | - |",
      "| a | b |",
      "",
      "```js",
      "const s = `t`",
      "```",
    ].join("\n");
    const out = mdToDiscord(input);
    expect(out).toContain("**Deep heading**");
    expect(out).toContain("link (<https://x.test>) text.");
    expect(out).toContain("**K** a");
    expect(out).toContain("**V** b");
    expect(out).toContain("const s = \\`t\\`");
  });

  test("bare ordered-list marker is not dropped (F1)", () => {
    // marked parses "42." as an ordered list with an empty item; the list
    // branch used to render empty segments and the whole text vanished.
    expect(mdToDiscord("42.")).toBe("42.");
  });
});

// ─── collapseFenceTrailingBlankLines (STYLE.md 2.5) ────────────────────────

describe("collapseFenceTrailingBlankLines", () => {
  test("2 blank lines after closing fence + trailing text -> 0", () => {
    const input =
      "text:\n\n```\n┌ fleet\n└ monky : active\n```\n\n\nAll three on the new jarate.";
    expect(collapseFenceTrailingBlankLines(input)).toBe(
      "text:\n\n```\n┌ fleet\n└ monky : active\n```\nAll three on the new jarate.",
    );
  });

  test("message ending in a fence -> trailing newlines trimmed", () => {
    expect(collapseFenceTrailingBlankLines("```\nbox\n```\n\n")).toBe(
      "```\nbox\n```",
    );
  });

  test("blank lines INSIDE a fence are untouched", () => {
    const input = "```\na\n\nb\n```\n\ntext";
    expect(collapseFenceTrailingBlankLines(input)).toBe(
      "```\na\n\nb\n```\ntext",
    );
  });

  test("fenced block with lang tag toggles correctly", () => {
    const input = "```bash\necho hi\n```\n\n\nnext";
    expect(collapseFenceTrailingBlankLines(input)).toBe(
      "```bash\necho hi\n```\nnext",
    );
  });

  test("blank line between fence and following fence is kept (two blocks)", () => {
    const input = "```\na\n```\n\n```\nb\n```";
    // second block: its opening fence is NOT blank-line-separated anymore,
    // but both blocks stay intact
    expect(collapseFenceTrailingBlankLines(input)).toBe(
      "```\na\n```\n```\nb\n```",
    );
  });
});

// ─── fence width: NO 40-col wrap (Andryo 2026-10-18) ───────────────────────
// The width budget is scoped to the in-turn tool-call frames (index.ts).
// Fence CONTENT (machine output, raw logs, code) ships verbatim; Discord
// wraps monospace lines natively.

describe("fence width: no 40-col wrap (2026-10-18)", () => {
  test("long untagged fence lines ship verbatim (mdToDiscord end-to-end)", () => {
    const line =
      "aaaaaaaaaa bbbbbbbbbb cccccccccc dddddddddd eeeeeeeeee ffffffffff gggggggggg hhhhhhhhhh iiii";
    expect(line.length).toBe(92);
    const input = `\`\`\`\n${line}\n\`\`\``;
    expect(mdToDiscord(input)).toBe(input);
  });

  test("prose outside fences is untouched; no fence line is split", () => {
    const prose =
      "this is a plain prose line that is definitely longer than 40";
    expect(prose.length).toBeGreaterThan(40);
    const input = `${prose}\n\`\`\`\n${prose}\n\`\`\`\n${prose}`;
    expect(mdToDiscord(input)).toBe(input);
  });

  test("language-tagged fences (code) are verbatim", () => {
    // 2026-09-15 incident: a 54-col python snippet got frame-style wrapping
    // (mangled indentation) + mid-identifier client splits on mobile.
    const py = "        cached_tokens=num_cached_tokens,"; // 38 cols, one 30-char token
    const input = `\`\`\`python\ndef f(\n    enable_prompt_tokens_details: bool, ...):\n    if not enable_prompt_tokens_details:\n${py}\n\`\`\``;
    expect(mdToDiscord(input)).toBe(input);
  });

  test("unbreakable long word in a fence ships on one line", () => {
    const word = "x".repeat(120);
    const input = `\`\`\`\n${word}\n\`\`\``;
    expect(mdToDiscord(input)).toBe(input);
  });
});

describe("hoistFencedUrls", () => {
  test("bare url in fence -> hoisted to plain line after fence", () => {
    const out = mdToDiscord(
      "Dev link:\n\n```\nhttp://100.64.0.1:1313/posts/x/\n```\n\nMore text.",
    );
    // url must NOT be inside a fence; it appears as a bare line
    expect(out).toContain("http://100.64.0.1:1313/posts/x/");
    // and the fence is gone (urls-only fence dropped)
    const urlIdx = out.indexOf("http://100.64.0.1:1313/posts/x/");
    expect(out.slice(0, urlIdx)).not.toContain("```");
  });
  test("url mixed with code -> code kept in fence, url after", () => {
    const out = mdToDiscord("```\nport 1313\nhttp://x.test:1313/\n```");
    expect(out).toContain("port 1313");
    const urlIdx = out.indexOf("http://x.test:1313/");
    // url is after the closing fence
    const fenceClose = out.lastIndexOf("```");
    expect(urlIdx).toBeGreaterThan(fenceClose);
  });
  test("no url in fence -> unchanged", () => {
    const out = mdToDiscord("```\njust code here\n```");
    expect(out).toContain("```\njust code here\n```");
  });

  // issue #87: links in existing fences render as literal [label](url)
  // text or monospace strings - hoist them so Discord links them

  test("md link in fence -> hoisted, rendered as a link (#87)", () => {
    const out = mdToDiscord("```\n[report](https://drop.junkyard.sh/abc)\n```");
    // fence dropped (links-only), link re-emitted in the bridge's
    // `label (<url>)` form - clickable, and stable on a second pass
    expect(out).toBe("report (<https://drop.junkyard.sh/abc>)");
  });

  test("md link with trailing period in fence -> hoisted (#87)", () => {
    const out = mdToDiscord("```\n[report](https://x.test/a).\n```");
    expect(out).toBe("report (<https://x.test/a>)");
  });

  test("backticked url in fence -> hoisted bare (#87)", () => {
    // the pipeline escapes fence-body backticks first (\`url\`); the
    // hoisted line carries no backtick, no backslash
    const out = mdToDiscord("```\n`https://drop.junkyard.sh/abc`\n```");
    expect(out).toBe("https://drop.junkyard.sh/abc");
  });

  test("autolink in fence -> hoisted bare (#87)", () => {
    const out = mdToDiscord("```\n<https://x.test/file>\n```");
    expect(out).toBe("https://x.test/file");
  });

  test("mixed prose+url line in untagged fence -> url hoisted, rest stays (#87)", () => {
    const out = mdToDiscord("```\nreport: https://drop.junkyard.sh/abc\n```");
    expect(out).toBe("```\nreport:\n```\nhttps://drop.junkyard.sh/abc");
  });

  test("machine line with url in existing fence -> url hoisted (#87)", () => {
    const out = mdToDiscord(
      "```\n[ok] uploaded https://drop.junkyard.sh/abc\n```",
    );
    expect(out).toBe("```\n[ok] uploaded\n```\nhttps://drop.junkyard.sh/abc");
  });

  test("two urls on one fence line -> each shipped once, no duplicate (#87)", () => {
    const out = mdToDiscord(
      "```\nsee https://a.test/x and https://b.test/y\n```",
    );
    expect(out).toBe("```\nsee and\n```\nhttps://a.test/x\nhttps://b.test/y");
  });

  test("backticked url mixed with prose in fence -> span removed, no dangling backslash (#87)", () => {
    const out = mdToDiscord("```\nsee `https://x.test/file` ok\n```");
    expect(out).toBe("```\nsee ok\n```\nhttps://x.test/file");
  });

  test("tagged fence: mixed url line is code, left alone (#87)", () => {
    const input = "```bash\ncurl https://x.test/file\n```";
    expect(mdToDiscord(input)).toBe(input);
  });

  test("quoted url in untagged fence (JSON) stays fenced (#87)", () => {
    const input = '```\n{\n  "url": "https://x.test/a"\n}\n```';
    expect(mdToDiscord(input)).toBe(input);
  });

  test("unclosed fence with url -> no undefined line (#87)", () => {
    expect(hoistFencedUrls("```\nhttps://x.test/a")).toBe("https://x.test/a");
    expect(hoistFencedUrls("```\ncode\nhttps://x.test/a")).toBe(
      "```\ncode\nhttps://x.test/a",
    );
  });

  test("idempotent through the full pipeline (#87)", () => {
    const inputs = [
      "```\n[report](https://x.test/a)\n```",
      "```\n`https://x.test/a`\n```",
      "```\n<https://x.test/a>\n```",
      "```\nreport: https://x.test/a\n```",
      "```\n[ok] uploaded https://x.test/a\n```",
    ];
    for (const input of inputs) {
      const once = mdToDiscord(input);
      expect(mdToDiscord(once)).toBe(once);
    }
  });
});

// ─── styleGuard (STYLE.md 2.7 / 3.1 / 4.4) ─────────────────────────────────

describe("styleGuard", () => {
  const F = (s: string) => `\`\`\`\n${s}\n\`\`\``;

  test("bare tag line stays plain (v4: 3.1 tags are prose; tag-fencing retired 2026-10-19)", () => {
    expect(styleGuard("[ok] compacted: 153k -> 36k")).toBe(
      "[ok] compacted: 153k -> 36k",
    );
    expect(styleGuard("[!] compact failed: timeout")).toBe(
      "[!] compact failed: timeout",
    );
    expect(styleGuard("[queued] 2 in line")).toBe("[queued] 2 in line");
    expect(styleGuard("[-] stopped")).toBe("[-] stopped");
    expect(styleGuard("[..] resetting...")).toBe("[..] resetting...");
    expect(styleGuard("[new] session (context cleared)")).toBe(
      "[new] session (context cleared)",
    );
  });

  test("bare box frame -> one fence, not double-fenced", () => {
    const frame = "┌ ok · 20260923-092222-670483\n│ 1 call · 5s\n└";
    const once = styleGuard(frame);
    expect(once).toBe(F(frame));
    // second pass: content is inside the fence now - untouched
    expect(styleGuard(once)).toBe(once);
    // exactly two fence delimiters, nothing else
    expect(once.split("\n").filter((l) => l.trim() === "```")).toHaveLength(2);
  });

  test("consecutive tag lines stay plain (v4)", () => {
    const block = "[ok] step 1\n[!] step 2\n[-] step 3";
    expect(styleGuard(block)).toBe(block);
  });

  test("plain prose with no markers -> unchanged", () => {
    const prose =
      "All good. The deploy is done and the tests pass.\n\nShip it when ready.";
    expect(styleGuard(prose)).toBe(prose);
  });

  test("already-fenced content -> unchanged (no double fence)", () => {
    const fenced = "```\n[ok] compacted: 153k -> 36k\n```";
    expect(styleGuard(fenced)).toBe(fenced);
    const frame = "```\n┌ ok · run\n└\n```";
    expect(styleGuard(frame)).toBe(frame);
  });

  test("existing fences: >40-col body stays VERBATIM (no width wrap)", () => {
    // No width budget anywhere (Andryo 2026-10-18): tagged AND untagged
    // existing fences pass through untouched.
    const codeLine =
      "def f(enable_prompt_tokens_details: bool, cached_tokens: int) -> bool:";
    expect(codeLine.length).toBeGreaterThan(40);
    const tagged = `\`\`\`python\n${codeLine}\n\`\`\``;
    expect(styleGuard(tagged)).toBe(tagged);
    const untagged = `\`\`\`\n${codeLine}\n\`\`\``;
    expect(styleGuard(untagged)).toBe(untagged);
  });

  test("idempotent: styleGuard(styleGuard(x)) === styleGuard(x)", () => {
    const inputs = [
      "[ok] compacted: 153k -> 36k",
      "┌ ok · run\n│ 1 call\n└",
      "[ok] a\n[!] b",
      "plain prose line",
      "```\n[ok] x\n```",
      '{"a": 1, "b": [2, 3]}',
      "/home/monky/projects/jarate",
      "ERROR: unit failed",
      "prose before\n[!] bare mid\nprose after",
      "```\n└\n```\n\n[!] bare after fence",
    ];
    for (const input of inputs) {
      const once = styleGuard(input);
      expect(styleGuard(once)).toBe(once);
    }
  });

  test("JSON object lines -> fenced (single and multi-line)", () => {
    expect(styleGuard('{"a": 1, "b": [2, 3]}')).toBe(
      F('{"a": 1, "b": [2, 3]}'),
    );
    const multi = '{\n  "a": 1\n  "b": 2\n}';
    const out = styleGuard(multi);
    expect(out).toBe(F(multi));
  });

  test("bare path line -> fenced; prose mentioning a path stays", () => {
    expect(styleGuard("/home/monky/projects/jarate")).toBe(
      F("/home/monky/projects/jarate"),
    );
    expect(styleGuard("~/scripts/pi-bg")).toBe(F("~/scripts/pi-bg"));
    // a >40-col path stays fenced and ships verbatim (no width wrap)
    const longPath = "/home/monky/projects/jarate/packages/bridge";
    expect(styleGuard(longPath)).toBe(`\`\`\`\n${longPath}\n\`\`\``);
    expect(styleGuard("wrote /tmp/x.ts for you")).toBe(
      "wrote /tmp/x.ts for you",
    );
  });

  test("log line shapes -> fenced", () => {
    expect(styleGuard("2026-09-23 09:22:22 ERROR boom")).toBe(
      F("2026-09-23 09:22:22 ERROR boom"),
    );
    expect(styleGuard("ERROR: unit failed")).toBe(F("ERROR: unit failed"));
    // a >40-col error line ships fenced, verbatim (no width wrap)
    const longErr = "ERROR: Failed to start transient timer unit";
    expect(styleGuard(longErr)).toBe(`\`\`\`\n${longErr}\n\`\`\``);
    expect(styleGuard("Sep 23 09:22:22 host pi.service: msg")).toBe(
      F("Sep 23 09:22:22 host pi.service: msg"),
    );
    expect(styleGuard("2026-09-23 was a good day")).toBe(
      "2026-09-23 was a good day",
    );
  });

  test("machine line between prose -> fenced, prose untouched", () => {
    const out = styleGuard('a\n{"ok": true}\nc');
    expect(out).toBe(`a\n${F('{"ok": true}')}\nc`);
  });

  test("list items, headings, blockquotes, inline code -> untouched", () => {
    expect(styleGuard("- [ok] item in list")).toBe("- [ok] item in list");
    expect(styleGuard("1. [!] numbered item")).toBe("1. [!] numbered item");
    expect(styleGuard("# [ok] heading")).toBe("# [ok] heading");
    expect(styleGuard("> [!] quoted")).toBe("> [!] quoted");
    expect(styleGuard("`error: x` inline")).toBe("`error: x` inline");
    // markdown link is not a state tag
    expect(styleGuard("[text](https://x.test) stays")).toBe(
      "[text](https://x.test) stays",
    );
  });

  test("fenced lines ship verbatim (no 40-col budget)", () => {
    const long = `├ ${"a".repeat(60)}`;
    expect(styleGuard(long)).toBe(`\`\`\`\n${long}\n\`\`\``);
  });

  test("unclosed existing fence -> left alone (conservative)", () => {
    const input = "```\n[ok] still inside";
    expect(styleGuard(input)).toBe(input);
  });

  test("mdToDiscord: bare frame in LLM text gets fenced as last step", () => {
    const out = mdToDiscord("Done.\n\n┌ ok · 1 call · 5s\n└");
    expect(out).toContain(F("┌ ok · 1 call · 5s\n└"));
    // idempotent through the full pipeline
    expect(mdToDiscord(out)).toBe(out);
  });
});

// ─── styleGuard URL hoisting (issue #87) ─────────────────────────────────

describe("styleGuard: URLs on machine lines stay clickable (#87)", () => {
  const F = (s: string) => `\`\`\`
${s}
\`\`\``;

  test("tag+URL prose line ships plain, url clickable, no fence (v4)", () => {
    const url = "https://webdrop.example/f/abc123";
    const out = mdToDiscord(`[ok] uploaded: ${url}`);
    expect(out).toBe(`[ok] uploaded: ${url}`);
    expect(out).not.toContain("```");
  });

  test("autolink and backticked url on a tag line stay inline (v4: no fence, no hoist)", () => {
    expect(styleGuard("[ok] see <https://x.test/file> for details")).toBe(
      "[ok] see <https://x.test/file> for details",
    );
    // the pipeline already turns `url` spans into <url> (autolink form)
    expect(mdToDiscord("[ok] see `https://x.test/file` for details")).toBe(
      "[ok] see <https://x.test/file> for details",
    );
  });

  test("punctuation-only tag line with url -> left as prose (v4)", () => {
    // [!] carries no word char: pre-v4 this hoisted the URL and dropped
    // the fence; now the line is prose and ships as written (a bare URL
    // is clickable in Discord)
    expect(styleGuard("[!] https://x.test/a")).toBe("[!] https://x.test/a");
  });

  test("URL inside a quoted JSON value stays fenced, untouched", () => {
    const input = '{\n  "url": "https://x.test/a"\n}';
    expect(styleGuard(input)).toBe(F(input));
  });

  test("trailing sentence punctuation on a tag url line stays (v4: no hoist)", () => {
    expect(styleGuard("[ok] got it: https://x.test/a.")).toBe(
      "[ok] got it: https://x.test/a.",
    );
  });

  test("machine block: url lines hoist after the shared fence", () => {
    // hoisting still works for real machine lines (log shapes)
    const out = styleGuard(
      "2026-01-01T00:00:00 built https://x.test/a\n2026-01-01T00:00:01 log https://x.test/b",
    );
    const lines = out.split("\n");
    expect(lines.at(-1)).toBe("https://x.test/b");
    expect(lines.at(-2)).toBe("https://x.test/a");
    expect(lines.at(-3)).toBe("```");
    expect(lines[0]).toBe("```");
  });

  test("idempotent: styleGuard(styleGuard(x)) === styleGuard(x)", () => {
    const inputs = [
      "[ok] uploaded: https://x.test/a",
      "[ok] see <https://x.test/file> for details",
      "[!] https://x.test/a",
      '{\n  "url": "https://x.test/a"\n}',
      "```\n[ok] x\n```\nhttps://x.test/a",
    ];
    for (const input of inputs) {
      const once = styleGuard(input);
      expect(styleGuard(once)).toBe(once);
    }
  });

  test("mdToDiscord: /diff shape keeps the URL bare after the fence", () => {
    const status = "[ok] working tree · 3 files +12 -3 · ttl 7d";
    const url = "https://drop.junkyard.sh/abc123";
    // what the /diff case now posts: fenced status, bare URL after
    const posted = `\`\`\`
${status}
\`\`\`
${url}`;
    const out = mdToDiscord(posted);
    expect(out.split("\n").at(-1)).toBe(url);
    expect(out.slice(out.indexOf(url))).not.toContain("```");
    // the unfenced two-line /diff text lands the same way
    const out2 = mdToDiscord(`${status}\n${url}`);
    expect(out2.split("\n").at(-1)).toBe(url);
    expect(out2.slice(out2.indexOf(url))).not.toContain("```");
  });
});

// ─── fmtTokensLC (moved from ctxwatch.test.ts — the ctx boundary notice was
// gutted 2026-10-19; the formatter stays, /jobs frame + /compact ack use it) ──

describe("fmtTokensLC", () => {
  test("units: raw below 1k, k integer, m one decimal, lowercase", () => {
    expect(fmtTokensLC(0)).toBe("0");
    expect(fmtTokensLC(999)).toBe("999");
    expect(fmtTokensLC(104_480)).toBe("104k");
    expect(fmtTokensLC(262_144)).toBe("262k");
    expect(fmtTokensLC(999_999)).toBe("1000k");
    expect(fmtTokensLC(1_000_000)).toBe("1.0m");
    expect(fmtTokensLC(2_621_440)).toBe("2.6m");
    expect(fmtTokensLC(12_500_000)).toBe("13m");
    expect(fmtTokensLC(-1)).toBe("?");
    expect(fmtTokensLC(NaN)).toBe("?");
    expect(fmtTokensLC(Infinity)).toBe("?");
  });
});
