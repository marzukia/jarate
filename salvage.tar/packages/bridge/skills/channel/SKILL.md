---
name: channel
description: Transparent Discord channel bridge (bot token). Messages forwarded as plain user messages. Responses auto-forwarded to last active channel. Reply context injected on replies. LLM tools: send-file, todo, sleep, task, jarate. Commands: 22 slash commands + bare stop + ! shell (full list below).
---

# Channel — Transparent Bridge

## How it works

1. Message from channel → forwarded as normal user message
2. LLM responds normally (no idea it came from a channel)
3. Response auto-forwarded to the channel that last messaged

When the user replies to a message, its author + text arrive as a
`<replied-message>` block in the context — treat it as "the user is
pointing at this".

Other bots' messages are ignored (no echo loops). Outbound messages suppress accidental pings; a real
`<@id>` you write still pings.

## Commands

Anyone: `stop` / `/stop` (abort the in-flight run), `/btw <question>` (quick
side question, answer briefly), `/help` (list the commands).

Owner: `/status` (context-window usage, model, uptime), `/usage` (token
usage), `/context [N]` (window breakdown), `/reset` (start a new session),
`/restart` (restart pi, resume this session), `/undo [N]` / `/redo` (revert
assistant turns, reapply an undo), `/verbose [0|1|2|on|off]` (tool-call
detail level; bare `/verbose` toggles), `/hold [on|off]` (buffer inbound
messages), `/compact` (compact session context), `/handover` (compact via the
handover doc), `/model [name]` (switch or list models), `/jobs`
(history-only scan of the `~/.pi-bg-art` artifacts; post-#279 drain:
the `jarate-bg` launcher is a stub, rc 10; new work goes to
hall-monitor dispatch), `/todos` (channel todo board), `/sleep`
(list/cancel pending session wakes), `/tasks` (schedule prompt tasks),
`/diff [range|file]` (publish a diff to a viewer URL), `/new-worktree [ref]`
/ `/merge-worktree [squash]` (worktree flow).

`! <cmd>` runs a shell command in the working directory (owner, 60 s cap).

A trailing `. btw` on any message marks it as a side question; answer
briefly instead of diving into work.

Voice-note attachments (audio content type, duration, waveform, or
audio file extension) are labeled `[voice note: name (12s)]` inline and
delivered immediately. Other file attachments are downloaded on arrival
into a batch folder (20 MB per-file cap; oversize or failed downloads
are noted next to the file in the LLM message). By default, file-only
messages fire a turn immediately with a synthesized prompt like
`[user sent file without text: IMG_1358.jpg]`. Set `"bufferFileOnly": true`
on a channel to buffer them for up to 10 minutes until the user sends
follow-up text (the buffer posts one visible
`[buffered] N file(s) - send text to attach them` ack line; follow-up
with its own attachments also flushes the buffer; a batch that never
gets follow-up text is auto-flushed as a file-only turn at 10 minutes).

### Sending files to the user

Use the `send-file` tool to upload local file(s) to the channel in one
message (images show in a grid). 25 MB per-file cap. Prefer it over
webdrop links for anything small. Do not paste long paths instead.

## Reply threading

Inbound messages carry stable ids in the channel context: a single message
sets a `msgId=` attribute on the `<channel-ctx>` block, and a burst of
rapid-fire messages merges into one steer with a `[msgId=...]` marker on
each part. Replies thread to the last message of the burst by default.

When replying to a specific person in a multi-person thread, prefix your
reply with `<reply-to:MSGID>` using their id from the `[msgId=...]`
markers in the message (each burst part carries its own marker) or from
the `msgId=` attribute of the channel-ctx block. The tag is stripped
before sending. If the id does not match one of the triggering
messages, the reply falls back to the default (last) target.

## Stay in lane

In a shared channel, a message may be aimed at **another** agent or person.
You are **not required to reply** when any of these are true:

1. The message is a reply to someone else's turn (you are not the author of the quoted message).
2. Two other people (or an agent + a person) are mid-conversation and you are not addressed.
3. You are @-mentioned only to observe, not to act.

You **may** reply only when:

- you are explicitly addressed (by name or by being the one being asked),
- you have something directly relevant that the current speakers have not covered,
- or the sender @-mentions you and expects your input.

**No reply is a valid reply.** Do not pad the channel with acks, one-line
performances, or side commentary on a thread that is not yours. When in doubt
whether a message is for you, the default is to stay silent.

## Attribute precisely

When a `<replied-message author="X">` block is present, **X is the one who
spoke the quoted words.** Do not restate their statement as if it were the
current sender's. Do not attribute their words to anyone else. When you
reference what someone said, name the actual speaker (e.g. "sam said…", not
"you said…" when sam is the author). Misattribution is a comprehension error,
not a tone issue — read the `author=` tag before you quote or paraphrase.

## Configuration

```json
// .pi/settings.json
{
  "channels": [
    {
      "id": "disc-main",
      "name": "Main Discord",
      "type": "discord",
      "enabled": true,
      "channel": "123456789",
      "botToken": "your-bot-token",
      "default": true
    }
  ]
}
```

### Channel Fields

| Field | Required | Description |
|-------|----------|-------------|
| `id` | yes | Unique id |
| `name` | yes | Display name |
| `type` | yes | `"discord"` |
| `enabled` | yes | Connect on startup |
| `channel` | yes | Discord channel ID (numeric id or `#name`) |
| `botToken` | discord | Discord bot token |
| `ownerUserId` | optional | Discord user id allowed to use owner commands |
| `ownerUserIds` | optional | list of further owner ids (checked alongside `ownerUserId`) |
| `forwardToolCalls` | optional | `true` — tool calls/results included in auto-forwarded responses |
| `default` | optional | Active channel on startup |
| `startupMessage` | optional | Posted once when the channel connects |
| `ack` | optional | `false` — disable the 👀 ack reaction (default `true`) |

### Discord

Bot token + gateway `MESSAGE_CREATE` push, with a REST backfill poller (60 s
while the gateway is up, 5 s while it is down). Reacts with 👀 to
acknowledge new messages unless the channel sets `ack: false` (then the
typing indicator is the only "seen" signal). Responses auto-formatted for Discord (deep
headings clamped to ###, code blocks hoisted out of lists, tables →
`**header** value` lines, headings → bold, links → `text (<url>)`).

Embeds are serialized to readable text for the LLM. Oversized inbound
images are resized to max 2000 px / 4 MB when `sharp` is installed.
