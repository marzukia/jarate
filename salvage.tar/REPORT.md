# Triage: marzukia/jarate open issues (base main @45a68339)

## Summary

| Class | Count | Issues |
|---|---|---|
| DONE | 5 | #291 #281 #260 #235 #210 |
| SUPERSEDED | 19 | #257 #243 #236 #231 #225 #223 #219 #217 #211 #209 #208 #207 #206 #205 #204 #203 #202 #191 #57 |
| PARTIAL | 4 | #266 #263 #200 #197 |
| OPEN | 6 | #265 #264 #259 #256 #245 #193 |

All 34 open issues classified; none unclassified.

## Recommended CLOSE (24)

| # | Reason |
|---|---|
| 291 | fixed (f82fa69d / PR #298) |
| 281 | fixed (d27a64c7 / PR #289) |
| 260 | fixed (2b414675 / PR #271) |
| 235 | fixed (69c8720c / PR #238) |
| 210 | fixed (0c39f0c0, live in discord.ts) |
| 257 | drained (#279, kill/tail wrappers removed) |
| 243 | drained (#279, launcher retired; fix was cd434ec8) |
| 236 | drained (#279, jarate-wait marker gone) |
| 231 | drained (#279; P2 fix live, launcher side gone) |
| 225 | drained (#272, flaky test removed with the gut) |
| 223 | drained (#272, bg_session_file gone) |
| 219 | gutted (1d0c2fb3, bin/jarate-pat removed) |
| 217 | gutted (1d0c2fb3; fix was 91e93c61 + a79088eb) |
| 211 | gutted (1d0c2fb3; fix was 8db58e23) |
| 209 | gutted (1d0c2fb3, dual surface removed) |
| 208 | gutted (1d0c2fb3; fix was 8db58e23) |
| 207 | gutted (1d0c2fb3; fix was 0c39f0c0) |
| 206 | gutted (1d0c2fb3; fix was 8db58e23) |
| 205 | gutted (1d0c2fb3; fix was 5971a730) |
| 204 | gutted (1d0c2fb3; fix was 0c39f0c0) |
| 203 | gutted (1d0c2fb3; fix was 5971a730) |
| 202 | gutted (1d0c2fb3; fix was 9929c5c6) |
| 191 | hm#59 (watchdog left repo 274801fc; liveness centralised 1c7be7df) |
| 57 | retired (hall-monitor #35; root cause filed upstream) |

---

## Per-issue

### #291 handover: transcript drops the last completed turn (amnesia)
- CLASS: DONE
- EVIDENCE: f82fa69d (PR #298) implements all three asks — anchored capture through the last completed turn, pending-only last-ask, explicit "[mid-turn at compact]" marker (transcript.ts:200); 216 new test lines.
- ACTION: close.

### #281 docs: trim to the edge-runtime truth (text-only)
- CLASS: DONE
- EVIDENCE: d27a64c7 (PR #289, 2026-10-24) "docs: trim to the edge-runtime truth (text-only)"; DISPATCH.md is now the 5-line retirement banner + pointer page to hall-monitor's dispatch; test-count drift fixed (b033102c follow-up).
- ACTION: close.

### #266 index.ts god-file split (6969 lines)
- CLASS: PARTIAL
- EVIDENCE: the 5-module pure move landed — d8015a3f (PR #273, 2026-10-28): index.ts 6969→3815 non-blank; commands.ts (1273 L), live.ts (478), queue.ts (445), restart-ops.ts (675), tools.ts (457) all present; size-ratchet.json is the permanent guard (0843b860 / #268).
- REMAINING: index.ts still 3959 lines (3815 non-blank, at ratchet budget); inbound handler / send-to-pi / web-status concerns still in index.ts; the issue explicitly tracks this remainder.
- ACTION: keep open as tracking issue; ratchet guards re-bloat.

### #265 Dead-code sweep (11 items)
- CLASS: OPEN
- EVIDENCE: all 11 items still present at HEAD — tap-flow survivors interactionUserName/replyInteraction/deleteDeferredAck (discord.ts:1201/1698/1739), ChannelStatus (types.ts:126) + ChannelSettings (types.ts:56), format.ts internal-only exports (wholeLinkLine, STYLE_*_RE, extractMachineUrls — no external imports), getDiscordChannelName (discord.ts:1148), rerunPath (undo.ts:846), getVoiceAttachmentMatchReason (voice.ts:27), censor.ts exports (defaultRegistryPath/loadRegistry/clearCensorWarns), stacked doc comments (types.ts:185-199).
- ACTION: keep open; low priority (one medium: tap-flow survivors).

### #264 discord.ts split (2.1k lines, 6 concerns)
- CLASS: OPEN
- EVIDENCE: discord.ts still 2103 lines (1969 non-blank, ratchet budget 1969); no discord-rest/discord-gateway/discord-state modules; SLASH_COMMANDS metadata still in discord.ts:1766-1900.
- ACTION: keep open; medium priority (mechanical, large diffs; discord.test.ts is the safety net).

### #263 TS connascence/DRY (24 findings)
- CLASS: PARTIAL
- EVIDENCE: the mcp-tools collision-guard finding is resolved — extensions/mcp-tools.ts rewritten as the MCP bridge (279 L), hardcoded builtin set gone.
- REMAINING: 23 of 24 findings — 429 retry loop duplicated (discord.ts:72-110 + 116-147), settings cascade hand-rolled ×4 (no readSettingsCascade), handover markdown scraping (liveInFlightLine/boardSummaryLine still parse jobs/todos output, handover.ts:1059/1103), prompt-framing tag contract, DISCORD_API literal ×2 (discord.ts:28 + restart-wake.ts:61), HOME ×5 variants (undo.ts:57/625, worktree.ts:147, jobs.ts:38), env naming 3 eras, spawn idiom ×5, fence builders, git wrappers, multipart cap asymmetry, webdrop toml parser, JARATE_COMMANDS, pricing duplication, age formatter, firstLine, suffix detectors, state-file naming.
- ACTION: keep open; low-medium priority.

### #260 Track pi-restart in the repo + install.sh
- CLASS: DONE
- EVIDENCE: 2b414675 (PR #271, 2026-10-28) "feat(dispatch): track pi-restart in repo + link it in install.sh"; dispatch/pi-restart exists in the repo; install.sh:16 links {~/.local/bin,~/scripts}/pi-restart.
- ACTION: close.

### #259 Single bg-wake classifier module
- CLASS: OPEN
- EVIDENCE: 3 divergent classifiers still at HEAD — isBgWebhook (discord.ts:592, raw payload), isBgCallbackBody (todos.ts:264, serialized body), isHumanInbound partial re-derivation (handover.ts:528); no bg-wake.ts module; the jarate-bg stub header's claim that isBgWebhook lives in format.ts is stale (it is in discord.ts).
- ACTION: keep open; medium priority (behavior-preserving if extracted verbatim).

### #257 /jobs kill|tail: call jarate-bg-kill/-tail directly
- CLASS: SUPERSEDED
- EVIDENCE: /jobs kill|tail wrappers removed with the drain — jobs.ts:7 "kill/tail wrappers (spawn jarate-bg-kill/-tail) are removed with the completion side"; jarate-bg-tail/-kill gone (dispatch/jarate-bg stub header); /jobs is history-only.
- ACTION: close with cross-ref to #279 drain / hall-monitor #35.

### #256 Command names single source (4 divergent copies)
- CLASS: OPEN
- EVIDENCE: 4 copies still at HEAD — matchCommand regex (commands.ts:112), SLASH_COMMANDS (discord.ts:1766), runChannelCommand switch (commands.ts), test pin (discord.test.ts:867-890); no COMMAND_NAMES SSOT, no set-equality test between regex alternates and SLASH_COMMANDS.
- ACTION: keep open; high priority (silent degradation of an entire command class).

### #245 Harden session_compact / restart-op deferred paths (3 stale-ctx sites)
- CLASS: OPEN
- EVIDENCE: all 3 sites still unaddressed at HEAD — F1: maybeHandoffRestart's first statement is still an unguarded ctx.cwd (restart-ops.ts:573); the void call has no .catch (handoffRestartForSize's try/catch only catches sync throws — the #244 comment at index.ts:3271-3276 explicitly warns that an async throw rejects, it does not hit the try/catch). F2: scheduleOpShutdown IIFE still has no .catch (restart-ops.ts:403-443). F3: setTimeout(drainQueuedAfterCompact) still unguarded (index.ts:2736; sync fn, first statement ctx.isIdle()). The #244 reference pattern (guarded ctx read + .catch) exists in maybeAutoCompactByToken/autoCompactByToken (index.ts:3266-3310) but is not applied to these sites.
- ACTION: keep open; medium priority (latent non-zero exit at pi -p run end).

### #243 jarate-bg: run's pi hangs after completion, cap slot stuck
- CLASS: SUPERSEDED
- EVIDENCE: fix landed cd434ec8 (2026-10-19) "delivered webhook frees the cap slot (ZOMBIE) + scrub run identity"; the launcher was then retired (293c0722 / #272 gut; #279 drain declared — zero in-flight runs fleet-wide); the cap-slot mechanism is gone; fleetwork is now the dispatch.
- ACTION: close with cross-ref to hall-monitor #35 / #279.

### #236 /hold off drain bypasses in-turn-consumed marker
- CLASS: SUPERSEDED
- EVIDENCE: the in-turn-consumed marker was removed with jarate-wait, its only producer (queue.ts:218 comment, #279 drain); the /hold off path (popChannelQueuedInbound, queue.ts:321) no longer needs the marker check.
- ACTION: close with cross-ref to #279.

### #235 deploy: pre-deploy gate exceeds TimeoutStartSec=600 (livelock)
- CLASS: DONE
- EVIDENCE: 69c8720c (PR #238) "deploy: TimeoutStartSec=1800 + SIGTERM fail-recording" — deploy/jarate-deploy.service:12 TimeoutStartSec=1800; deploy.sh TERM trap records the fail so the 3-fail backoff works; the gate was also slimmed (5f2e5e0a / #285: dispatch suite moved out to CI).
- ACTION: close.

### #231 dispatch: reduce channel spam
- CLASS: SUPERSEDED
- EVIDENCE: the jarate-bg dispatch layer is retired (hall-monitor #35; #279 drain); P2 (bridge [bg: queued-ack silence) landed — index.ts:3617-3627 "#231 P2: machine wakes queue SILENTLY"; P1's -killed marker logic survives in the live signal subcommand (dispatch/jarate-bg); P3's marker removed with jarate-wait (queue.ts:218); P4 (no-output DIED) was launcher-side, gone with the retirement.
- ACTION: close with cross-ref to hall-monitor #35 / #279.

### #225 jarate-bg test flake: dual-lookup /tmp tests
- CLASS: SUPERSEDED
- EVIDENCE: the flaky "dual lookup ... legacy /tmp" test was removed with the pi-bg path gut (293c0722 / #272); jarate-bg.test.ts now covers only the stub contract + #143 signal subcommand (2 describe blocks).
- ACTION: close with cross-ref to hall-monitor #35.

### #223 dispatch: cross-ticket mtime race in bg_session_file
- CLASS: SUPERSEDED
- EVIDENCE: bg_session_file is gone with the launcher retirement (293c0722 / #272; the stub has no launch path, only the signal subcommand); fleetwork is now the dispatch.
- ACTION: close with cross-ref to hall-monitor #35.

### #219 pat-run: 401 'invalid credentials' (trailing newline)
- CLASS: SUPERSEDED
- EVIDENCE: bin/jarate-pat gutted (1d0c2fb3, 2026-10-17 — "hall-monitor owns it now"); hall-monitor owns vault credentials; the newline fix never landed but the component is gone.
- ACTION: close with cross-ref to hall-monitor vault.

### #217 vault/pat: no agent wake on tap approval
- CLASS: SUPERSEDED
- EVIDENCE: the fix landed pre-gut — 91e93c61 (#218, 2026-10-14 "wake agent on approval") + a79088eb (#221, 2026-10-16 "owner-tap wake (rewake on approve/deny/revoke)"); the pat/vault surface was then gutted (1d0c2fb3); hall-monitor owns the vault + plan-approval wakes.
- ACTION: close with cross-ref to hall-monitor vault.

### #211 tests: fixtures invented d.message_id + stub URL contract
- CLASS: SUPERSEDED
- EVIDENCE: the URL-contract + fixture fixes landed in 8db58e23 (merge of pi-bg/vault-ops, 2026-10-09); the vault surface + its tests were gutted in 1d0c2fb3 — the discriminating tests were against the vault surface, which moved to hall-monitor.
- ACTION: close with cross-ref to hall-monitor vault.

### #210 bridge: discordFetch truncates 4xx error bodies to 200 chars
- CLASS: DONE
- EVIDENCE: the fullError option is live in code — discord.ts:75/105 (cap 1000, "#210"), used on the interaction callback endpoint (discord.ts:1627); 0c39f0c0 (2026-10-09).
- ACTION: close.

### #209 vault: dual surface — deprecate pat-vault, plan removal
- CLASS: SUPERSEDED
- EVIDENCE: the deprecation note landed in 8db58e23 (2026-10-09); the whole dual surface was then removed (1d0c2fb3 — bin/jarate-pat + bin/jarate-vault gone, pat-vault.ts + vault.ts deleted); hall-monitor owns the vault.
- ACTION: close with cross-ref to hall-monitor vault.

### #208 vault: startupSweep audits no-op sweep lines
- CLASS: SUPERSEDED
- EVIDENCE: the sweep guard landed in 8db58e23 (2026-10-09); vault.ts gutted in 1d0c2fb3 — the audit surface moved to hall-monitor.
- ACTION: close with cross-ref to hall-monitor vault.

### #207 vault: tap defer ack is channel-visible
- CLASS: SUPERSEDED
- EVIDENCE: the fix landed in 0c39f0c0 (2026-10-09, "every outcome visible + audited"); vault.ts gutted in 1d0c2fb3.
- ACTION: close with cross-ref to hall-monitor vault.

### #206 vault: no non-button approval path
- CLASS: SUPERSEDED
- EVIDENCE: the /vault slash path landed in 8db58e23 (2026-10-09); vault.ts gutted in 1d0c2fb3 — approval is now the hall-monitor plan-approval surface.
- ACTION: close with cross-ref to hall-monitor vault.

### #205 vault: default grant must be 30-min time-box
- CLASS: SUPERSEDED
- EVIDENCE: the fix landed in 5971a730 (2026-10-09, "default grant 30m time-box"); vault.ts gutted in 1d0c2fb3.
- ACTION: close with cross-ref to hall-monitor vault.

### #204 vault: tap outcomes not visible/audited
- CLASS: SUPERSEDED
- EVIDENCE: the fix landed in 0c39f0c0 (2026-10-09); vault.ts + pat-vault.ts gutted in 1d0c2fb3.
- ACTION: close with cross-ref to hall-monitor vault.

### #203 vault: pending requests auto-expire after 5m
- CLASS: SUPERSEDED
- EVIDENCE: the fix landed in 5971a730 (2026-10-09, "pending has no default TTL (blocking; revoke kill switch)"); vault.ts gutted in 1d0c2fb3.
- ACTION: close with cross-ref to hall-monitor vault.

### #202 vault+pat-vault: mismatch check reads d.message_id
- CLASS: SUPERSEDED
- EVIDENCE: the fix landed in 9929c5c6 (2026-10-09, "d.message.id, PATCH @original reply, audit every tap"); vault.ts + pat-vault.ts gutted in 1d0c2fb3.
- ACTION: close with cross-ref to hall-monitor vault.

### #200 deploy: jarate-deploy flapping (600s timeout + state drift)
- CLASS: PARTIAL
- EVIDENCE: TimeoutStartSec=1800 + SIGTERM fail-recording landed (69c8720c / #238); the gate was slimmed (5f2e5e0a / #285: dispatch suite moved to CI — the ~600s wall portion is out of the gate); the #143 signal receipt subcommand is live.
- REMAINING: the manual-pull state-drift fast path (option 1) is not implemented — state-behind + checkout-at-origin/main still runs the full gate + pi.service restart (deploy.sh's "up to date" skip only covers deployed == origin/main).
- ACTION: keep open; low-medium priority (the livelock is fixed; the fast path is an optimization).

### #197 LOW follow-ups batch (#194 F1/F2 + #195 F1/F2)
- CLASS: PARTIAL
- EVIDENCE: F4 is superseded — the watchdog (out)-annotation test target left the repo (274801fc / #280-3c).
- REMAINING: F1 unaddressed — settleWorkingFrame still persists the frame clear before the REST is confirmed (index.ts:2306, not in p.then). F2 unaddressed — the clears (midTurnQueues/queuedAcks/clearAllInterrupts, index.ts:2059-2061) still persist/unlink (persistLivePlaceholders unlinks when empty, live.ts:157-161) before await Promise.allSettled(shutdownDeletes) (index.ts:2076). F3 unaddressed — the stub's exit-code line still reads "0/3 signal receipt (gone / still alive)" without the "or no live members" disambiguation (empty cgroup exits 3, dispatch/jarate-bg:150-151).
- ACTION: keep open; low priority.

### #193 styleGuard multi-URL machine line duplicates the 2nd URL
- CLASS: OPEN
- EVIDENCE: the styleGuard copy (format.ts:722) still has the forward-order splice `for (const u of urls) r = r.slice(0, u.start) + r.slice(u.end);`; the hoistFencedUrls copy was fixed in 89eb9abd / #190, which explicitly deferred the styleGuard copy to this issue ("follow-up styleGuard copy in #193").
- ACTION: keep open; low-medium priority (2-line reverse-order splice + two-URLs-one-line test).

### #191 dispatch: agent-liveness watchdog (monky OOM follow-up)
- CLASS: SUPERSEDED
- EVIDENCE: the watchdog script left the repo (274801fc / #280-3c "run-state/OOM sweep removed — dispatch/jarate-bg-watchdog is gone"); fleet liveness (M2 marker sweep) centralised to hall-monitor#59 (1c7be7df); OOM baseline reports → hall-monitor#60; the timer template was re-added (45a68339 / #302) but points at the live-box script (%h/scripts/jarate-bg-watchdog).
- ACTION: close with cross-ref to hall-monitor #59 / #60.

### #57 [pi-bg] silent exit=1 mid-turn (5x on 2026-09-14)
- CLASS: SUPERSEDED
- EVIDENCE: the pi-bg lane is retired (hall-monitor #35; dispatch/jarate-bg stub exit 10); the root cause was diagnosed 2026-09-22 (RETRYABLE_PROVIDER_ERROR_PATTERN missing ECONN* codes) and filed upstream against earendil-works/pi; the in-repo backstop (pi-bg SILENT-tail retry1) left with pi-bg.
- ACTION: close with cross-ref to the upstream filing + hall-monitor #35.
