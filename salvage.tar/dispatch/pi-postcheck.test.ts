/**
 * dispatch/pi-postcheck.sh — restart health check (C1 + C8, polish sweep).
 *
 * Runs the real bash script against a fake HOME with stubbed curl /
 * systemctl / journalctl. C1: the webhook heartbeat is state-aware
 * (the failure path used to read "[!] healthy", a lie). The heartbeat is
 * an EMBED CARD (2026-10-19; 2026-10-21 de-prefix: the visible [bg:
 * content prefix is dropped): EMPTY content, the EMBED AUTHOR is
 * `pi-bg pi-restart · ok|fail` (the wake marker), + one embed
 * (postcheck · ok/fail, green/red, footer pi-postcheck).
 * In-flight note lines ride the embed's in-flight field as RAW LINES:
 * no frame, no wrap, no width budget; a long token (URL) ships
 * verbatim.
 */
import { afterEach, describe, expect, test } from "bun:test";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { spawn } from "bun";

const POSTCHECK = path.join(import.meta.dir, "pi-postcheck.sh");
const TOKEN = "tok-pc-111";
const CHANNEL = "chan-pc-111";

const tmpDirs: string[] = [];
afterEach(() => {
  for (const d of tmpDirs.splice(0)) {
    fs.rmSync(d, { recursive: true, force: true });
  }
});

interface Post {
  url: string;
  content: string;
  embeds?: Array<{
    author?: { name: string };
    title: string;
    color: number;
    description: string;
    fields?: Array<{ name: string; value: string }>;
    footer?: { text: string };
  }>;
}

interface Fixture {
  tmp: string;
  home: string;
  webhookUrl: string;
  env: Record<string, string>;
  setJournal: (lines: string[]) => void;
  setSystemd: (rc: number) => void;
  setInflight: (s: string | null) => void;
  run: () => Promise<{ code: number; out: string; err: string }>;
  posts: () => Post[];
  /** stub call log: which of systemctl/journalctl the script invoked */
  calls: () => string[];
}

function fixture(): Fixture {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "pipostcheck-"));
  tmpDirs.push(tmp);
  const home = path.join(tmp, "home");
  const bin = path.join(tmp, "bin");
  const capture = path.join(tmp, "curl-capture.txt");
  const journal = path.join(tmp, "journal.txt");
  const callsPath = path.join(tmp, "stub-calls.txt");
  fs.mkdirSync(home, { recursive: true });
  fs.mkdirSync(bin, { recursive: true });
  fs.mkdirSync(path.join(home, ".pi", "agent"), { recursive: true });
  fs.mkdirSync(path.join(home, ".config", "pi-dispatch"), { recursive: true });
  fs.writeFileSync(
    path.join(home, ".pi", "agent", "settings.json"),
    JSON.stringify({
      channels: [
        { channel: CHANNEL, botToken: TOKEN, enabled: true, default: true },
      ],
    }),
  );
  fs.writeFileSync(path.join(journal), "");

  // stub curl: records (url, -d payload) per call
  fs.writeFileSync(
    path.join(bin, "curl"),
    `#!/bin/sh
url=""; data=""
while [ $# -gt 0 ]; do
  case "$1" in
    -d) data="$2"; shift 2;;
    -H) shift 2;;
    -m) shift 2;;
    -X) shift 2;;
    -s) shift;;
    *) url="$1"; shift;;
  esac
done
printf '%s\\n%s\\n--\\n' "$url" "$data" >> "$CURL_CAPTURE"
printf 'ok\\n'
`,
  );
  // stub systemctl: is-active rc from the env knob; logs every call
  fs.writeFileSync(
    path.join(bin, "systemctl"),
    '#!/bin/sh\necho systemctl >> "$STUB_CALLS"\nif [ -n "$STUB_SYSTEMD_RC" ]; then exit "$STUB_SYSTEMD_RC"; fi\nexit 0\n',
  );
  // stub journalctl: emits the prepared journal lines; logs every call
  fs.writeFileSync(
    path.join(bin, "journalctl"),
    `#!/bin/sh\necho journalctl >> "$STUB_CALLS"\ncat "$STUB_JOURNAL" 2>/dev/null || true\n`,
  );
  for (const f of ["curl", "systemctl", "journalctl"]) {
    fs.chmodSync(path.join(bin, f), 0o755);
  }

  const env = { ...process.env } as Record<string, string>;
  env.HOME = home;
  env.PATH = `${bin}:${env.PATH ?? ""}`;
  env.CURL_CAPTURE = capture;
  env.STUB_JOURNAL = journal;
  env.STUB_CALLS = callsPath;
  env.STUB_SYSTEMD_RC = "0";
  return {
    tmp,
    home,
    webhookUrl: "",
    env,
    setJournal: (lines: string[]) =>
      fs.writeFileSync(journal, lines.join("\n")),
    setSystemd: (rc: number) => {
      env.STUB_SYSTEMD_RC = String(rc);
    },
    setInflight: (s: string | null) => {
      const p = path.join(home, ".config", "pi-inflight.md");
      if (s === null) fs.rmSync(p, { force: true });
      else fs.writeFileSync(p, s);
    },
    run: async () => {
      const p = spawn(["bash", POSTCHECK], {
        env,
        cwd: tmp,
        stdout: "pipe",
        stderr: "pipe",
      });
      const [out, err] = await Promise.all([
        new Response(p.stdout).text(),
        new Response(p.stderr).text(),
      ]);
      const code = await p.exited;
      return { code, out, err };
    },
    posts: () => {
      const raw = fs.existsSync(capture)
        ? fs.readFileSync(capture, "utf8")
        : "";
      return raw
        .split("--\n")
        .map((c) => c.trim())
        .filter(Boolean)
        .map((c) => {
          const [url, ...rest] = c.split("\n");
          const data = rest.join("\n");
          const j = JSON.parse(data) as {
            content: string;
            embeds?: Post["embeds"];
          };
          return {
            url: url ?? "",
            content: j.content,
            embeds: j.embeds,
          };
        });
    },
    calls: () =>
      fs.existsSync(callsPath)
        ? fs.readFileSync(callsPath, "utf8").trim().split("\n").filter(Boolean)
        : [],
  };
}

const webhookPost = (f: Fixture): Post => {
  const p = f.posts().find((x) => x.url.startsWith("http://127.0.0.1"));
  if (!p)
    throw new Error(`webhook post not captured: ${JSON.stringify(f.posts())}`);
  return p;
};

const channelPost = (f: Fixture): Post => {
  const p = f.posts().find((x) => x.url.includes(`channels/${CHANNEL}`));
  if (!p)
    throw new Error(`channel post not captured: ${JSON.stringify(f.posts())}`);
  return p;
};

describe("pi-postcheck C1: state-aware wording", () => {
  test("healthy: [ok] healthy 90s after restart (channel + webhook)", async () => {
    const f = fixture();
    fs.writeFileSync(
      path.join(f.home, ".config", "pi-dispatch", "webhook"),
      "http://127.0.0.1:1/hook\n",
    );
    try {
      const r = await f.run();
      expect(r.code).toBe(0);
      expect(channelPost(f).content).toBe(
        "`[ok] pi post-check: service healthy 90s after restart`",
      );
      const hb = webhookPost(f);
      // embed card: EMPTY content, author `pi-bg pi-restart · ok` (the
      // 2026-10-21 wake marker) + one embed
      expect(hb.content).toBe("");
      expect(hb.embeds).toHaveLength(1);
      expect(hb.embeds[0].author?.name).toBe("pi-bg pi-restart \u00b7 ok");
      expect(hb.embeds[0].title).toBe("postcheck \u00b7 ok");
      expect(hb.embeds[0].color).toBe(0x57f287);
      expect(hb.embeds[0].footer?.text).toBe("pi-postcheck");
      expect(hb.embeds[0].fields).toBeUndefined();
    } finally {
      f.setInflight(null);
    }
  });

  test("service down: [!] not healthy (not '[!] healthy')", async () => {
    const f = fixture();
    fs.writeFileSync(
      path.join(f.home, ".config", "pi-dispatch", "webhook"),
      "http://127.0.0.1:1/hook\n",
    );
    f.setSystemd(3);
    try {
      const r = await f.run();
      expect(r.code).toBe(0);
      expect(channelPost(f).content).toBe(
        "`[!] pi.service not active after restart`",
      );
      const hb = webhookPost(f);
      expect(hb.content).toBe("");
      expect(hb.embeds?.[0].author?.name).toBe("pi-bg pi-restart \u00b7 fail");
      expect(hb.embeds?.[0].title).toBe("postcheck \u00b7 fail");
      expect(hb.embeds?.[0].color).toBe(0xed4245);
    } finally {
      f.setInflight(null);
    }
  });

  test("systemd error: channel posts the clipped error line; heartbeat [!]", async () => {
    const f = fixture();
    fs.writeFileSync(
      path.join(f.home, ".config", "pi-dispatch", "webhook"),
      "http://127.0.0.1:1/hook\n",
    );
    f.setJournal([
      "Sep 15 10:00:01 host systemd[1]: pi.service: Main process exited, code=killed, status=1/SEGV (Failed with result 'signal').",
      "Sep 15 10:00:03 host systemd[1]: pi.service: second failed line must not be quoted",
    ]);
    try {
      const r = await f.run();
      expect(r.code).toBe(0);
      const ch = channelPost(f).content;
      expect(ch).toContain("`[!] pi restarted, systemd error:`");
      expect(ch).toContain("Main process exited, code=killed, status=1/SEGV");
      expect(ch).not.toContain("second failed line"); // head -1 only
      expect(webhookPost(f).content).toBe("");
      expect(webhookPost(f).embeds?.[0].author?.name).toBe(
        "pi-bg pi-restart \u00b7 fail",
      );
    } finally {
      f.setInflight(null);
    }
  });
});

/**
 * audit dispatch-core F1 (pi-postcheck slice P2): the journal filter must
 * drop systemd "0 failed" summary lines. The live incident: a healthy
 * restart's journal contained a line matching systemd[ + failed with a
 * "0 failed" unit summary, and the postcheck posted a [!] "systemd
 * error" quoting that line - a false alarm on every clean restart.
 */
describe("pi-postcheck: systemd '0 failed' summary lines are not errors", () => {
  const SUMMARY =
    "Sep 15 10:00:01 host systemd[1]: pi.service: 4 loaded units listed (4 target, 3 listening, 0 failed).";
  const REAL =
    "Sep 15 10:00:02 host systemd[1]: pi.service: Main process exited, code=killed, status=1/SEGV (Failed with result 'signal').";

  test("only '0 failed' lines in journal -> healthy, no error block", async () => {
    const f = fixture();
    fs.writeFileSync(
      path.join(f.home, ".config", "pi-dispatch", "webhook"),
      "http://127.0.0.1:1/hook\n",
    );
    // SUMMARY matches `systemd[` + `failed` (case-insensitive) but carries
    // the "0 failed" marker: grep -aiv "0 failed" must drop it
    f.setJournal([SUMMARY]);
    try {
      const r = await f.run();
      expect(r.code).toBe(0);
      // healthy: no systemd-error block in the channel line
      expect(channelPost(f).content).toBe(
        "`[ok] pi post-check: service healthy 90s after restart`",
      );
      expect(webhookPost(f).content).toBe("");
      expect(webhookPost(f).embeds?.[0].author?.name).toBe(
        "pi-bg pi-restart \u00b7 ok",
      );
      expect(webhookPost(f).content).not.toContain("systemd error");
    } finally {
      f.setInflight(null);
    }
  });

  test("'0 failed' line + real error: the real error is quoted, not the summary", async () => {
    const f = fixture();
    fs.writeFileSync(
      path.join(f.home, ".config", "pi-dispatch", "webhook"),
      "http://127.0.0.1:1/hook\n",
    );
    // the summary line comes FIRST: without the filter, head -1 quotes IT
    f.setJournal([SUMMARY, REAL]);
    try {
      const r = await f.run();
      expect(r.code).toBe(0);
      const ch = channelPost(f).content;
      expect(ch).toContain("`[!] pi restarted, systemd error:`");
      expect(ch).toContain(REAL);
      expect(ch).not.toContain(SUMMARY); // the 0-failed summary is filtered
      expect(webhookPost(f).content).toBe("");
      expect(webhookPost(f).embeds?.[0].author?.name).toBe(
        "pi-bg pi-restart \u00b7 fail",
      );
    } finally {
      f.setInflight(null);
    }
  });
});

/**
 * audit dispatch-core F2 (pi-postcheck slice P5): the missing-settings and
 * no-bot-token branches. Both must: exit 0, post NO channel message (no
 * CH_ID/TOKEN to post with), emit the degraded webhook frame, and short-
 * circuit BEFORE any systemctl/journalctl call (proven by the stub call
 * log). The literal channel MSG text is unobservable in these branches
 * (it only ships with a channel post), so the branch is pinned via the
 * observable side effects instead.
 */
describe("pi-postcheck: missing settings / no bot token branches", () => {
  // the fail-state wake marker (2026-10-21: content is empty, the state
  // rides the embed author)
  const FAIL_AUTHOR = "pi-bg pi-restart \u00b7 fail";

  test("settings.json missing: exit 0, no channel post, degraded frame, no systemd probes", async () => {
    const f = fixture();
    fs.writeFileSync(
      path.join(f.home, ".config", "pi-dispatch", "webhook"),
      "http://127.0.0.1:1/hook\n",
    );
    fs.rmSync(path.join(f.home, ".pi", "agent", "settings.json"));
    try {
      const r = await f.run();
      expect(r.code).toBe(0);
      // exactly ONE post: the webhook heartbeat (no channel post)
      expect(f.posts()).toHaveLength(1);
      expect(webhookPost(f).content).toBe("");
      expect(webhookPost(f).embeds?.[0].author?.name).toBe(FAIL_AUTHOR);
      // branch short-circuits before probing the service
      expect(f.calls()).toEqual([]);
    } finally {
      f.setInflight(null);
    }
  });

  test("no bot token: exit 0, no channel post, degraded frame, no systemd probes", async () => {
    const f = fixture();
    fs.writeFileSync(
      path.join(f.home, ".config", "pi-dispatch", "webhook"),
      "http://127.0.0.1:1/hook\n",
    );
    fs.writeFileSync(
      path.join(f.home, ".pi", "agent", "settings.json"),
      JSON.stringify({
        channels: [
          { channel: CHANNEL, botToken: "", enabled: true, default: true },
        ],
      }),
    );
    try {
      const r = await f.run();
      expect(r.code).toBe(0);
      // exactly ONE post: the webhook heartbeat (no channel post)
      expect(f.posts()).toHaveLength(1);
      expect(webhookPost(f).content).toBe("");
      expect(webhookPost(f).embeds?.[0].author?.name).toBe(FAIL_AUTHOR);
      // the token check fires before is-active / journalctl
      expect(f.calls()).toEqual([]);
    } finally {
      f.setInflight(null);
    }
  });
});

describe("pi-postcheck in-flight note: raw embed field lines (2026-10-19)", () => {
  test("80-char URL in the in-flight note: ships verbatim in the field, no wrap, no fence", async () => {
    const f = fixture();
    fs.writeFileSync(
      path.join(f.home, ".config", "pi-dispatch", "webhook"),
      "http://127.0.0.1:1/hook\n",
    );
    const url = `https://webdrop.example/file/${"a".repeat(60)}.png`;
    // the old 30-col budget would have chunked this
    expect(url.length).toBeGreaterThan(40);
    f.setInflight(url);
    try {
      const r = await f.run();
      expect(r.code).toBe(0);
      const hb = webhookPost(f);
      // the content is EMPTY (2026-10-21 de-prefix) - the note rides the
      // embed field, the state rides the embed author
      expect(hb.content).toBe("");
      expect(hb.embeds?.[0].author?.name).toBe("pi-bg pi-restart \u00b7 ok");
      // no fence, no frame characters anywhere in the card
      const em = hb.embeds?.[0];
      expect(em).toBeDefined();
      expect(JSON.stringify(em)).not.toContain("```");
      expect(JSON.stringify(em)).not.toMatch(/[┌└│├┤┣]/);
      // the note line is ONE raw field value - verbatim, unchunked
      const fld = em?.fields?.[0];
      expect(fld?.name).toBe("in-flight");
      expect(fld?.value).toBe(url);
    } finally {
      f.setInflight(null);
    }
  });

  test("multi-line note: every line in the field, blank lines dropped", async () => {
    const f = fixture();
    fs.writeFileSync(
      path.join(f.home, ".config", "pi-dispatch", "webhook"),
      "http://127.0.0.1:1/hook\n",
    );
    f.setInflight("fix the pi restart loop\n\nthen redeploy");
    try {
      const r = await f.run();
      expect(r.code).toBe(0);
      const hb = webhookPost(f);
      expect(hb.content).toBe("");
      expect(hb.embeds?.[0].fields?.[0].name).toBe("in-flight");
      expect(hb.embeds?.[0].fields?.[0].value).toBe(
        "fix the pi restart loop\nthen redeploy",
      );
    } finally {
      f.setInflight(null);
    }
  });

  test("in-flight >1024 chars: field capped at Discord's limit with overflow suffix (review MEDIUM 2026-10-19)", async () => {
    const f = fixture();
    fs.writeFileSync(
      path.join(f.home, ".config", "pi-dispatch", "webhook"),
      "http://127.0.0.1:1/hook\n",
    );
    // 20 realistic ticket lines (~130 chars each) -> ~2.7KB joined: the
    // pre-fix field value would 400 the whole webhook post
    const lines = Array.from(
      { length: 20 },
      (_, i) =>
        `20261019-071832-5730${i} worker 30:45 # JARATE - card-format all plain [bg: webhook posts (Andryo 2026-10-19)`,
    );
    const joined = lines.join("\n");
    expect(joined.length).toBeGreaterThan(1024);
    f.setInflight(joined);
    try {
      const r = await f.run();
      expect(r.code).toBe(0);
      const hb = webhookPost(f);
      expect(hb.content).toBe("");
      const fields = hb.embeds?.[0].fields ?? [];
      // Discord-shippable: no field value over the 1024 limit
      for (const x of fields) {
        expect(x.value.length).toBeLessThanOrEqual(1024);
      }
      const fld = fields[0];
      expect(fld?.name).toBe("in-flight");
      expect(fld?.value.startsWith(lines[0])).toBe(true);
      expect(fld?.value).toContain("\u2026 +");
      expect(fld?.value.endsWith("lines - see /jobs")).toBe(true);
      expect(fld?.value).not.toBe(joined);
    } finally {
      f.setInflight(null);
    }
  });
});

/**
 * issue #262 (DRY): the dispatch webhook resolver is single-sourced in
 * dispatch/lib.sh jrate_webhook - $PI_DISPATCH_WEBHOOK wins, else the
 * FIRST LINE (head -1) of ~/.config/pi-dispatch/webhook. The old
 * postcheck `cat`ed the whole file: a stray second line corrupted the
 * URL. Pins both halves of the contract.
 */
describe("pi-postcheck webhook resolution (issue #262)", () => {
  test("2-line webhook file: only the first line is posted to (head -1, not cat)", async () => {
    const f = fixture();
    fs.writeFileSync(
      path.join(f.home, ".config", "pi-dispatch", "webhook"),
      "http://127.0.0.1:1/hook\nhttp://127.0.0.1:1/stray-second-line\n",
    );
    try {
      const r = await f.run();
      expect(r.code).toBe(0);
      // With the old `cat`, the second line would have landed inside the
      // captured URL and broken the (url, body) capture parse below.
      const hb = webhookPost(f);
      expect(hb.url).toBe("http://127.0.0.1:1/hook");
      // de-prefix (#277): content is EMPTY; the marker rides the author.
      expect(hb.content).toBe("");
      expect(hb.embeds?.[0].author?.name).toBe("pi-bg pi-restart \u00b7 ok");
    } finally {
      f.setInflight(null);
    }
  });

  test("$PI_DISPATCH_WEBHOOK overrides the webhook file", async () => {
    const f = fixture();
    fs.writeFileSync(
      path.join(f.home, ".config", "pi-dispatch", "webhook"),
      "http://127.0.0.1:1/file-hook\n",
    );
    f.env.PI_DISPATCH_WEBHOOK = "http://127.0.0.1:1/env-hook";
    try {
      const r = await f.run();
      expect(r.code).toBe(0);
      expect(webhookPost(f).url).toBe("http://127.0.0.1:1/env-hook");
    } finally {
      f.setInflight(null);
      delete f.env.PI_DISPATCH_WEBHOOK;
    }
  });
});
